function lqcontr(operation);
% LQCONTR	Module illustrating Linear quadratic control.

%		Author: Helena Haglund
%		LastEditDate : October 11, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_lq fig2_lq ccs_col fig_ccs
global system_lq
global h_cur sli_h h ra_cur sli_ra ra
global phi gam C D Bd Ad Bd_cl Ad_cl q1 q2 y
global error_lq

if nargin == 0,
	operation = 'show';
end;

%-- checks if the window already exists
if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('LQ-control');
	if ~existFlag,
      		lqcontr('winit_lq');
      		lqcontr('init_lq');	
 		[existFlag,figNumber]=figflag('LQ-control');
	else
		clf;
		lqcontr('init_lq');
	end;


%%---------------SYSTEM ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'system'),

	figure(fig_lq);

	watchon;
	set(error_lq,'Visible','off');
	figure(fig2_lq);
	subplot(211);
	cla;
	subplot(212);
	cla;

	figure(fig_lq);
if get(system_lq,'Value') ==2|get(system_lq,'Value') ==3|...
get(system_lq,'Value') ==4,

	%-- set ra to current value
	set(ra_cur,'String',num2str(get(sli_ra,'Val')));
	ra = get(sli_ra,'Value');

	if get(system_lq,'value')==2,
		%-- double integrator        
		Bc = 1;
		Ac = [1 0 0];
		h = 1;
		[A,B,C,D] = tf2ss(Bc,Ac);
		[phi,gam] = c2d(A,B,h);
		[Bd,Ad] = ss2tf(phi,gam,C,D,1);

	elseif get(system_lq,'value')==3,
		%-- system with zero inside unit circle 
		Bd = [1 0.5];
		Ad = [1 -1 0.3];
		[phi,gam,C,D] = tf2ss(Bd,Ad);
		     
	elseif get(system_lq,'value')==4,
		%-- system with zero outside unit circle 
		Bd = [1 1.3];
		Ad = [1 -1 0.3];
		[phi,gam,C,D] = tf2ss(Bd,Ad);
	end;

	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	
	%-- plot open loop poles and zeros
	if ccs_col == 1,
		z = plot(real(roots(Bd)),imag(roots(Bd)),'bo');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(roots(Ad)),imag(roots(Ad)),'bx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(roots(Bd)),imag(roots(Bd)),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(roots(Ad)),imag(roots(Ad)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- error if choosing ra=0 with the double integrator
   	if ra ==0 & get(system_lq,'Value')==2,
		set(error_lq,'Visible','on');
   	else
		
	q1 = C'*C;
	q2 = ra;

	%-- lq-design
	error(abcdchk(phi,gam));	
 	[ma,na] = size(phi);
	[mb,nb] = size(gam);
	[mq1,nq1] = size(q1);
	[mq2,nq2] = size(q2);
   	q12 = zeros(mq1,nq2);
	Q = [q1 q12; q12' q2];

 	%-- Calculate solution to Riccati equation

  	q12 = zeros(size(phi)*[1;0],size(gam)*[0;1]);
	% Generalized Schur form Riccati solver
	% Construct generalized pencil
	na = length(phi);
	nb = size(gam)*[0;1];
	Bc = [eye(na) zeros(na,na+nb); zeros(na,na) phi' zeros(na,nb); 
        zeros(nb,na) -gam' zeros(nb,nb)];
	Ac = [phi zeros(na,na) gam; -q1 eye(na) -q12; q12' zeros(nb,na) q2];
	% Call solver
	n = length(Ac);
	na = (n-nb)/2;
 
	% Reduce pencil to size 2*na
	[q,r] = qr(Ac(:,n-nb+1:n));
	A = q(:,n:-1:1)'*Ac;
	B = q(:,n:-1:1)'*Bc;
 
	A = A(1:n-nb,1:n-nb);
	B = B(1:n-nb,1:n-nb);
 
	% Solve generalized eigenvalue problem
	[AA,BB,q,z,v] = qz(A,B);
 
	% Find all eigenvalues inside the specified region
	dAA = diag(AA);
	dBB = diag(BB);
 	ind = abs(dAA)-abs(dBB) < -eps;

 	% Order eigenvalues
	% This part of the code is a direct translation of the sorting of 
	% of 1x1 blocks in ACM TOMS algorithm 590
	j = find(ind(1:n-nb)==0);
	k = find(ind(j(1)+1:n-nb)==1);
	while ~isempty(k)
  		j = j(1);
  		k = k(1)+j;
  		% Propagate element up the diagonal from k-th to j-th entry
  		for l = k-1:-1:j
    			l1 = l+1;
    			% exchange element l and l1, use algorithm EXCHQZ in 
			%590 ACM ToMS
    			f = max(abs([AA(l1,l1),BB(l1,l1)]));
    			altb = abs(AA(l1,l1)) < f;
    			% construct the column transformation zt
    			zt = givens((BB(l,l)*AA(l1,l1)-AA(l,l)*BB(l1,l1))/f,...
                	(BB(l,l1)*AA(l1,l1)-AA(l,l1)*BB(l1,l1))/f);
    			zt = [zt(2,:); zt(1,:)];
    			AA(:,l:l1) = AA(:,l:l1)*zt; 
    			BB(:,l:l1) = BB(:,l:l1)*zt; 
    			z(:,l:l1) = z(:,l:l1)*zt; 
    			% construct the row transformation qt
    			if altb
      				qt = givens(BB(l,l), BB(l1,l));
    			else
      				qt = givens(AA(l,l), AA(l1,l));
    			end
    			AA(l:l1,:) = qt*AA(l:l1,:);
    			BB(l:l1,:) = qt*BB(l:l1,:);
    			ix = ind(l); ind(l) = ind(l1); ind(l1) = ix;
  		end;
  		% Find next element to shift
  		j = find(ind(1:n-nb)==0);
  		k = find(ind(j(1)+1:n-nb)==1);
	end;
 
	% Form solution from transformation matrix z
	S = real(z(na+1:2*na,1:na)/z(1:na,1:na));


	L  = (q2 + gam'*S*gam)\(gam'*S*phi + q12');  
	Lv = (q2 + gam'*S*gam)\(gam'*S);             

	%-- make stationary gain equal to one, u(kh)=-L*x(kh) + M*uc(kh)
	n = length(phi);			
	newPhi = eye(n)-phi+gam*L;

	M = inv(C*inv(newPhi)*gam);

	%-- calculate closed-loop system
	phi_cl = phi - gam*L;
	gam_cl = gam*M;
	[Bd_cl,Ad_cl] = ss2tf(phi_cl,gam_cl,C,D,1);
		
	subplot(224);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
 	
	%-- plot closed-loop poles and zeros
	if ccs_col == 1,
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'rx');
		set(p,'Linewidth',2,'Markersize',9);	
	else
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'kx');
		set(p,'Linewidth',2,'Markersize',9);	
	end;
	
	%-- simulate step response of closed-loop system
 	[y,x] = dstep(phi_cl,gam_cl,[C;-L],[0;M],1,20);

	figure(fig2_lq);

	%-- plot output
	subplot(211);
	cla;
	if ccs_col == 1,
		plot(y(:,1),'b');
	else
		plot(y(:,1),'k');
	end;

	%-- plot control signal
	subplot(212);
	cla;
	t=1:20;
	[ts,ys]=stairs(t,y(:,2));
	if ccs_col == 1,
		plot(ts,ys,'b');
	else
		plot(ts,ys,'k');
	end;
   end;
end;
	figure(fig_lq);
	watchoff;


%%------------------- CALCULATIONS ----------------------------
%%-------------------------------------------------------------

elseif strcmp(operation,'lqedit'),

	%-- update ra when changed with edit
	set(sli_ra,'Value',str2num(get(ra_cur,'String')));
	lqcontr('lqcalc');		

elseif strcmp(operation,'lqslid'),

	%-- update ra when changed with slider
	set(ra_cur,'String',num2str(get(sli_ra,'Value')));
	lqcontr('lqcalc');

elseif strcmp(operation,'lqcalc'),

if get(system_lq,'Value') ==2|get(system_lq,'Value') ==3|...
get(system_lq,'Value') ==4,

   %-- get correct value of ra
   ra = get(sli_ra,'Value');

   %-- error if choosing ra=0 with the double integrator
   if ra ==0 & get(system_lq,'Value')==2,
	set(error_lq,'Visible','on');
   else
	set(error_lq,'Visible','off');
	q1 = C'*C;
	q2 = ra;

	%-- lq-design
	error(abcdchk(phi,gam));	
 	[ma,na] = size(phi);
	[mb,nb] = size(gam);
	[mq1,nq1] = size(q1);
	[mq2,nq2] = size(q2);
  	q12 = zeros(mq1,nq2);
 	Q = [q1 q12; q12' q2];

	%-- Calculate solution to Riccati equation
	q12 = zeros(size(phi)*[1;0],size(gam)*[0;1]);
	% Generalized Schur form Riccati solver
	% Construct generalized pencil
	na = length(phi);
	nb = size(gam)*[0;1];
	Bc = [eye(na) zeros(na,na+nb); zeros(na,na) phi' zeros(na,nb); 
        zeros(nb,na) -gam' zeros(nb,nb)];
	Ac = [phi zeros(na,na) gam; -q1 eye(na) -q12; q12' zeros(nb,na) q2];
	% Call solver
	n = length(Ac);
	na = (n-nb)/2;
 
	% Reduce pencil to size 2*na
	[q,r] = qr(Ac(:,n-nb+1:n));
	A = q(:,n:-1:1)'*Ac;
	B = q(:,n:-1:1)'*Bc;
 
	A = A(1:n-nb,1:n-nb);
	B = B(1:n-nb,1:n-nb);
 
	% Solve generalized eigenvalue problem
	[AA,BB,q,z,v] = qz(A,B);
 
	% Find all eigenvalues inside the specified region
	dAA = diag(AA);
	dBB = diag(BB);
 	ind = abs(dAA)-abs(dBB) < -eps;

 	% Order eigenvalues
	% This part of the code is a direct translation of the sorting of 
	% of 1x1 blocks in ACM TOMS algorithm 590
	j = find(ind(1:n-nb)==0);
	k = find(ind(j(1)+1:n-nb)==1);
	while ~isempty(k)
  		j = j(1);
  		k = k(1)+j;
  		% Propagate element up the diagonal from k-th to j-th entry
  		for l = k-1:-1:j
    			l1 = l+1;
    			% exchange element l and l1, use algorithm EXCHQZ in 
			%590 ACM ToMS
    			f = max(abs([AA(l1,l1),BB(l1,l1)]));
    			altb = abs(AA(l1,l1)) < f;
    			% construct the column transformation zt
    			zt = givens((BB(l,l)*AA(l1,l1)-AA(l,l)*BB(l1,l1))/f,...
                	(BB(l,l1)*AA(l1,l1)-AA(l,l1)*BB(l1,l1))/f);
    			zt = [zt(2,:); zt(1,:)];
    			AA(:,l:l1) = AA(:,l:l1)*zt; 
    			BB(:,l:l1) = BB(:,l:l1)*zt; 
    			z(:,l:l1) = z(:,l:l1)*zt; 
    			% construct the row transformation qt
    			if altb
      				qt = givens(BB(l,l), BB(l1,l));
    			else
      				qt = givens(AA(l,l), AA(l1,l));
    			end
    			AA(l:l1,:) = qt*AA(l:l1,:);
    			BB(l:l1,:) = qt*BB(l:l1,:);
    			ix = ind(l); ind(l) = ind(l1); ind(l1) = ix;
  		end;
  		% Find next element to shift
  		j = find(ind(1:n-nb)==0);
  		k = find(ind(j(1)+1:n-nb)==1);
	end;
 
	% Form solution from transformation matrix z
	S = real(z(na+1:2*na,1:na)/z(1:na,1:na));

	L  = (q2 + gam'*S*gam)\(gam'*S*phi + q12');  
	Lv = (q2 + gam'*S*gam)\(gam'*S);             

	%-- make stationary gain equal to one, u(kh)=-L*x(kh) + M*uc(kh)
	n = length(phi);	
	newPhi = eye(n)-phi+gam*L;
	if rank(newPhi) ~= n
  		error('Can''t calculate reference input gain. System includes i			ntegrator.');	
	end
	M = inv(C*inv(newPhi)*gam);

	%-- calculate closed-loop system
	phi_cl = phi - gam*L;
	gam_cl = gam*M;
	[Bd_cl,Ad_cl] = ss2tf(phi_cl,gam_cl,C,D,1);
	
	%-- plot closed-loop system poles and zeros
	subplot(224);
	if ccs_col == 1,	
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'rx');
		set(p,'Linewidth',2,'Markersize',9);	
	else
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response of closed-loop system	
 	[y,x] = dstep(phi_cl,gam_cl,[C;-L],[0;M],1,20);

	figure(fig2_lq);

	%-- plot output
	subplot(211);
	if ccs_col == 1,
		plot(y(:,1),'r');
	else
		plot(y(:,1),'k--');
	end;

	%-- plot control signal
	subplot(212);
	t=1:20;
	[ts,ys]=stairs(t,y(:,2));
	if ccs_col == 1,
		plot(ts,ys,'r');
	else
		plot(ts,ys,'k--');
	end;
   end;
end;
	figure(fig_lq);
	watchoff;


%%------------------- CLEAR ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'lqclear'),
%-- keap only most resent simulation

if get(system_lq,'Value') ==2|get(system_lq,'Value') ==3|...
get(system_lq,'Value') ==4,

	watchon;
	subplot(224);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
 	
	%-- plot closed-loop poles and zeros
	if ccs_col == 1,
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(roots(Bd_cl)),imag(roots(Bd_cl)),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(Ad_cl)),imag(roots(Ad_cl)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;
	
	figure(fig2_lq);

	%-- plot output
	subplot(211);
	cla;
	if ccs_col == 1,
		plot(y(:,1),'b');
	else
		plot(y(:,1),'k');
	end;

	%-- plot control signal
	subplot(212);
	cla;
	t=1:20;
	[ts,ys]=stairs(t,y(:,2));
	if ccs_col == 1,
		plot(ts,ys,'b');
	else
		plot(ts,ys,'k');
	end;

	figure(fig_lq);
	watchoff;
end;


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_lq'),
   ttlStr='LQ-control help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' This demo illustrates the effect of changing'  
         ' the weighting (rho) on the control signal in'   
         ' LQ-control.                                 '
	 '                                             '
	 ' In LQ-control the control law u(k)=-L(k)x(k)'
	 ' is determined by minimizing the loss func-  '
	 ' tion J=E(y^2+rho*u^2), where rho is a weigh-'
	 ' ting on the control signal. When rho is     '
	 ' large, the control signal is kept small.    '
	 '                                             '
	 ' The poles of the closed-loop system are the '
	 ' roots of rho+H(z^-1)H(z)=0, where           '
	 ' H(z)=B(z)/A(z).                             '
	 '                                             '
	 ' Notice that, if rho is zero, the controller '
	 ' is a minimum variance controller. Then, one '
	 ' pole is situated in origo. The other pole is'
	 ' situated on the process zero, if the zero   '];

   hlpStr2= ...
	['                                             '
	 ' is inside the unit circle. If the zero is   '
	 ' outside the unit circle, the pole is anyway '
	 ' situated inside the unit circle, as a mirror'
	 ' image of the zero.                          ']; 

    hwin(ttlStr,hlpStr1,hlpStr2); 


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_lq'),
   ttlStr='LQ-control theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Chapter 11 in CCS p. 408 for reading    '  
         ' about optimal design methods with state-    '   
         ' space approach.                             '
	 '                                             '
	 ' See Chapter 11.2 in CCS p. 413-428 for more '
	 ' information about Linear Quadratic control. '];


    hwin(ttlStr,hlpStr); 


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_lq'),
   ttlStr='LQ-control hints...';
    hlpStr= ...                                           
        ['                                             '  
         ' Choose system 2 and set ra=0. This gives    '  
         ' deadbeat.                                   '
	 ' Notice that one pole is situated on the     '
	 ' process zero. This mode is seen in the con- '
	 ' trol signal. This type of deadbeat is some- '
	 ' times called output-deadbeat.               '
	 '                                             '
	 ' Then, set ra=10 and see how the step re-    '
	 ' sponse and control signal changes.          ']; 

    hwin(ttlStr,hlpStr);    
       

%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_lq'),

	fig_lq = figure('Name',...
	'LQ-control','NumberTitle','off','Units', 'Normalized',...
	'Position',[0.0425 0.4433 0.4861 0.4667 ],... 
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_lq,'Color',[0.8,0.8,0.8]);


elseif strcmp(operation,'init_lq'),
	watchon;

	%-- checks if plot window already exists
	[existFlag,figNumber]=...
	figflag('Plots, LQ-control');
	if ~existFlag,
      		fig2_lq= figure('Name',...
		'Step response & Control signal, LQ-control',...
		'NumberTitle','Off','BackingStore','Off',...
		'Units', 'Normalized',...
		'Position', [0.5286 0.4433 0.4340 0.4667 ]);
		set(fig2_lq,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=...
		figflag...
		('Step response & Control signal, LQ-control');
	else
		clf;fig=gcf;
	end;

	figure(fig_lq);

	%-- create diagram for plotting poles and zeros of open-loop system
	disc_lqopen = subplot(222);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	title('Open-loop system','Color','k',...
	'FontName','Times','Fontsize',11);
	set(disc_lqopen,'XLim',[-1.5 1.2],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for plotting poles and zeros of closed-loop system
	disc_lqclosed = subplot(224);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	title('Closed-loop system','Color','k',...
	'FontName','Times','Fontsize',11);
	set(disc_lqclosed,'XLim',[-1.5 1.2],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_lq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_lq = uicontrol(fig_lq,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','lqcontr(''close_lq'');');

	help_lq = uicontrol(fig_lq,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','lqcontr(''help_lq'');');

	theory_lq = uicontrol(fig_lq,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','lqcontr(''theory_lq'');');

	hint_lq = uicontrol(fig_lq,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','lqcontr(''hints_lq'');');

	clear_lq = uicontrol(fig_lq,'Style','Push',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'String','Clear plots',...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','lqcontr(''lqclear'');');

	close_lq = uicontrol(fig_lq,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','lqcontr(''close_lq_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_lq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	system_lq = uicontrol(fig_lq,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.8667 0.2679 0.0595 ],  ...
	'string',...
	'Select system|Double integrator|(z+0.5)/(z^2-z+0.3)|(z+1.3)/(z^2-z+0.3)');
	set(system_lq,'Callback','lqcontr(''system'');');


	frame_ra = uicontrol(fig_lq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2180 0.3950 0.2950 0.1100 ]);

	sli_ra = uicontrol(fig_lq,'Style','slider',...
	'Units', 'Normalized','Position', [0.2571 0.4024 0.2143 0.0476 ],  ...
	'Min',0,'Max',10,...
	'Value',5,'Callback','lqcontr(''lqslid'');');

	ra_cur = uicontrol(fig_lq,'Style','edit',...
	'Units', 'Normalized','Position', [0.4179 0.4500 0.0893 0.0476 ],  ...
	'String',num2str(get(sli_ra,'Val')),...
	'Callback','lqcontr(''lqedit'');');

	ra_min = uicontrol(fig_lq,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4024 0.0357 0.0476 ],  ...
	'String',num2str(get(sli_ra,'Min')));

	ra_max = uicontrol(fig_lq,'Style','text',...
	'Units', 'Normalized','Position', [0.4714 0.4024 0.0357 0.0476 ],  ...
	'String',num2str(get(sli_ra,'Max')));

	ra_label = uicontrol(fig_lq,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4500 0.1964 0.0476 ],  ...
	'String','Weighting rho=');

	error_lq = uicontrol(fig_lq,'Style','text',...
	'Units', 'Normalized', 'Position', [0.2304 0.2357 0.2679 0.0952 ], ...
	'String',...
	'Ra must not be zero!',...
	'BackgroundColor','r');
	set(error_lq,'Visible','off');


%%----------- 2:nd WINDOW -------------------------------------

	figure(fig2_lq);

	%-- create diagram for step response
	step_axes_lq = subplot(211);
	hold on;
	grid on;
	set(step_axes_lq, 'XLim',[0 20],'YLim'...
	, [-0.1 2],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Step response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for control signal
	control_axes_lq = subplot(212);
	hold on;
	grid on;
	set(control_axes_lq, 'XLim',[0 20],'YLim'...
	, [-0.4 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Control signal','Color','k',...
	'FontName','Times','Fontsize',11);
	figure(fig_lq);

	watchoff;


%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_lq'),
	[existFlag,figNumber]=figflag('LQ-control');
    	if existFlag,
		close(fig_lq);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, LQ-control');
    	if existFlag,
		close(fig2_lq);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_lq_def'),
	[existFlag,figNumber]=figflag('LQ-control');
    	if existFlag,
		close(fig_lq);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, LQ-control');
    	if existFlag,
		close(fig2_lq);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

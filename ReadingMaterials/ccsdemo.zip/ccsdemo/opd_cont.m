function [ret,x0,str,ts,xts]=pd_cont(t,x,u,flag);
%PD_CONT	is the M-file description of the SIMULINK system named PD_CONT.
%	The block-diagram can be displayed by typing: PD_CONT.
%
%	SYS=PD_CONT(T,X,U,FLAG) returns depending on FLAG certain
%	system values given time point, T, current state vector, X,
%	and input vector, U.
%	FLAG is used to indicate the type of output to be returned in SYS.
%
%	Setting FLAG=1 causes PD_CONT to return state derivatives, FLAG=2
%	discrete states, FLAG=3 system outputs and FLAG=4 next sample
%	time. For more information and other options see SFUNC.
%
%	Calling PD_CONT with a FLAG of zero:
%	[SIZES]=PD_CONT([],[],[],0),  returns a vector, SIZES, which
%	contains the sizes of the state vector and other parameters.
%		SIZES(1) number of states
%		SIZES(2) number of discrete states
%		SIZES(3) number of outputs
%		SIZES(4) number of inputs
%		SIZES(5) number of roots (currently unsupported)
%		SIZES(6) direct feedthrough flag
%		SIZES(7) number of sample times
%
%	For the definition of other parameters in SIZES, see SFUNC.
%	See also, TRIM, LINMOD, LINSIM, EULER, RK23, RK45, ADAMS, GEAR.

% Note: This M-file is only used for saving graphical information;
%       after the model is loaded into memory an internal model
%       representation is used.

% the system will take on the name of this mfile:
sys = mfilename;
new_system(sys)
simver(1.3)
if (0 == (nargin + nargout))
     set_param(sys,'Location',[194,462,1010,770])
     open_system(sys)
end;
set_param(sys,'algorithm',     'RK-45')
set_param(sys,'Start time',    '0.0')
set_param(sys,'Stop time',     '999999')
set_param(sys,'Min step size', '0.0001')
set_param(sys,'Max step size', '10')
set_param(sys,'Relative error','1e-3')
set_param(sys,'Return vars',   '')
set_param(sys,'AssignSampleTimeColors','on');
set_param(sys,'AssignWideVectorLines','on');

add_block('built-in/Zero-Order Hold',[sys,'/','ZoH3'])
set_param([sys,'/','ZoH3'],...
		'Drop Shadow',4,...
		'Sample time','h',...
		'position',[105,124,140,156])

add_block('built-in/Step Fcn',[sys,'/','Step Input'])
set_param([sys,'/','Step Input'],...
		'hide name',0,...
		'Drop Shadow',4,...
		'Time','0',...
		'position',[30,130,50,150])

add_block('built-in/Zero-Order Hold',[sys,'/','ZoH1'])
set_param([sys,'/','ZoH1'],...
		'Drop Shadow',4,...
		'Sample time','h',...
		'position',[415,119,450,151])

add_block('built-in/Zero-Order Hold',[sys,'/','ZoH2'])
set_param([sys,'/','ZoH2'],...
		'Drop Shadow',4,...
		'Sample time','h',...
		'position',[355,144,390,176])

add_block('built-in/Gain',[sys,'/','K'])
set_param([sys,'/','K'],...
		'hide name',0,...
		'Gain','k',...
		'position',[220,135,250,165])

add_block('built-in/Gain',[sys,'/','1'])
set_param([sys,'/','1'],...
		'orientation',2,...
		'hide name',0,...
		'position',[300,265,330,295])


%     Subsystem  ['Double',13,' integrator'].

new_system([sys,'/',['Double',13,' integrator']])
set_param([sys,'/',['Double',13,' integrator']],'Location',[425,490,618,646])

add_block('built-in/Outport',[sys,'/',['Double',13,' integrator/out_2']])
set_param([sys,'/',['Double',13,' integrator/out_2']],...
		'Port','2',...
		'position',[170,100,190,120])

add_block('built-in/Inport',[sys,'/',['Double',13,' integrator/in_1']])
set_param([sys,'/',['Double',13,' integrator/in_1']],...
		'position',[30,60,50,80])

add_block('built-in/Outport',[sys,'/',['Double',13,' integrator/out_1']])
set_param([sys,'/',['Double',13,' integrator/out_1']],...
		'position',[170,60,190,80])

add_block('built-in/Integrator',[sys,'/',['Double',13,' integrator/x6']])
set_param([sys,'/',['Double',13,' integrator/x6']],...
		'position',[80,60,100,80])

add_block('built-in/Integrator',[sys,'/',['Double',13,' integrator/x5']])
set_param([sys,'/',['Double',13,' integrator/x5']],...
		'position',[125,60,145,80])
add_line([sys,'/',['Double',13,' integrator']],[55,70;75,70])
add_line([sys,'/',['Double',13,' integrator']],[105,70;120,70])
add_line([sys,'/',['Double',13,' integrator']],[150,70;165,70])
add_line([sys,'/',['Double',13,' integrator']],[105,70;105,110;165,110])


%     Finished composite block ['Double',13,' integrator'].

set_param([sys,'/',['Double',13,' integrator']],...
		'Drop Shadow',4,...
		'position',[270,122,300,173])

add_block('built-in/Sum',[sys,'/','Sum1'])
set_param([sys,'/','Sum1'],...
		'hide name',0,...
		'Drop Shadow',4,...
		'inputs','+--',...
		'position',[185,132,205,168])

add_block('built-in/Gain',[sys,'/','Td'])
set_param([sys,'/','Td'],...
		'orientation',2,...
		'hide name',0,...
		'Drop Shadow',4,...
		'Gain','td',...
		'position',[220,210,250,240])

add_block('built-in/To Workspace',[sys,'/','Step response'])
set_param([sys,'/','Step response'],...
		'mat-name','outputd',...
		'position',[500,127,550,143])

add_block('built-in/To Workspace',[sys,'/','Control signal'])
set_param([sys,'/','Control signal'],...
		'mat-name','contr',...
		'position',[290,62,340,78])

add_block('built-in/To Workspace',[sys,'/','Step response_'])
set_param([sys,'/','Step response_'],...
		'mat-name','output',...
		'position',[430,57,480,73])
add_line(sys,[455,135;465,135;465,280;335,280])
add_line(sys,[305,135;410,135])
add_line(sys,[395,160;405,160;405,225;255,225])
add_line(sys,[305,160;350,160])
add_line(sys,[295,280;150,280;150,150;180,150])
add_line(sys,[215,225;160,225;160,160;180,160])
add_line(sys,[210,150;215,150])
add_line(sys,[255,150;265,150])
add_line(sys,[455,135;495,135])
add_line(sys,[145,140;180,140])
add_line(sys,[55,140;100,140])
add_line(sys,[255,150;260,150;260,70;285,70])
add_line(sys,[305,135;365,135;365,65;425,65])

drawnow

% Return any arguments.
if (nargin | nargout)
	% Must use feval here to access system in memory
	if (nargin > 3)
		if (flag == 0)
			eval(['[ret,x0,str,ts,xts]=',sys,'(t,x,u,flag);'])
		else
			eval(['ret =', sys,'(t,x,u,flag);'])
		end
	else
		[ret,x0,str,ts,xts] = feval(sys);
	end
else
	drawnow % Flash up the model and execute load callback
end

function noise(operation);
% NOISE 	Module illustrating stochastic processes.
%		Author: Helena Haglund
%               Revised: Bjorn Wittenmark
%		LastEditDate : January 3, 1997
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_noise fig2_noise ccs_col fig_ccs
global system_noise error_noise
global Bd Ad h
global pole zero x y
global disc_axes_noise
global lgw1 lgw2 n w i tau wvec t
global ry C fr e
global a1 a2 b1 Bd1 K
global cov_handle spectr_handle realiz_handle
global cov_axes spectrum_axes realization_axes

if nargin == 0,
	operation = 'show';
end;

%-- checks if window already exists
if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Noise');
	if ~existFlag,
      		noise('winit_noise');
      		noise('init_noise');	
 		[existFlag,figNumber]=figflag('Noise');
	else
		clf;
		noise('init_noise');
	end;


%%------------------- SYSTEM ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'system'),

	watchon;
	figure(fig_noise);
	set(error_noise,'Visible','off');
	h = 1;

	%-- make plots go clear after next updating
	set(cov_handle,'EraseMode','XOR');
	set(spectr_handle,'EraseMode','XOR');
	set(realiz_handle,'EraseMode','XOR');

	if get(system_noise,'value')==1,
		axes(disc_axes_noise);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;			
		plot(sin(t),cos(t),'k-');
		axes(cov_axes);
		cla;
		axes(spectrum_axes);
		cla;
		axes(realization_axes);
		cla;
	elseif get(system_noise,'value')==2,

		Ad = [1 -0.5];
		a1 = -0.5;
		% ---gives var(y)=1
		Bd_test = 0;
                Bd1 = 1;
		Bd = sqrt(1-a1^2);
		[phi,gam,C,D] = tf2ss(Bd,Ad);     

	elseif get(system_noise,'Value')==3,

		Ad = [1 -0.3 0.1];
		Bd1 = [1 -0.5];
		a1 = -0.3;
		a2 = 0.1;
		b1 = -0.5;
		% ---gives var(y)=1
		Bd_test = 0;
		vary = ((1+b1^2)*(1+a2)-2*b1*a1)/((1-a2^2)*(1+a2)-(a1-a1*a2)*a1);
		K = 1/sqrt(vary);
		Bd = K*Bd1;
		[phi,gam,C,D] = tf2ss(Bd,Ad); 
	end;

	if get(system_noise,'Value') ==2|get(system_noise,'Value') ==3|...
	get(system_noise,'Value') ==4,

		axes(disc_axes_noise);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;			
		plot(sin(t),cos(t),'k-');

		%-- plot poles and zeros of sampled system
		if ccs_col == 1,
			pole = plot(real(roots(Ad)),imag(roots(Ad)),'rx');
			set(pole,'Linewidth',2,'EraseMode','XOR', ...
				'Markersize',10);
			zero = plot(real(roots(Bd)),imag(roots(Bd)),'ro');
			set(zero,'Linewidth',2,'EraseMode','XOR',...
				'Markersize',7);
		else
			pole = plot(real(roots(Ad)),imag(roots(Ad)),'kx');
			set(pole,'Linewidth',2,'EraseMode','XOR', ...
				'Markersize',10);
			zero = plot(real(roots(Bd)),imag(roots(Bd)),'ko');
			set(zero,'Linewidth',2,'EraseMode','XOR',...
				'Markersize',7);
		end;

		%-- makes poles movable
		set(pole,'ButtonDownFcn','noise(''move_p'')');
		set(zero,'ButtonDownFcn','noise(''move_z'')');

		%-- calculates covariance function
		ry = zeros(20,1);
		tau = 20;
		rx   = dlyap(phi,gam*gam');
		ry(1) = C*rx*C';
		for k=1:tau,
			rx = phi*rx;
			ry(k+1) = C*rx*C'; 
		end;
		axes(cov_axes);

		%-- plot covariance function
		set(cov_handle,'XData',0:tau,'YData',ry);
		set(cov_handle,'LineWidth',2,'EraseMode','None');

		%-- calculate spectrum
		lgw1 = -2;
		n = 50;
   		w = logspace(lgw1,pi,n)';
		i = sqrt(-1);
		tau1 = zeros(size(Ad)*[1;0],1);
		wvec = exp(i*w*h);
		na = size(Ad)*[1;0];
		nb = size(Bd)*[1;0];
		nt = length(tau1);
		maxn = max([na nb nt]);
   		if na==1, 
			Ad = kron(Ad,ones(maxn,1));	
		end;
  		if nb==1, 
			Bd = kron(Bd,ones(maxn,1)); 
		end
  		if nt==1, 
			tau1 = kron(tau1,ones(maxn,1));
		end 

 		gvec = zeros(length(wvec),maxn); 
 		for k=1:maxn,
  			gvec(:,k) = ...
    			exp(-tau1(k)*wvec(:)).*...
			polyval(Bd(k,:),wvec(:))./polyval(Ad(k,:),wvec(:))/(2*pi);
		end
		fr = [w gvec];
 
		%-- plot spectrum
		axes(spectrum_axes);
		set(spectr_handle,'XData',fr(:,1),'YData',abs(fr(:,2)));
		set(spectr_handle,'LineWidth',2,'EraseMode','None');

		%-- calculate realization
		axes(realization_axes);

		%-- white noise			
		e = randn(1,50);
		y = filter(Bd,Ad,e);
		t=0:49;
		%-- plot realization
		set(realiz_handle,'XData',t,'YData',y);
		set(realiz_handle,'LineWidth',2,'EraseMode','None');
 
	end;

	axes(disc_axes_noise);
	figure(fig_noise);
	watchoff;


%%--------------- MOVING POLES -----------------------------
%%----------------------------------------------------------

elseif strcmp(operation,'move_p'),

	set(fig_noise, 'WindowButtonMotionFcn', ...
	'noise(''moving_p'');', ...
                  'WindowButtonUpFcn', ...
        'noise(''moved_p'');');

elseif strcmp(operation,'moving_p'),

	currpoint = get(disc_axes_noise, 'CurrentPoint');
	x = currpoint(1,1);
	y = currpoint(1,2);
	if get(system_noise,'Value')==2,
	if ccs_col == 1,
		set(pole, 'XData', x, 'YData', 0,'Color','r');
	else
		set(pole, 'XData', x, 'YData', 0,'Color','k');
	end
	elseif get(system_noise,'Value')==3,		
	if ccs_col == 1,
		set(pole, 'XData', [x x], 'YData', [y -y],'Color','r');
	else
		set(pole, 'XData', [x x], 'YData', [y -y],'Color','k');
	end;
	end;

elseif strcmp(operation,'moved_p'),  	

	%-- update plots after completed move
	if get(system_noise,'Value')==2,
	if ccs_col == 1,
		set(pole, 'XData', x, 'YData', 0,'Color','r');
	else
		set(pole, 'XData', x, 'YData', 0,'Color','k');
	end;
		Ad = [1 -x];
		a1 = -x;
		% ---test stability
		if (abs(x)>=1) 
                        Bd_test = 1; Bd = Bd1;
                else
		% ---gives var(y)=1
                        Bd_test = 0; Bd = abs(sqrt(1-a1^2));
                end;
		elseif get(system_noise,'Value')==3,			
		if ccs_col == 1,
			set(pole, 'XData', [x x], 'YData', [y -y],'Color','r');
		else
			set(pole, 'XData', [x x], 'YData', [y -y],'Color','k');
		end;
		Ad = [1 -2*x x^2+y^2];
		a1 = -2*x;
		a2 = x^2+y^2;
		% ---test stability
		if (max(abs(roots(Ad)))>=1)
                        Bd_test = 1; Bd = Bd1;
                else
                        Bd_test = 0;               
		% ---gives var(y)=1
		 	vary = ((1+b1^2)*(1+a2)-2*b1*a1)/((1-a2^2)...
			*(1+a2)-(a1-a1*a2)*a1);
    			K = 1/sqrt(vary);
			Bd = K*Bd1;
		end;
		[phi,gam,C,D] = tf2ss(Bd,Ad);
	end;
	%-- warning message if system is unstable
	if (Bd_test==1 & get(system_noise,'Value')==2)|...
	(Bd_test==1 & get(system_noise,'Value')==3),
		set(error_noise,'Visible','on');
	else
		set(error_noise,'Visible','off');		
	end;

	[phi,gam,C,D] = tf2ss(Bd,Ad);
	set(fig_noise, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');

	%-- covariance function and spectrum if system is stable
	if Bd_test==0,
		%-- calculate covariance function
	        rx   = dlyap(phi,gam*gam');
		ry(1) = C*rx*C';
		for k=1:tau,
			rx = phi*rx;
			ry(k+1) = C*rx*C'; 
		end;

		%-- plot covariance function
		axes(cov_axes);

		set(cov_handle,'XData',0:tau,'YData',ry);

		%-- calculate spectrum
		tau1 = zeros(size(Ad)*[1;0],1);
		na = size(Ad)*[1;0];
		nb = size(Bd)*[1;0];
		nt = length(tau1);
		maxn = max([na nb nt]);
	   	if na==1, 
			Ad = kron(Ad,ones(maxn,1));	
		end;
	  	if nb==1, 
			Bd = kron(Bd,ones(maxn,1)); 
		end
	  	if nt==1, 
			tau1 = kron(tau1,ones(maxn,1));
		end 

	 	gvec = zeros(length(wvec),maxn); 
	 	for k=1:maxn,
	  		gvec(:,k) = ...
	    		exp(-tau1(k)*wvec(:)).*...
			polyval(Bd(k,:),wvec(:))./polyval(Ad(k,:),wvec(:))/(2*pi);
		end
		fr = [w gvec];

		%-- plot spectrum
		axes(spectrum_axes);
		set(spectr_handle,'XData',fr(:,1),'YData',abs(fr(:,2)));
	end;

	%-- calculate and plot realization
	axes(realization_axes);

	y = filter(Bd,Ad,e);
	t=0:49;
	set(realiz_handle,'XData',t,'YData',y);
 
	axes(disc_axes_noise);
	figure(fig_noise);
	watchoff;



%%--------------- MOVING ZEROS -----------------------------
%%----------------------------------------------------------

elseif strcmp(operation,'move_z'),
	set(fig_noise, 'WindowButtonMotionFcn', ...
	'noise(''moving_z'');', ...
                  'WindowButtonUpFcn', ...
        'noise(''moved_z'');');

elseif strcmp(operation,'moving_z'),
	currpoint = get(disc_axes_noise, 'CurrentPoint');
	x = currpoint(1,1);
	y = currpoint(1,2);
	set(zero, 'XData', x, 'YData', 0);


elseif strcmp(operation,'moved_z'),  	

	%-- update plots after completed move
	watchon;
	set(zero, 'XData', x, 'YData', 0);
	Bd1 = [1 -x];
	b1 = -x;
	% ---test stability
	if (max(abs(roots(Ad)))>=1)
           	Bd_test = 1; Bd = Bd1;
    	else
          	Bd_test = 0;               
		% ---gives var(y)=1
		vary = ((1+b1^2)*(1+a2)-2*b1*a1)/((1-a2^2)...
		*(1+a2)-(a1-a1*a2)*a1);
		K = 1/sqrt(vary);
		Bd = K*Bd1;
	end;
	[phi,gam,C,D] = tf2ss(Bd,Ad);

	set(fig_noise, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');

	%-- covariance function and spectrum if system is stable
	if Bd_test==0,
		%-- calculate covariance function
		rx   = dlyap(phi,gam*gam');
		ry(1) = C*rx*C';
		for k=1:tau,
			rx = phi*rx;
			ry(k+1) = C*rx*C'; 
		end;

		%-- plot covariance function
		axes(cov_axes);
		set(cov_handle,'XData',0:tau,'YData',ry);		

		%-- calculate spectrum
		tau1 = zeros(size(Ad)*[1;0],1);
		na = size(Ad)*[1;0];
		nb = size(Bd)*[1;0];
		nt = length(tau1);
		maxn = max([na nb nt]);
	   	if na==1, 
			Ad = kron(Ad,ones(maxn,1));	
		end;
	  	if nb==1, 
			Bd = kron(Bd,ones(maxn,1)); 
		end
	  	if nt==1, 
			tau1 = kron(tau1,ones(maxn,1));
		end 

	 	gvec = zeros(length(wvec),maxn); 
 		for k=1:maxn,
	  		gvec(:,k) = ...
	    		exp(-tau1(k)*wvec(:)).*...
			polyval(Bd(k,:),wvec(:))./polyval(Ad(k,:),wvec(:))/(2*pi);
		end
		fr = [w gvec];

		%-- plot spectrum 
		axes(spectrum_axes);

		set(spectr_handle,'XData',fr(:,1),'YData',abs(fr(:,2)));
	end;
	%-- calculate and plot realization
	axes(realization_axes);

	y = filter(Bd,Ad,e);
	t=0:49;
	set(realiz_handle,'XData',t,'YData',y);
 
	axes(disc_axes_noise);
	figure(fig_noise);
	watchoff;

%%------------------ CLEAR --------------------------------
%%---------------------------------------------------------

elseif strcmp(operation,'noiseclear'),

	if get(system_noise,'Value') ==2|get(system_noise,'Value') ==3|...
	get(system_noise,'Value') ==4,

		%-- plot most resent covariance function
		axes(cov_axes);
		cla;
		if ccs_col == 1,
			cov_handle = plot(0:tau, ry,'r');
		else
			cov_handle = plot(0:tau, ry,'k');
		end;	
		set(cov_handle,'LineWidth',2,'EraseMode','None');

		%-- plot most resent spectrum
		axes(spectrum_axes);
		cla;
		if ccs_col == 1,
			spectr_handle = loglog(fr(:,1),abs(fr(:,2)),'r');
		else
			spectr_handle = loglog(fr(:,1),abs(fr(:,2)),'k');
		end;
		set(spectr_handle,'LineWidth',2,'EraseMode','None');
	

		%-- plot most resent realization
		axes(realization_axes);
		cla;
		if ccs_col == 1,				
			realiz_handle = plot(t,y,'r');
		else
			realiz_handle = plot(t,y,'k');
		end;
		set(realiz_handle,'LineWidth',2,'EraseMode','None');
		figure(fig_noise);
		axes(disc_axes_noise);

	end;

%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_noise'),
   ttlStr='Noise help...';
    hlpStr= ...                                           
        ['                                             '  
         ' This demo illustrates how the covariance    '
	 ' function, the spectrum and the realization  '
	 ' varies when white noise is filtered through '
	 ' systems with different transfer functions.  '
	 ' Only the realization is calculated when     '
 	 ' the system is unstable.                     '
	 '                                             '
	 ' Two different types of systems are used. The'
	 ' first one has no zeros and one pole. The se-'
	 ' cond one has one zero and two poles. The    '
	 ' poles and zeros can be moved in a pole-zero '
	 ' plot. In this way, systems with various pro-'
	 ' perties can be achieved.                    '
	 '                                             '
	 ' The transfer functions are normalized so    '
	 ' that the output variance is 1, when the     '
	 ' system is stable.                           '];
   

    hwin(ttlStr,hlpStr);


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_noise'),
   ttlStr='Noise theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Chapter 10 in CCS p. 370 for reading    '  
         ' about Disturbance models.                   '   
    	 '                                             '
	 ' See Chapter 10 p. 370-381 for more about    '
	 ' these types of plots.                       '];

    hwin(ttlStr,hlpStr);


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_noise'),
   ttlStr='Noise hints...';
    hlpStr= ...                                           
        ['                                             '  
         ' Choose system 2. Move the poles and the zero'
	 ' to the origin, i.e. the process is a pure   '
	 ' delay, H(z)=z/z^2. The white noise passes   '
	 ' unaffected. The covariance is a delta-func- '
	 ' tion and the spectrum is flat.              '
	 '                                             '
	 ' Compare this with a system where the poles  '
	 ' are situated near the unit circle. In this  '
	 ' case, it takes a longer time for the covari-'
	 ' ance to settle to zero  and the spectrum im-'
 	 ' plies much lower damping.                   '];


    hwin(ttlStr,hlpStr);    
       

%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_noise'),

	%-- create main window
	fig_noise = figure('Name',...
	'Noise','NumberTitle','off',...
	'Units', 'Normalized',...
	'Position', [0.2561 0.4400 0.4861 0.4667 ],... 
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_noise,'Color',[0.8 0.8 0.8]);


elseif strcmp(operation,'init_noise'),
	watchon;

	figure(fig_noise);


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_noise,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_noise = uicontrol(fig_noise,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'Callback','noise(''close_noise'');');

	help_noise = uicontrol(fig_noise,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','noise(''help_noise'');');

	theory_noise = uicontrol(fig_noise,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','noise(''theory_noise'');');

	hint_noise = uicontrol(fig_noise,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ], ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','noise(''hints_noise'');');

%	clear_noise = uicontrol(fig_noise,'Style','Push',...
%	'String','Clear plots',...
%	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
%	'BackgroundColor',[0.5 1 0.5],...
%	'Callback','noise(''noiseclear'');');

	close_noise = uicontrol(fig_noise,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','noise(''close_noise_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_noise,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.7119 0.3214 0.2619 ]);

	system_noise = uicontrol(fig_noise,'Style','popup',...
	'Units', 'Normalized','Position', [0.2214 0.8667 0.2857 0.0595 ],  ...
	'string',...
	'Select system|b/(z+a)|(b0z+b1)/(z^2+a1*z+a2)');
	set(system_noise,'Callback','noise(''system'');');

	%-- create pole/zero axes
	disc_axes_noise = axes('position',[0.23 0.15 0.28 0.28]);
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	title('Poles/Zeros','Color','k',...
	'FontName','Times','Fontsize',11);
	set(disc_axes_noise,'XLim',[-1.05 1.05],'YLim',[-1.05 1.05],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','YTick',[-1 0 1],'DrawMode','Fast',...
	'Xcolor','k','Ycolor','k',...
	'FontName','Times','Fontsize',11);
	hold on;

	%-- create covariance diagram
	cov_axes = axes('Position',[0.6 0.71 0.35 0.22]);
	grid on;
	set(cov_axes, 'XLim',[0 20],'YLim'...
	, [-1 2], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k', ...
	'FontName','Times','Fontsize',11);
	title('Covariance function','Color','k',...
	'FontName','Times','Fontsize',11);
	hold on;

	%-- create spectrum diagram
	spectrum_axes = axes('Position',[0.6 0.39 0.35 0.22]);
	grid on;
	set(spectrum_axes,'XLim',[0.01 4],'YLim',[0.01 5],...
	'XScale','log','YScale','log','XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Spectrum','Color','k',...
	'FontName','Times','Fontsize',11);	
	hold on;		

	%-- create realization diagram
	realization_axes = axes('Position',[0.6 0.05 0.35 0.22]);
	grid on;
	set(realization_axes, 'XLim',[0 50],'YLim'...
	, [-5 5], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Realization','Color','k',...
	'FontName','Times','Fontsize',11);
	hold on;

	%-- creat handles
	axes(cov_axes);
	if ccs_col == 1,
		cov_handle = plot(NaN,NaN,'r');
		axes(spectrum_axes);
		spectr_handle = loglog(NaN,NaN,'r');
		axes(realization_axes);
		realiz_handle = plot(NaN,NaN,'r');
	else
		cov_handle = plot(NaN,NaN,'k');
		axes(spectrum_axes);
		spectr_handle = loglog(NaN,NaN,'k');
		axes(realization_axes);
		realiz_handle = plot(NaN,NaN,'k');
	end;
	
	watchoff;


%%----------------- ERROR MESSAGE --------------------------------

	error_noise = uicontrol(fig_noise,'Style','text',...
	'Units', 'Normalized','Position', [0.2304 0.5202 0.2679 0.0950 ],  ...
	'String',...
	'Unstable system!','Fontsize',12, ...
	'BackgroundColor','r');
	set(error_noise,'Visible','off');


%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_noise'),

	[existFlag,figNumber]=figflag('Noise');
    	if existFlag,
		close(fig_noise);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_noise_def'),

	[existFlag,figNumber]=figflag('Noise');
    	if existFlag,
		close(fig_noise);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

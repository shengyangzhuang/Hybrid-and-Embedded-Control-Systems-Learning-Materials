function [sys,x0]= rstdes3(t,x,u,flag,inta,cancela,Aoa,Ama)
 

    if flag==0
      sys=[0 0 12 8 0 1];
      x0=[];

    elseif flag==3

		Bd=[u(1) u(2)];
		Ad=[1 u(3) u(4)];
		if cancela == 0,
			bminus = Bd;		% NO CANCELLATION OF ZEROS
			bplus = 1;
		else
			bminus = Bd(1);		% CANCELLATION OF ZEROS
			if length(Bd) == 1,
				bplus = 1;
			else
				bplus = [1 Bd(2)/Bd(1)];
			end;
		end;	
		if inta==1,	% INTEGRATOR
			Ar = [1 -1];	
			l = 1;
		else        			% NO INTEGRATOR
			Ar = 1;
			l = 0;
		end;
	

						% RST DESIGN
	        [R,S,T]=rstd(bplus,bminus,Ad,1,Ama,Aoa,Ar);
       
                if cancela==0
                  R=[R 0];
                  S=[S 0];
                  T=[T 0];
                end
                  [sss,ttt]=size(S);
                  S=[zeros(1,4-ttt) S];		% NORMATION TO 3:RD DEGREE
                  [sss,ttt]=size(T);
                  T=[zeros(1,4-ttt) T];


                sys=[R S T];


     else
        sys=[];
    end;

function numerics(operation);
% NUMERICS	Module illustrating differences between diagonal
%		and controllable form.
%		
%		A 4:th order system is given in either form and
%		can then be examined according to location of 
%		poles and step response.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_par ccs_col fig_ccs
global a1_diag a2_diag a3_diag a4_diag
global a1_diag0 a2_diag0 a3_diag0 a4_diag0
global a1_contr a2_contr a3_contr a4_contr
global a1_cur a2_cur a3_cur a4_cur
global sli_a1 sli_a2 sli_a3 sli_a4
global a1_min a2_min a3_min a4_min
global a1_max a2_max a3_max a4_max
global a1_label a2_label a3_label a4_label
global input_a1 input_a2 input_a3 input_a4 edit_label1 edit_label2
global frame_a1 frame_a2 frame_a3 frame_a4
global a1 a2 a3 a4 
global tr_axes
global ad bd ad1 bd1 A1 B1 C1 D1 ad0 bd0 y0 y
global ready change
global form formel error_num
global ed text1_diag text2_diag text1_contr text2_contr
	 
if nargin == 0,
	operation = 'show';
end;

%-- checks if the window already exists
if strcmp(operation,'show'),
    [existFlag,figNumber]=figflag('Numerics');
    if ~existFlag,
        numerics('winit');
	numerics('init');
        [existFlag,figNumber]=figflag('Numerics');
    else
	clf;
	numerics('init');
    end;


%%------------------ DIAGONAL  FORM ------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'diag_form'),
	watchon;

	%-- roots of current system
	root = [a1_diag a2_diag a3_diag a4_diag];
	imag_root = imag(root);
	for number=1:4,
		if abs(imag_root(number))<0.001,
			imag_root(number)=0;
		end;
	end;
	imag_root = [imag_root(1) imag_root(2) imag_root(3) imag_root(4)];
		
	if imag_root==[0 0 0 0],

		a1_diag=real(a1_diag);
		a2_diag=real(a2_diag);
		a3_diag=real(a3_diag);
		a4_diag=real(a4_diag);

		set(input_a1,'String',num2str(a1_diag));
		set(input_a2,'String',num2str(a2_diag));
		set(input_a3,'String',num2str(a3_diag));
		set(input_a4,'String',num2str(a4_diag));

		formel = 1;

		%-- calculate polynomials	
		ad = poly(root);ad0 = ad;
		bd =sum(ad);bd0 = bd;
		a1_contr = ad(2);
		a2_contr = ad(3);
		a3_contr = ad(4);
		a4_contr = ad(5);

		%-- transfer to state-space form
		[A,B,C,D] = tf2ss(bd,ad);

		subplot(222);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		%-- plot poles
		if ccs_col == 1,
			poles_num = plot(real(roots(ad)),imag(roots(ad)),'rx');
			set(poles_num,'Linewidth',2,'Markersize',9);
		else
			poles_num = plot(real(roots(ad)),imag(roots(ad)),'kx');
			set(poles_num,'Linewidth',2,'Markersize',9);
		end;

		%-- simulate step response
		y = dstep(bd,ad,100);y0 =y;

		%-- plot step response	
		subplot(224);
		cla;
		if ccs_col == 1,
			plot(y,'r','Linewidth',2);
		else
			plot(y,'k','Linewidth',2);
		end;
	else
		set(error_num,'Visible','on');
		set(form,'Value',2);

	end;
		watchoff;

%%-------------------CONTROLLABLE FORM ------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'contr_form'),
	watchon;

	set(input_a1,'String',num2str(a1_contr));
	set(input_a2,'String',num2str(a2_contr));
	set(input_a3,'String',num2str(a3_contr));
	set(input_a4,'String',num2str(a4_contr));

	formel = 0;

	%-- polynomials
	ad = [1 a1_contr a2_contr a3_contr a4_contr];ad0 = ad;
	root=roots(ad);

	a1_diag = root(1);
	a2_diag = root(2);
	a3_diag = root(3);
	a4_diag = root(4);

	%-- make static gain equal to one
	bd =sum(ad);bd0 = bd;

	%-- transfer to state-space form
	[A,B,C,D] = tf2ss(bd,ad);

	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot poles
	if ccs_col == 1,
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'rx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	else
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'kx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response
	y = dstep(bd,ad,100);y0 = y;

	%-- plot step response	
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y,'r','Linewidth',2);
	else
		plot(y,'k','Linewidth',2);
	end;
		watchoff;


%%------------------- CLEAR ----------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'recalc'),
 
	watchon;
	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot nominal poles and zeros
	if ccs_col == 1,
		p = plot(real(roots(ad0)),imag(roots(ad0)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- plot nominal step response
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y0,'r','Linewidth',2);
	else
		plot(y0,'k','Linewidth',2);
	end;
 
	%-- plot most resent poles
	subplot(222);
	if ccs_col == 1,
		p = plot(real(roots(ad)),imag(roots(ad)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		p = plot(real(roots(ad)),imag(roots(ad)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- plot most resent step response	
	subplot(224);
	if ccs_col == 1,
		plot(y,'r','Linewidth',2);
	else
		plot(y,'k--','Linewidth',2);
	end;
	watchoff;


%%---------------CHANGING VALUES ------------------------------
%%-------------------------------------------------------------

elseif strcmp(operation,'editing'),

	watchon;
		
	set(error_num,'Visible','off');

	%-- update values
	a1 = str2num(get(input_a1,'String'));
	a2 = str2num(get(input_a2,'String'));
	a3 = str2num(get(input_a3,'String'));
	a4 = str2num(get(input_a4,'String'));

	if formel == 0,
		%-- polynomials if controllable form
		ad = [1 a1 a2 a3 a4];ad0 = ad;
		a1_contr = a1;
		a2_contr = a2;
		a3_contr = a3;
		a4_contr = a4;
		root = roots(ad);
		a1_diag = root(1);
		a2_diag = root(2);
		a3_diag = root(3);
		a4_diag = root(4);		  	
	elseif formel == 1,
		%-- polynomials if diagonal form
		root = [a1 a2 a3 a4];
		ad = poly(root);ad0 = ad;
		a1_diag = a1;
		a2_diag = a2;
		a3_diag = a3;
		a4_diag = a4;	
		a1_contr = ad(2);
		a2_contr = ad(3);
		a3_contr = ad(4);
		a4_contr = ad(5);  	
	end;

	%-- make static gain equal to one
	bd =sum(ad);bd0 = bd;
	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot poles
	if ccs_col == 1,
		p = plot(real(roots(ad)),imag(roots(ad)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		p = plot(real(roots(ad)),imag(roots(ad)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response
	y = dstep(bd,ad,100);y0 = y;

	%-- plot output	
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y,'y');
 	else
		plot(y,'k');
	end;
	watchoff;


%%----------------CHANGING SLIDER VALUES----------------------
%%------------------------------------------------------------

elseif strcmp(operation,'move_slid'),
	watchon;

	%-- set sliders to correct values	
	set(a1_cur,'String',num2str(get(sli_a1,'Value')));
	a1 = get(sli_a1,'Val');
	set(a2_cur,'String',num2str(get(sli_a2,'Value')));
	a2 = get(sli_a2,'Val');
	set(a3_cur,'String',num2str(get(sli_a3,'Value')));
	a3 = get(sli_a3,'Val');
	set(a4_cur,'String',num2str(get(sli_a4,'Value')));
	a4 = get(sli_a4,'Val');

	if formel == 0,
		%-- polynomials on controllable form	
		ad = [1 a1 a2 a3 a4];
	elseif formel == 1,
		%-- polynomials on diagonal form
		root = [a1 a2 a3 a4];	
		ad = poly(root);
	end;

	%-- make static gain equal to one
	bd =sum(ad);

	%-- transfer to stste-space form
	[A,B,C,D] = tf2ss(bd,ad);
	subplot(222);

	%-- plot poles
	if ccs_col == 1,
		p = plot(real(roots(ad)),imag(roots(ad)),'rx');	
		set(p,'Linewidth',2,'Markersize',9);
	else
		subplot(222);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');
		p = plot(real(roots(ad)),imag(roots(ad)),'kx');	
		set(p,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response
	y = dstep(bd,ad,100);

	%-- plot output	
	subplot(224);
	if ccs_col == 1,
		plot(y,'r','Linewidth',2);
	else
		plot(y,'k--','Linewidth',2);
	end;		
	watchoff;


%%------------------ SYSTEM -----------------------------------
%%-------------------------------------------------------------

elseif strcmp(operation,'syst_def'),
	watchon;

	set(error_num,'Visible','off');
	set(form,'Visible','off');

   	if get(form,'Value')==1,

		set(text1_diag,'Visible','on');
		set(text2_diag,'Visible','on');

		%-- set slider limits according to chosen value of parameter
		set(sli_a1,'Min',0.5*a1_diag,...
		'Max',1.5*a1_diag,'Value',a1_diag);
		set(sli_a2,'Min',0.5*a2_diag,...
		'Max',1.5*a2_diag,'Value',a2_diag);
		set(sli_a3,'Min',0.5*a3_diag,...
		'Max',1.5*a3_diag,'Value',a3_diag);
		set(sli_a4,'Min',0.5*a4_diag,...
		'Max',1.5*a4_diag,'Value',a4_diag);

		set(a1_min,'String',num2str(0.5*a1_diag));
		set(a1_max,'String',num2str(1.5*a1_diag));
		set(a2_min,'String',num2str(0.5*a2_diag));
		set(a2_max,'String',num2str(1.5*a2_diag));
		set(a3_min,'String',num2str(0.5*a3_diag));
		set(a3_max,'String',num2str(1.5*a3_diag));
		set(a4_min,'String',num2str(0.5*a4_diag));
		set(a4_max,'String',num2str(1.5*a4_diag));

	elseif get(form,'Value')==2,

		set(text1_contr,'Visible','on');
		set(text2_contr,'Visible','on');

		%-- set slider limits according to chosen value of parameter
		set(sli_a1,'Max',0.5*a1_contr,...
		'Min',1.5*a1_contr,'Value',a1_contr);
		set(sli_a2,'Min',0.5*a2_contr,...
		'Max',1.5*a2_contr,'Value',a2_contr);
		set(sli_a3,'Max',0.5*a3_contr,...
		'Min',1.5*a3_contr,'Value',a3_contr);
		set(sli_a4,'Min',0.5*a4_contr,...
		'Max',1.5*a4_contr,'Value',a4_contr);

		set(a1_min,'String',num2str(0.5*a1_contr));
		set(a1_max,'String',num2str(1.5*a1_contr));
		set(a2_min,'String',num2str(0.5*a2_contr));
		set(a2_max,'String',num2str(1.5*a2_contr));
		set(a3_min,'String',num2str(0.5*a3_contr));
		set(a3_max,'String',num2str(1.5*a3_contr));
		set(a4_min,'String',num2str(0.5*a4_contr));
		set(a4_max,'String',num2str(1.5*a4_contr));
	end;



	set(a1_cur,'String',num2str(get(sli_a1,'Value')));
	set(a2_cur,'String',num2str(get(sli_a2,'Value')));
	set(a3_cur,'String',num2str(get(sli_a3,'Value')));
	set(a4_cur,'String',num2str(get(sli_a4,'Value')));

	set(ready,'Visible','off');
	set(change,'Visible','on');
	set(input_a1,'Visible','off');
	set(input_a2,'Visible','off');
	set(input_a3,'Visible','off');
	set(input_a4,'Visible','off');
	set(edit_label1,'Visible','off');
	set(edit_label2,'Visible','off');
	set(sli_a1,'Visible','on');
	set(a1_cur,'Visible','on');
	set(a1_min,'Visible','on');
	set(a1_max,'Visible','on');
	set(a1_label,'Visible','on');
	set(sli_a2,'Visible','on');
	set(a2_cur,'Visible','on');
	set(a2_min,'Visible','on');
	set(a2_max,'Visible','on');
	set(a2_label,'Visible','on');
	set(sli_a3,'Visible','on');
	set(a3_cur,'Visible','on');
	set(a3_min,'Visible','on');
	set(a3_max,'Visible','on');
	set(a3_label,'Visible','on');
	set(sli_a4,'Visible','on');
	set(a4_cur,'Visible','on');
	set(a4_min,'Visible','on');
	set(a4_max,'Visible','on');
	set(a4_label,'Visible','on');
	set(frame_a1,'Visible','on');
	set(frame_a2,'Visible','on');
	set(frame_a3,'Visible','on');
	set(frame_a4,'Visible','on');

	watchoff;


%%--------------------- CHANGE SYSTEM ------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'change_syst'),

	watchon;
	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	%-- plot nominal poles and zeros
	if ccs_col == 1,
		p = plot(real(roots(ad0)),imag(roots(ad0)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	subplot(224);
	cla;
	%-- plot nominal step response
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y0,'r','Linewidth',2);
	else
		plot(y0,'k','Linewidth',2);
	end;
		
	set(form,'Visible','on');

	set(text1_diag,'Visible','off');
	set(text2_diag,'Visible','off');
	set(text1_contr,'Visible','off');
	set(text2_contr,'Visible','off');

	set(ready,'Visible','on');
	set(change,'Visible','off');
	set(input_a1,'Visible','on');
	set(input_a2,'Visible','on');
	set(input_a3,'Visible','on');
	set(input_a4,'Visible','on');
	set(edit_label1,'Visible','on');
	set(edit_label2,'Visible','on');
	set(sli_a1,'Visible','off');
	set(a1_cur,'Visible','off');
	set(a1_min,'Visible','off');
	set(a1_max,'Visible','off');
	set(a1_label,'Visible','off');
	set(sli_a2,'Visible','off');
	set(a2_cur,'Visible','off');
	set(a2_min,'Visible','off');
	set(a2_max,'Visible','off');
	set(a2_label,'Visible','off');
	set(sli_a3,'Visible','off');
	set(a3_cur,'Visible','off');
	set(a3_min,'Visible','off');
	set(a3_max,'Visible','off');
	set(a3_label,'Visible','off');
	set(sli_a4,'Visible','off');
	set(a4_cur,'Visible','off');
	set(a4_min,'Visible','off');
	set(a4_max,'Visible','off');
	set(a4_label,'Visible','off');
	set(frame_a1,'Visible','off');
	set(frame_a2,'Visible','off');
	set(frame_a3,'Visible','off');
	set(frame_a4,'Visible','off');
	watchoff;


%%------------------ RESET -----------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'reset_num'),
	watchon;

	set(error_num,'Visible','off');
	set(form,'Value',1);

	set(form,'Visible','on');

	set(text1_diag,'Visible','off');
	set(text2_diag,'Visible','off');
	set(text1_contr,'Visible','off');
	set(text2_contr,'Visible','off');

	set(ready,'Visible','on');
	set(change,'Visible','off');
	set(input_a1,'Visible','on');
	set(input_a2,'Visible','on');
	set(input_a3,'Visible','on');
	set(input_a4,'Visible','on');
	set(edit_label1,'Visible','on');
	set(edit_label2,'Visible','on');
	set(sli_a1,'Visible','off');
	set(a1_cur,'Visible','off');
	set(a1_min,'Visible','off');
	set(a1_max,'Visible','off');
	set(a1_label,'Visible','off');
	set(sli_a2,'Visible','off');
	set(a2_cur,'Visible','off');
	set(a2_min,'Visible','off');
	set(a2_max,'Visible','off');
	set(a2_label,'Visible','off');
	set(sli_a3,'Visible','off');
	set(a3_cur,'Visible','off');
	set(a3_min,'Visible','off');
	set(a3_max,'Visible','off');
	set(a3_label,'Visible','off');
	set(sli_a4,'Visible','off');
	set(a4_cur,'Visible','off');
	set(a4_min,'Visible','off');
	set(a4_max,'Visible','off');
	set(a4_label,'Visible','off');
	set(frame_a1,'Visible','off');
	set(frame_a2,'Visible','off');
	set(frame_a3,'Visible','off');
	set(frame_a4,'Visible','off');
	


	%-- roots of current system
	root = [a1_diag0 a2_diag0 a3_diag0 a4_diag0];
	a1_diag = a1_diag0;
	a2_diag = a2_diag0;
	a3_diag = a3_diag0;
	a4_diag = a4_diag0;
		
	set(input_a1,'String',num2str(a1_diag0));
	set(input_a2,'String',num2str(a2_diag0));
	set(input_a3,'String',num2str(a3_diag0));
	set(input_a4,'String',num2str(a4_diag0));

	formel = 1;

	%-- calculate polynomials	
	ad = poly(root);ad0 = ad;
	bd =sum(ad);bd0 = bd;
	a1_contr = ad(2);
	a2_contr = ad(3);
	a3_contr = ad(4);
	a4_contr = ad(5);

	%-- transfer to state-space form
	[A,B,C,D] = tf2ss(bd,ad);

	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot poles
	if ccs_col == 1,
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'rx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	else
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'kx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response
	y = dstep(bd,ad,100);y0 =y;

	%-- plot step response	
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y,'r','Linewidth',2);
	else
		plot(y,'k','Linewidth',2);
	end;
	
	watchoff;


%%-------------- POPUP-----------------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'popup'),

	%-- call the callback corresponding to chosen system
	if get(form,'value')==1,
		numerics('diag_form');
	elseif get(form,'value')==2,
 		numerics('contr_form');
	end;


%%------------------- HELP ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'help_par'),

  ttlStr='Numerics help...';
    hlpStr1= ...                                           
        ['                                             ' 
	 ' For a control law, various realizations can '
	 ' be obtained by different choises of the     '
	 ' state variables. Two of these will be trea- '
	 ' ted in this demo, the diagonal form and the '
	 ' companion form.                             '
	 '                                             '
	 ' The diagonal form looks like:               '
	 '          (z-a1)(z-a2)(z-a3)(z-a4)           '
	 ' The numbers ai, are the eigenvalues of phi. '
	 '                                             '
	 ' The companion form looks like:              '
	 '          z^4+a1z^3+a2z^2+a3z+a4             '
	 ' Here, the numbers are those used in the con-'
	 ' trollable canonical form.                   '
	 '                                             '
	 ' These representations are eqivalent from an '
	 ' input-output point of view if we assume that'
	 ' the calculations are done with infinite pre-'];

   hlpStr2= ...
	['                                             '
	 ' cision. If though, the precision is finite, '
	 ' the choise of state-space representation is '
	 ' of great importance. A bad choice of repre- '
	 ' sentation may result in a controller that is'
	 ' very sensitive to computation errors.       '
	 '                                             '
	 ' In this demo, you can choose between a re-  '
	 ' presentation in diagonal or companion form. '
	 ' The system is of 4:th order and the nume-   '
	 ' rator is chosen to give unit static gain.   '
	 ' If you have designed a system in one of the '
	 ' representations, when changing form, the    '
	 ' system is still the same.                   '];

         hwin(ttlStr,hlpStr1,hlpStr2);


%%------------------- THEORY ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'theory_par'),

  ttlStr='Numerics theory...';
    hlpStr= ...                                           
        ['                                             '  
   	 ' See Section 2.5 CCS p. 44-46 and p. 96-97   '
	 ' for reading more about diagonal and         '
	 ' controllable form.                          '
	 '                                             '
	 ' Numerical problems in realizations of digi- '
	 ' tal controllers are dealt with in Section   '
	 ' 9.7.                                        '];

         hwin(ttlStr,hlpStr);


%%------------------- HINTS ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'hint_par'),

  ttlStr='Numerics hints...';
    hlpStr= ...                                           
        ['                                             '
	 ' Use the default system. Press the "Investi- '
	 ' gate this system" button. Change the parame-'
	 ' ters 10% up and down by clicking on the     '
	 ' through of the slider. The through is the   '
	 ' space where the indicator can be moved.     '
	 ' Keep the default system and change to the   '
	 ' companion form. Repeat the procedure.       '
	 ' You can see, that the changes has a larger  '
	 ' impact on the behavior when the companion   ' 
	 ' form is used. This representation is much   '
	 ' more sensitive to numerical errors than the '
	 ' diagonal form. The computation of the compa-'
	 ' nion forms may be poorly conditioned.       '
	 '                                             '
	 ' Do also compare a system where the poles are'
	 ' situated closer to the origin. Then you see '
	 ' that such a system is less sensitive to     '
	 ' changes.                                    '];


      hwin(ttlStr,hlpStr);


%%----------------------- INIT ---------------------------------
%%--------------------------------------------------------------

elseif strcmp(operation,'winit'),

	%-- create main window
	fig_par = figure('Name','Numerics','NumberTitle','Off',...
 	'Units', 'Normalized', ...
	'Position', [0.2526 0.4789 0.4861 0.4667 ],...
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_par,'Color',[0.8,0.8,0.8]);


elseif strcmp(operation,'init'),


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_par,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_par = uicontrol(fig_par,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','numerics(''close_par'');');

	help_par = uicontrol(fig_par,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','numerics(''help_par'');');

	theory_par = uicontrol(fig_par,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','numerics(''theory_par'');');

	hint_par = uicontrol(fig_par,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','numerics(''hint_par'');');

	clear_par = uicontrol(fig_par,'Style','Push',...
	'String','Clear plots',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','numerics(''recalc'');');

	reset_par = uicontrol(fig_par,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized','Position', [0.0339 0.3667 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','numerics(''reset_num'');');

	close_par = uicontrol(fig_par,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','numerics(''close_par_def'');');


%%--------------- FRAME  -------------------------------------------

	frame_middle = uicontrol(fig_par,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	form=uicontrol(fig_par,'Style','popup',...
	'Units', 'Normalized','Position', [0.2214 0.8667 0.2857 0.0595 ],  ...
	'string',...
	'Diagonal form|Controllable form',...
	'Callback','numerics(''popup'');');

	input_a1 = uicontrol(fig_par,'Style','edit',...
	'Units', 'Normalized','Position', [0.2696 0.7119 0.0893 0.0476 ]);
	a1 = str2num(get(input_a1,'String'));
	set(input_a1,'CallBack','numerics(''editing'');',...
	'Backgroundcolor','w');

	input_a2 = uicontrol(fig_par,'Style','edit',...
	'Units', 'Normalized','Position', [0.3607 0.7119 0.0893 0.0476 ]);
	a2 = str2num(get(input_a2,'String'));
	set(input_a2,'CallBack','numerics(''editing'');',...
	'Backgroundcolor','w')

	input_a3 = uicontrol(fig_par,'Style','edit',...
	'Units', 'Normalized','Position', [0.2696 0.5929 0.0893 0.0476 ]);
	a3 = str2num(get(input_a3,'String'));
	set(input_a3,'CallBack','numerics(''editing'');',...
	'Backgroundcolor','w')

	input_a4 = uicontrol(fig_par,'Style','edit',...
	'Units', 'Normalized','Position', [0.3607 0.5929 0.0893 0.0476 ]);
	a4 = str2num(get(input_a4,'String'));
	set(input_a4,'CallBack','numerics(''editing'');',...
	'Backgroundcolor','w')

	edit_label1 = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2696 0.7619 0.1786 0.0476 ],  ...
	'String',...
	'a1         a2');

	edit_label2 = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2696 0.6429 0.1786 0.0476 ],  ...
	'String',...
	'a3         a4');

	ready = uicontrol(fig_par,'style','push',...
	'Units', 'Normalized','Position', [0.2304 0.5214 0.2679 0.0476 ],  ...
	'string','Investigate this system');
	set(ready,'CallBack','numerics(''syst_def'');');

	change = uicontrol(fig_par,'style','push',...
	'Units', 'Normalized','Position', [0.2304 0.4738 0.2679 0.0476 ], ...
	'string','Change to new system');
	set(change,'CallBack','numerics(''change_syst'');');
	set(change,'Visible','off');



%%----------------- SLIDERS ------------------------------------

	frame_a1 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2100 0.3548 0.3100 0.1000 ]);

	sli_a1 = uicontrol(fig_par,'Style','slider',...
	'Visible','off');
	drawnow
	set(sli_a1,'Units', 'Normalized',...
	'Position', [0.2786 0.3600 0.1607 0.0467 ]);

	a1_cur = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.3857 0.4077 0.1250 0.0421 ]);

	a1_min = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.3600 0.0650 0.0476 ]);

	a1_max = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.4393 0.3600 0.0714 0.0476 ]);

	a1_label = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.4077 0.1786 0.0421 ], ...
	'String','Par. a1=');
	set(sli_a1,'CallBack','numerics(''move_slid'')');

	frame_a2 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2100 0.2452 0.3100 0.1000 ]);

	sli_a2 = uicontrol(fig_par,'Style','slider',...
	'Visible','off');
	drawnow
	set(sli_a2,'Units', 'Normalized',...
	'Position', [0.2786 0.2505 0.1607 0.0476 ]);

	a2_cur = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.3857 0.2981 0.1250 0.0421 ]);

	a2_min = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.2505 0.0650 0.0476 ]);

	a2_max = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.4393 0.2505 0.0714 0.0476 ]);

	a2_label = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.2981 0.1786 0.0421 ],  ...
	'String','Par. a2=');
	set(sli_a2,'CallBack','numerics(''move_slid'')');

	frame_a3 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2100 0.1357 0.3100 0.1000 ]);

	sli_a3 = uicontrol(fig_par,'Style','slider',...
	'Visible','off');
	drawnow
	set(sli_a3,'Units', 'Normalized',...
	'Position', [0.2786 0.1410 0.1607 0.0476 ]);

	a3_cur = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.3857 0.1886 0.1250 0.0421 ]);

	a3_min = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.1410 0.0650 0.0476 ]);

	a3_max = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.4393 0.1410 0.0714 0.0476 ]);

	a3_label = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.1886 0.1786 0.0421 ],  ...
	'String','Par. a3=');
	set(sli_a3,'CallBack','numerics(''move_slid'')');

	frame_a4 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2100 0.0262 0.3100 0.1000 ]);

	sli_a4 = uicontrol(fig_par,'Style','slider',...
	'Visible','off');
	drawnow
	set(sli_a4,'Units', 'Normalized',...
	'Position', [0.2786 0.0315 0.1607 0.0476 ]);

	a4_cur = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.3857 0.0791 0.1250 0.0421 ]);

	a4_min = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.0315 0.0650 0.0476 ]);

	a4_max=uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.4393 0.0315 0.0714 0.0476 ]);

	a4_label = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.0791 0.1786 0.0421 ],  ...
	'String','Par. a4 =');
	set(sli_a4,'CallBack','numerics(''move_slid'')');

	set(a1_cur,'Visible','off');
	set(a1_min,'Visible','off');
	set(a1_max,'Visible','off');
	set(a1_label,'Visible','off');
	set(a2_cur,'Visible','off');
	set(a2_min,'Visible','off');
	set(a2_max,'Visible','off');
	set(a2_label,'Visible','off');
	set(a3_cur,'Visible','off');
	set(a3_min,'Visible','off');
	set(a3_max,'Visible','off');
	set(a3_label,'Visible','off');
	set(a4_cur,'Visible','off');
	set(a4_min,'Visible','off');
	set(a4_max,'Visible','off');
	set(a4_label,'Visible','off');
	set(frame_a1,'Visible','off');
	set(frame_a2,'Visible','off');
	set(frame_a3,'Visible','off');
	set(frame_a4,'Visible','off');


%%---------------- DIAGRAMS ------------------------------------

	%-- create pole/zero diagram
	pz_axes = subplot(222);
	title('Discrete time poles','Color','k',...
	'FontName','Times','Fontsize',11);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	set(pz_axes, 'XLim', [-1.2 1.2], 'YLim', [-1.2 1.2],...
	 'DrawMode','Fast','Clipping','Off',...
	 'XLimMode','Manual','YLimMode','Manual','XColor','k',...
	'YColor','k',...
	'FontName','Times','Fontsize',11);

	%-- create step response diagram
	tr_axes = subplot(224);
	title('Step Response','Color','k',...
	'FontName','Times','Fontsize',11);
	grid on;
	set(tr_axes, 'XLim', [0 100], 'YLim', [-1 2], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	hold on;

	a1_diag = 0.9;a1_diag0 = a1_diag;
	a2_diag = 0.9;a2_diag0 = a2_diag;
	a3_diag = 0.8;a3_diag0 = a3_diag;
	a4_diag = 0.7;a4_diag0 = a4_diag;

	set(input_a1,'String',num2str(a1_diag));
	set(input_a2,'String',num2str(a2_diag));
	set(input_a3,'String',num2str(a3_diag));
	set(input_a4,'String',num2str(a4_diag));

	formel = 1;

	%-- roots of current system
	root = [a1_diag a2_diag a3_diag a4_diag];

	%-- calculate polynomials	
	ad = poly(root);ad0 = ad;
	bd =sum(ad);bd0 = bd;
	a1_contr = ad(2);a1_contr0 = a1_contr;
	a2_contr = ad(3);a2_contr0 = a2_contr;
	a3_contr = ad(4);a3_contr0 = a3_contr;
	a4_contr = ad(5);a4_contr0 = a4_contr;

	%-- transfer to state-space form
	[A,B,C,D] = tf2ss(bd,ad);

	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot poles
	if ccs_col == 1,
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'rx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	else
		poles_num = plot(real(roots(ad)),imag(roots(ad)),'kx');
		set(poles_num,'Linewidth',2,'Markersize',9);
	end;

	%-- simulate step response
	y = dstep(bd,ad,100);y0 =y;

	%-- plot step response	
	subplot(224);
	cla;
	if ccs_col == 1,
		plot(y,'r','Linewidth',2);
	else
		plot(y,'k','Linewidth',2);
	end;

%%----------------- TEXT -------------------------------

	text1_diag = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized', ...
	'Position', [0.2100 0.8700 0.3050 0.0700 ],...
	'String','Diagonal form',...
	'BackgroundColor',[1 1 0.5]);
	set(text1_diag,'Visible','off');

	text2_diag = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized', ...
	'Position', [0.2100 0.8000 0.3050 0.0700 ],...
	'String','(z-a1)(z-a2)(z-a3)(z-a4)',...
	'BackgroundColor',[1 1 0.5],'Fontsize',10);
	set(text2_diag,'Visible','off');

	text1_contr = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized', ...
	'Position', [0.2100 0.8700 0.3050 0.0700 ],...
	'String','Controllable form',...
	'BackgroundColor',[1 1 0.5]);
	set(text1_contr,'Visible','off');

	text2_contr = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized', ...
	'Position', [0.2100 0.8000 0.3050 0.0700 ],...
	'String','z^4+a1z^3+a2z^2+a3z+a4',...
	'BackgroundColor',[1 1 0.5],'Fontsize',10);
	set(text2_contr,'Visible','off');


%%-------------- WARNING -------------------------------

	error_num = uicontrol(fig_par,'Style','text',...
	'Units', 'Normalized', ...
	'Position', [0.2200 0.3000 0.2800 0.0700 ],...
	'String','Complex eigenvalues!!',...
	'BackgroundColor','r');
	set(error_num,'Visible','off');


%%--------------- CLOSE --------------------------------
%%------------------------------------------------------

elseif strcmp(operation, 'close_par'),

	[existFlag,figNumber]=figflag('Numerics');
    	if existFlag,
		close(fig_par);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_par_def'),

	[existFlag,figNumber]=figflag('Numerics');
    	if existFlag,
		close(fig_par);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

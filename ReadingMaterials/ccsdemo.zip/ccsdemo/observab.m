function observab(operation);
% OBSERVAB	Module illustrating observability.
%		
%		It is possible to move the initial state in a
%		plot. The trajectory and the output are plotted.
%		The unobservable subspace is shown in the case of
%		the unobservable system. There are one unobservable
%		and two observable systems to investigate.

%		Author: Helena Haglund
%		LastEditDate : November 28, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_observ ccs_col fig_ccs
global state_axes
global state_handle u_handle y_handle interest
global x0 x1 x2 x00 x10 x20 
global l1 l2 l3 l4
global phi C
global x y
global system erase_obs
global interest_box
global o_ra s_ra

if nargin == 0,
	operation = 'show';
end;

%-- checks if the window already exists
if strcmp(operation,'show'),
    [existFlag,figNumber]=figflag('Observability');
    if ~existFlag,
        observab('winit');
	observab('init');
        [existFlag,figNumber]=figflag('Observability');
    else
	clf;
	observab('init');
    end;


%%---------------- SYSTEM 1, UNOBSERVABLE ------------
%%----------------------------------------------------

elseif strcmp(operation,'system1'),

	watchon;
	set(interest_box,'Visible','on'); 
	subplot(222);
	cla;
	phi = [1.1 -0.3;1 0];
	C = [1 -0.5];

	%-- calculate observab matrix Wo
	wo = obsv(phi,C);
	subplot(222);
	%-- plot interesting points invisible
	if ccs_col == 1,
		interest = plot(-0.25,-0.5,'go',0.35,-0.8,'go',...
		0.4,0.8,'go',1.5,0.25,'go');
		set(interest,'Linewidth',2,'Visible','off');
	else
		interest = plot(-0.25,-0.5,'ko',0.35,-0.8,'ko',...
		0.4,0.8,'ko',1.5,0.25,'ko');
		set(interest,'Linewidth',2,'Visible','off');
	end;
	%-- calculate vectors spanning the unobservable subspace and Wo
	l1 = (-2:0.1:2);
	l2 = (wo(1,2)/wo(1,1))*l1;
	l3 = (-wo(1,1)/wo(1,2))*l1;
	l4 = l3-1.5;

	%-- plot vectors spanning the unobservable subspace and Wo
	if ccs_col == 1,
		plot(l1,l2,'c-','Linewidth',2);
		plot(l1,l3,'b-','Linewidth',2);
		plot(l1,l4,'b--','Linewidth',2);
	else
		plot(l1,l2,'k-','Linewidth',2);
		plot(l1,l3,'k--','Linewidth',2);
		plot(l1,l4,'k-.','Linewidth',2);
	end;

	%-- initial state
	x1 = 1;x10 = x1;
	x2 = 0.5;x20 = x2;
	x0 = [x1 x2];x00 = x0;

	%-- simulate the system when releasing it in the initial state
	[y,x] = dinitial(phi,[0 0]',C,0,x0);

	%-- plot the output
	subplot(224);
	cla;
	if ccs_col == 1,
		y_handle = plot(y,'r-','Linewidth',2);
	else
		y_handle = plot(y,'k-','Linewidth',2);
	end;

	%-- plot the states	
	subplot(222);
	if ccs_col == 1,
		u_handle = plot(x(:,1),x(:,2),'r-','Linewidth',2);
		state_handle = plot(x10,x20,'rx','Linewidth',2, ...
			'Markersize',10);
	else
		u_handle = plot(x(:,1),x(:,2),'k-','Linewidth',2);
		state_handle = plot(x10,x20,'kx','Linewidth',2, ...
			'Markersize',10);
	end;
	set(state_handle,'Linewidth',2,'EraseMode','XOR');

	%-- EraseMode XOR or None
	if get(erase_obs,'Value')==1,
		set(y_handle,'EraseMode','XOR');
		set(u_handle,'EraseMode','XOR');
	elseif get(erase_obs,'Value')==2,
		set(y_handle,'EraseMode','None');
		set(u_handle,'EraseMode','None');
	end;

	%-- make initial state movable
	set(state_handle,'ButtonDownFcn',...
	'observab(''move_state'');');
	watchoff;


%%---------------- SYSTEM 2 & 3, OBSERVABLE---------------
%%--------------------------------------------------------

elseif strcmp(operation,'system23'),

	watchon;
	subplot(222);
	cla;
	if get(system,'Value')==2,
		set(interest_box,'Visible','on'); 
		if ccs_col == 1,
			interest = plot(1.8,0.5,'go',2,1,'go',...
			-0.5,1.5,'go',0,-0.5,'go',-1,-0.8,'go',...
			-1,0.8,'ro',1,-0.8,'ro');
			set(interest,'Linewidth',2,'Visible','off');
		else
			interest = plot(1.8,0.5,'ko',2,1,'ko',...
			-0.5,1.5,'ko',0,-0.5,'ko',-1,-0.8,'ko',...
			-1,0.8,'k*',1,-0.8,'k*');
			set(interest,'Linewidth',2,'Visible','off');
		end;
		phi = [1 1;-0.16 0];
		C = [1 0];
	elseif get(system,'Value')==3,
		set(interest_box,'Visible','off'); 
		phi = [-0.5 1;-0.6 0];
		C = [1 0];
	end;

	%-- calculate observab matrix Wo
	wo = obsv(phi,C);
	subplot(222);

	%-- initial state
	x1 = 1;x10 = x1;
	x2 = 0.5;x20 = x2;
	x0 = [x1 x2];x00 = x0;

	%-- simulate the system when releasing it in the initial state
	[y,x] = dinitial(phi,[0 0]',C,0,x00);

	%-- plot the output
	subplot(224);
	cla;
	if ccs_col == 1,
		y_handle = plot(y,'r-','Linewidth',2);
	else
		y_handle = plot(y,'k-','Linewidth',2);
	end;

	%-- plot the states
	subplot(222);
	if ccs_col == 1,
		u_handle = plot(x(:,1),x(:,2),'r-','Linewidth',2);
		state_handle = plot(x1,x2,'rx','Linewidth',2,'Markersize',10);
	else
		u_handle = plot(x(:,1),x(:,2),'k-','Linewidth',2);
		state_handle = plot(x1,x2,'kx','Linewidth',2,'Markersize',10);
	end;
	set(state_handle,'Linewidth',2,'EraseMode','XOR');

	%-- EraseMode XOR or None
	if get(erase_obs,'Value')==1,
		set(y_handle,'EraseMode','XOR');
		set(u_handle,'EraseMode','XOR');
	elseif get(erase_obs,'Value')==2,
		set(y_handle,'EraseMode','None');
		set(u_handle,'EraseMode','None');
	end;

	%-- make initial state movable
	set(state_handle,'ButtonDownFcn',...
	'observab(''move_state'');');
	watchoff;


%%---------------- MOVING ---------------------------
%%----------------------------------------------------

elseif strcmp(operation,'move_state'),

	set(fig_observ, 'WindowButtonMotionFcn', ...
	'observab(''moving_state'');',...
                 'WindowButtonUpFcn', ...
      'observab(''state_moved'');');

elseif strcmp(operation,'moving_state'),

	currpoint = get(state_axes, 'CurrentPoint');
	x1 = currpoint(1,1);
	x2 = currpoint(1,2);

	x0 = [x1 x2];

elseif strcmp(operation,'state_moved'),

	set(fig_observ, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');

	%-- simulate with new inintial state
	[y,x] = dinitial(phi,[0 0]',C,0,x0);

	%-- plot output
	subplot(224);
	set(y_handle,'YData',y,'XData',1:length(y));
	
	%-- plot states
	subplot(222);
	set(u_handle,'XData',x(:,1),'YData',x(:,2));
	set(state_handle,'XData',x1,'YData',x2);


%%--------------- INTERESTING POINTS ----------------------------
%%---------------------------------------------------------------

elseif strcmp(operation,'opoints'),

	%-- just marks some initial states of special interest
	subplot(222);
	if ccs_col == 1,
		if get(system,'Value')==4,
		set(interest,'Visible','on');
		elseif get(system,'Value')==2,
		set(interest,'Visible','on');
		end;
	else
		if get(system,'Value')==4,
		set(interest,'Visible','on');
		elseif get(system,'Value')==2,
		set(interest,'Visible','on');
		end;
	end;


%%-------------- POPUP-----------------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'popup'),

	if get(system,'value')==1
 		subplot(222);cla;
		subplot(224);cla;
	elseif get(system,'value')==2,
 		observab('system23');
	elseif get(system,'value')==3, 
 		observab('system23');
	elseif get(system,'value')==4, 
 		observab('system1');
	end;


%%-------------- POPUP ERASE----------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'popup_erase'),

	if get(erase_obs,'value')==1
		subplot(224);
		cla;
		subplot(222);
		cla;
		if get(system,'Value')==4,
		%-- plot interesting points invisible
		if ccs_col == 1,
			interest = plot(-0.25,-0.5,'go',0.35,-0.8,'go',...
			0.4,0.8,'go',1.5,0.25,'go');
			set(interest,'Linewidth',2,'Visible','off');
		else
			interest = plot(-0.25,-0.5,'ko',0.35,-0.8,'ko',...
			0.4,0.8,'ko',1.5,0.25,'ko');
			set(interest,'Linewidth',2,'Visible','off');
		end;
			%-- plot vectors spanning the unobservable 
			%-- subspace and Wo
			if ccs_col == 1,
				plot(l1,l2,'c-','Linewidth',2);
				plot(l1,l3,'b-','Linewidth',2);
				plot(l1,l4,'b--','Linewidth',2);
			else
				plot(l1,l2,'k-','Linewidth',2);
				plot(l1,l3,'k--','Linewidth',2);
				plot(l1,l4,'k-.','Linewidth',2);
			end;
		end;
		if get(system,'Value')==2,
			set(interest_box,'Visible','on'); 
			subplot(222);
			if ccs_col == 1,
				interest = plot(1.8,0.5,'go',2,1,'go',...
				-0.5,1.5,'go',0,-0.5,'go',-1,-0.8,'go',...
				-1,0.8,'ro',1,-0.8,'ro');
				set(interest,'Linewidth',2,'Visible','off');
			else
				interest = plot(1.8,0.5,'ko',2,1,'ko',...
				-0.5,1.5,'ko',0,-0.5,'ko',-1,-0.8,'ko',...
				-1,0.8,'k*',1,-0.8,'k*');
				set(interest,'Linewidth',2,'Visible','off');
			end;
		end;
		if ccs_col == 1,
			u_handle = plot(x(:,1),x(:,2),'r-','Linewidth',2);
			set(u_handle, 'EraseMode', 'XOR');
			state_handle = plot(x1,x2,'rx','Markersize',10,...
			'Linewidth',2);
		else
			u_handle = plot(x(:,1),x(:,2),'k-','Linewidth',2);
			set(u_handle, 'EraseMode', 'XOR');
			state_handle = plot(x1,x2,'kx','Markersize',10,...
			'Linewidth',2);
		end;
		set(state_handle, 'EraseMode', 'XOR','LineWidth',2);
		subplot(224);
		if ccs_col == 1,
			y_handle = plot(y,'r-','Linewidth',2);
		else
			y_handle = plot(y,'k-','Linewidth',2);
		end;
		set(y_handle, 'EraseMode', 'XOR');

		%-- make initial state movable
		set(state_handle,'ButtonDownFcn',...
		'observab(''move_state'');');
%		end;

	elseif get(erase_obs,'value')==2,
 		set(u_handle, 'EraseMode', 'None');
		set(y_handle, 'EraseMode', 'None');
		subplot(224);
	end;
          
	
%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_observ');
   ttlStr='Observab help...';
  if ccs_col == 1,
    hlpStr1= ...                                           
        ['                                             '
         ' This demo illustrates observability. A sys- '
	 ' tem is observable if all states can be re-  '
	 ' constructed, given only the input and output'
	 ' signals.                                    '
	 '                                             '
	 ' The systems that are used in this demo are: '
	 ' System1: phi=[1 1;-0.16 0], C=[1 0]         '
	 ' System2: phi=[-0.5 1;-0.6 0], C=[1 0]       '
	 ' System3: phi=[1.1 -0.3;1 0], C=[1 -0.5]     '
	 '                                             '
	 ' System 1 and 2 are observable systems. Sy-  '
	 ' stem 1 has real eigenvalues and system 2 has'
	 ' complex eigenvalues. System 3 is an unobser-'
	 ' vable system.                               '
	 '                                             '
         ' Concerning the unobservable system, the un- '   
         ' observable subspace is shown with a blue    '  
         ' line in the upper graph. The light blue line']; 

  hlpStr2= ...                                           
        ['                                             '
	 ' shows the vector spanned by the observ-     '
	 ' ability matrix. The dotted blue line is     '
	 ' a line parallell to the unobservable sub-   '
	 ' space.                                      '
	 '                                             '
       	 ' When a system is chosen, its initial state, '
	 ' the trajectory and the output are shown. The'
	 ' initial state can be moved to arbitrary po- '
	 ' sition in the phase plane.                  '];


  else
    hlpStr1= ...                                           
        ['                                             '
         ' This demo illustrates observability. A sys- '
	 ' tem is observable if all states can be re-  '
	 ' constructed, given only the input and output'
	 ' signals.                                    '
	 '                                             '
	 ' The systems that are used in this demo are: '
	 ' System1: phi=[1 1;-0.16 0], C=[1 0]         '
	 ' System2: phi=[-0.5 1;-0.6 0], C=[1 0]       '
	 ' System3: phi=[1.1 -0.3;1 0], C=[1 -0.5]     '
	 '                                             '
	 ' System 1 and 2 are observable systems. Sy-  '
	 ' stem 1 has real eigenvalues and system 2 has'
	 ' complex eigenvalues. System 3 is an unobser-'
	 ' vable system.                               '
	 '                                             '
         ' Concerning the unobservable system, the un- '   
         ' observable subspace is shown with a dotted  '  
         ' line in the upper graph. The full line shows']; 

  hlpStr2= ...                                           
        ['                                             '
	 ' the vector spanned by the observability mat-'
	 ' rix and the dash-dotted line is a line      '
	 ' parallell to the unobservable subspace.     '
	 '                                             '
      	 ' When a system is chosen, its initial state, '
	 ' the trajectory and the output are shown. The'
	 ' initial state can be moved to arbitrary po- '
	 ' sition in the phase plane.                  '];

  end;

     
    hwin(ttlStr,hlpStr1,hlpStr2); 


%%------------------THEORY ----------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_observ');
   ttlStr='Observab theory...';
    hlpStr= ...                                           
        ['                                             '
         ' See Section 3.4 in CCS p. 98-101 for more   '
	 ' information about observability.            '];
 
     
    hwin(ttlStr,hlpStr); 


%%------------------HINTS ----------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_observ');
   ttlStr='Observab hints...';
  if ccs_col == 1,
    hintStr1= ... 
	['                                             '
	 ' Choose observable system 1 and press the    '
	 ' "Interesting"-button. Set erasemode to None.'
	 ' Move the initial state too all the green and'
	 ' red rings  in the phase plane. The resulting'
	 ' plot shows that the states approach the ori-'
	 ' gin along two vectors. These vectors are the'
	 ' eigenvectors of phi. The vector correspon-  '
	 ' ding to the slowest eigenvalue is the one,  '
	 ' along which most of the trajectories appro- '
	 ' ach the origin. Only when starting on the   '
	 ' fast eigenvector, the trajectories follow   '
	 ' that direction. The red rings are situated  '
	 ' on the fast eigenvector.                    '
	 '                                             '
	 ' Choose the unobservable system and press the'
	 ' "Interesting"-button. Set erasemode to None.'
	 ' Move the initial state to the ring situated '
	 ' on the same line as the default position.   '];


   hintStr2= ...                                           
      	['                                             '
	 ' Notice that the output does not change. Move'
	 ' the initial state to some other positions on'
	 ' this same line and you can see that all of  '
	 ' them give the same ouput. This line is      '
	 ' parallell to the unobservable subspace. The '
	 ' same thing happens when moving along any    '
	 ' line that is parallell to the unobservable  '
	 ' subspace.                                   '
	 ' Then, move the initial state to one of the  '
	 ' rings situated on the dark blue full line.  '
	 ' The output becomes zero. This line repre-   '
	 ' sents the unobservable subspace. All initial'
	 ' states lying on this line give zero output. '
	 ' Try this by moving the initial state to some'
	 ' other locations on the same line.           '];

  else
   hintStr1= ... 
	['                                             '
	 ' Choose observable system 1 and press the    '
	 ' "Interesting"-button. Set erasemode to None.'
	 ' Move the initial state too all the rings and'
	 ' stars in the phase plane. The resulting plot'
	 ' shows that the states approach the origin   '
	 ' along two vectors. These vectors are the    '
	 ' eigenvectors of phi. The vector correspon-  '
	 ' ding to the slowest eigenvalue is the one,  '
	 ' along which most of the trajectories appro- '
	 ' ach the origin. Only when starting on the   '
	 ' fast eigenvector, the trajectories follow   '
	 ' that direction. The stars are situated on   '
	 ' the fast eigenvector.                       '
	 '                                             '
	 ' Choose the unobservable system and press the'
	 ' "Interesting"-button. Set erasemode to none.'
	 ' Move the initial state to the ring situated '
	 ' on the same line as the default position.   '];

    hintStr2= ...                                           
      	['                                             '
	 ' Notice that the output does not change. Move'
	 ' the initial state to some other positions on'
	 ' this same line and you can see that all of  '
	 ' them give the same ouput. This line is      '
	 ' parallell to the unobservable subspace. The '
	 ' same thing happens when moving along any    '
	 ' line that is parallell to the unobservable  '
	 ' subspace.                                   '
	 ' Then, move the initial state to one of the  '
	 ' rings situated on the dashed line. The out- '
	 ' put becomes zero. This line represents the  '
	 ' unobservable subspace. All initial states   '
	 ' lying on this line give zero output. Try    '
	 ' this by moving the initial state to some    '
	 ' other locations on the same line.           '];
  end;
 
    hwin(ttlStr,hintStr1,hintStr2); 


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit');

	%-- creates window
	fig_observ = figure('Name','Observability','NumberTitle'...
	,'Off','BackingStore','Off','Units', 'Normalized',...
	'Position', [0.2561 0.4656 0.4861 0.4667 ]);
	set(fig_observ,'Color',[0.8 0.8 0.8],'DefaultUicontrolFontSize',11);


elseif strcmp(operation,'init'),
	watchon;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_observ,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_observ = uicontrol(fig_observ,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized',...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'Callback','observab(''close_observ'');');

	help_observ = uicontrol(fig_observ,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','observab(''help_observ'');');

	theory_observ = uicontrol(fig_observ,'Style','Push',...
	'String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','observab(''theory_observ'');');

	hint_observ = uicontrol(fig_observ,'Style','Push',...
	'String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','observab(''hints_observ'');');

	close_observ = uicontrol(fig_observ,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','observab(''close_observ_def'');');


%%--------------- FRAME MIDDLE -------------------------------------

	frame_middle = uicontrol(fig_observ,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	system = uicontrol(fig_observ,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.8667 0.2679 0.0595 ],  ...
	'string',...
	'Select system|Observable 1|Observable 2|Unobservable',...
	'Callback','observab(''popup'');');

	interest_box = uicontrol(fig_observ,'style','push',...
	'Units', 'Normalized','Position', [0.2304 0.5929 0.2679 0.0595 ],  ...
	'string','Interesting',...
	'BackgroundColor',[0.7 1 0.7]);
	set(interest_box,'CallBack','observab(''opoints'');');
	set(interest_box,'Visible','off'); 

	erase_obs = uicontrol(fig_observ,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.4262 0.2679 0.0595 ],  ...
	'String',...
	'Erasemode XOR|Erasemode None',...
	'Callback','observab(''popup_erase'');');

%%------------- DIAGRAMS --------------------------------------------

	%-- creates state axes
	state_axes = subplot(222);
	set(state_axes,'XLim',[-1 2],'YLim',[-1 2],'XColor','k',...
	'YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Phase plane','Color','k',...
	'FontName','Times','Fontsize',11);
	axis('equal');
	grid on;
	hold on;

	%-- creates output axes
	out_axes = subplot(224);
	set(out_axes,'XLim',[0 15],'YLim',[-1.5 1.5],...
	'XColor','k','YColor','k','YTick',[-1 0 1],...
	'FontName','Times','Fontsize',11);
	title('Output','Color','k',...
	'FontName','Times','Fontsize',11);
	xlabel('time t/s','Color','k');
	grid on;
	hold on;
	watchoff;

	%-- create handles
	u_handle = plot(NaN,NaN);
	y_handle = plot(NaN,NaN);
	state_handle = plot(NaN,NaN);
	set(state_handle,'EraseMode','XOR');


%%------------------ CLOSE --------------------------
%%---------------------------------------------------

elseif strcmp(operation, 'close_observ'),

	[existFlag,figNumber]=figflag('Observability');
    	if existFlag,
		close(fig_observ);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_observ_def'),

	[existFlag,figNumber]=figflag('Observability');
    	if existFlag,
		close(fig_observ);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;	

function alias(operation);
% ALIAS		Module illustrating the aliasing problem when a
%		signal is sampled, and also how this problem can
%		be overcome by using a prefilter.
%		
%		The sine wave-, and the Nyquist- frequency can be
%		altered. When using the optional 6:th order Bessel-
%		filter, the bandwidth of this one can also be 
%		altered.

%		Author: Helena Haglund
%		LastEditDate : Dec 14 1995
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_alias ccs_col fig_ccs
global system_alias
global freq_axes_alias sine_axes_alias samp_axes_alias
global sli_nyq nyq_cur sli_w w_cur 
global sli_wb wb_cur wb_min wb_max frame_wb wb_label
global b a num2 den2 numf denf w
global choise1_alias
global sin_u sin_ys sin_ts h sin_t sin_y nyq sin_tsf
global pw pwn sine_handle samp_handle samp2_handle pwb pw_wn sine_filt_handle

if nargin == 0,
	operation = 'show';
end;

if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Aliasing');
	if ~existFlag,
      		alias('winit_alias');
      		alias('init_alias');	
 		[existFlag,figNumber]=figflag('Aliasing');
	else
		clf;
		alias('init_alias');
	end;


%%------------------- CALCULATIONS --------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'aliascalc'),

	watchon;

	if get(choise1_alias,'Value')==1,
		%- make filter bandwidth slider unvisible
		set(frame_wb,'Visible','off');
		set(sli_wb,'Visible','off');
		set(wb_cur,'Visible','off');
		set(wb_min,'Visible','off');
		set(wb_max,'Visible','off');
		set(wb_label,'Visible','off');
	else
		%- make filter bandwidth slider visible
		set(frame_wb,'Visible','on');
		set(sli_wb,'Visible','on');
		set(wb_cur,'Visible','on');
		set(wb_min,'Visible','on');
		set(wb_max,'Visible','on');
		set(wb_label,'Visible','on');
	end;

	%-- get correct value of Nyquist freq.
	nyq = get(sli_nyq,'Value');
	set(nyq_cur,'String',num2str(nyq));
	h = 3.14/nyq;

	%-- get correct value of w
	w = get(sli_w,'Value');
	set(w_cur,'String',num2str(w));

	if get(choise1_alias,'Value')==2,
		%-- get correct value of bandwidth of the filter, wb
		wb = get(sli_wb,'Value');
		set(wb_cur,'String',num2str(wb));
	end;

	%-- plot frequencies
	axes(freq_axes_alias);

	A = 0:0.1:1;
	w_vec = w*ones(1,length(A));
	%-- plot sinus frequency
	set(pw,'XData',w_vec,'YData',A);
	wn_vec = nyq*ones(1,length(A));
	%-- plot nyqvist frequency
	set(pwn,'XData',wn_vec,'YData',A);
	w_test = w;

	%-- plot the folded frequency if there is one
	set(pw_wn,'XData',NaN,'YData',NaN);
	while w_test > nyq,
		w1 = abs(2*nyq-w_test);
		w_test = w1;
		if w_test < nyq,
			w_wn_vec = w1*ones(1,length(A));
			set(pw_wn,'XData',w_wn_vec,'YData',A);
		end;
	end;	

	if get(choise1_alias,'Value')==2,
		wb_vec = wb*ones(1,length(A));
		set(pwb,'XData',wb_vec,'YData',A);
		if ccs_col == 1,
			set(samp_handle,'Color','b');
		else
			set(samp_handle,'Color','k');
		end;

		%-- 6:th order besselfilter
		om1 = 1.90; zeta1 = 0.49;
		om2 = 1.69; zeta2 = 0.82;
		om3 = 1.61; zeta3 = 0.98;
		bf1 = om1^2;
		bf2 = om2^2;
		bf3 = om3^2;
		af1 = [(1/wb)^2 2*zeta1*om1/wb om1^2];
		af2 = [(1/wb)^2 2*zeta2*om2/wb om2^2];
		af3 = [(1/wb)^2 2*zeta3*om3/wb om3^2];
		bf = bf1*bf2*bf3;
		aftemp = conv(af1,af2);
		af = conv(aftemp,af3);
	else
		set(pwb,'XData',NaN,'YData',NaN);
		set(sine_filt_handle,'XData',NaN,'YData',NaN);
		if ccs_col == 1,
			set(samp_handle,'Color','r');
		else
			set(samp_handle,'Color','k');
		end;
	end;

	%-- create sine wave
	sin_t = 0:0.1/w:15;
	sin_u = sin(w*sin_t);
	sin_ts = 0:h:15;

	if get(choise1_alias,'Value')==1,
		%-- plot sine wave
		axes(sine_axes_alias);
		set(sine_handle,'XData',sin_t,'YData',sin_u);

		%-- sample the sine wave
		axes(samp_axes_alias);
		sin_us = sin(w*sin_ts);
		set(samp_handle,'XData',sin_ts,'YData',sin_us);
		set(samp2_handle,'XData',sin_ts,'YData',sin_us);

	else

		%-- plot sine wave
		axes(sine_axes_alias);
		set(sine_handle,'XData',sin_t,'YData',sin_u);

		%-- sample the sine wave
		axes(samp_axes_alias);
		sin_us = sin(w*sin_ts);
		set(samp_handle,'XData',sin_ts,'YData',sin_us);
		set(samp2_handle,'XData',sin_ts,'YData',sin_us);

		%-- filter sine wave
		sin_y = lsim(bf,af,sin_u,0:0.1/w:15);

		%-- plot filtered sine wave
		axes(sine_axes_alias);
		set(sine_filt_handle,'XData',sin_t,'YData',sin_y);

		%-- sample the filtered sine wave
		sin_ys = zeros(length(sin_ts),1);
		sin_tsf = zeros(length(sin_ts),1);
         	axes(samp_axes_alias);
	        for t=2:length(sin_ts),
                        t1 = round((t-1)*h/(0.1/w));
                        if t1>length(0:0.1/w:15),
                                t1 = length(0:0.1/w:15);
                        end;
                        sin_ys(t) = sin_y(t1);
			sin_tsf(t) = sin_t(t1);
                end;
		set(samp_handle,'XData',sin_tsf,'YData',sin_ys);
		set(samp2_handle,'XData',sin_tsf,'YData',sin_ys);
	end;
	watchoff;


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_alias'),
   ttlStr='Alias help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' This demo illustrates what happens to a sig-'
	 ' nal when it is sampled. Alias frequencies   '
	 ' appear when the sampling period is too long '
	 ' relative to the frequency of the sinusoidal.'
	 '                                             '
	 ' According to the Sampling theorem, the samp-'
	 ' ling frequency must be at least twice as    '
	 ' high as the highest frequency component in  '
	 ' the signal to avoid frequency aliasing. This'
	 ' means that the Nyquist frequency must be at '
	 ' least as high as the highest frequency com- '
	 ' ponent. If this is not the case, alias fre- '
	 ' quencies will appear, and the original sig- '
	 ' nal can not be distinguished from these.    '
	 '                                             '
	 ' The Nyquist frequency, the frequency of the '
	 ' sine wave and the bandwidth of the filter   '  
	 ' can be altered. The nyquist frequency is    '];

  if ccs_col == 1,
    hlpStr2= ...
	['                                             '
	 ' equal to pi/h. The filter is a 6:th order   '  
	 ' Bessel-filter.                              '
	 '                                             '
	 ' In the Frequencies-diagram, the red line is '
	 ' the Nyquist-frequency, the violet line      '
	 ' is the frequency of the sine wave, the vio- '
	 ' let dashed line is the folded frequency and '
	 ' the dark blue one is the bandwidth of the   '
	 ' Bessel-filter.                              '
	 '                                             '
	 ' When a filter is used, the blue line in the '
	 ' diagram "Signal before sampling", is the    '
	 ' filtered signal and the yellow line is the  '
	 ' signal that would be if there was no filter.'];  
  else
      hlpStr2= ...                                           
        ['                                             ' 
	 ' equal to pi/h. The filter is a 6:th order   '  
	 ' Bessel-filter.                              '
	 '                                             ' 
	 ' In the Frequencies-diagram, the full line is'
	 ' the Nyquist-frequency, the dashed line is   '
	 ' the frequency of the sine wave, the dashdot '
	 ' line is the folded frequency and the dotted '
	 ' line is the bandwidth of the filter.        '
	 '                                             '
	 ' When a filter is used, the dash-dotted line '
	 ' in the diagram "Signal before sampling", is '
	 ' the filtered signal and the full line is the'
	 ' signal that would be if there was no filter.'];  
  end;    
    hwin(ttlStr,hlpStr1,hlpStr2); 


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_alias'),
   ttlStr='Aliasing theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Section 7.4 in CCS p.249-256 for reading'  
         ' about aliasing, frequency folding and pre-  '   
	 ' filtering.                                  '];

    hwin(ttlStr,hlpStr);   


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_alias'),
   ttlStr='Aliasing hints...';
    hlpStr1= ...                                           
        ['                                             '
	 ' Choose Nyquist frequency wn=5 and sine fre- '
	 ' quency w=1. The sampling period is then     '
	 ' equal to 0.63. In this case, the sampling   '
	 ' frequency (2*wn) is much higher than the    '
	 ' signal frequency and the original signal can'
	 ' be reconstructed from the sampled signal. No'
	 ' alias frequencies appear.                   '
	 '                                             '
         ' Choose Nyquist frequency wn= 2.7 and Sine   '  
         ' frequency w=4.5. The sampling period is then'
	 ' equal to 1.1. In this case, the sampling    '
	 ' frequency (2*wn) is not twice as high as the'
	 ' signal frequency and the original signal can'
	 ' not be reconstructed from the sampled sig-  '
	 ' nal. A low-frequency alias signal has appea-'
	 ' red.                                        '];

   hlpStr2= ...
	['                                             '
	 ' In the case where alias frequencies appea-  '
	 ' red, add a filter with bandwidth wb=1. Then '
	 ' the sinewave is almost completely extingu-  '
	 ' ished. The low frequency alias signal has   '
	 ' also been removed.                          '
	 '                                             '
	 ' A prefilter, with a proper bandwidth, can   '
	 ' be used to remove unwanted high frequencies '
	 ' in a signal. In the former example, the si- '
	 ' nusoidal can be regarded as a high-frequency'
	 ' disturbance, acting on a signal with lower  '
	 ' frequency. In this case, the high frequency '
	 ' should be removed, which is performed with  '
	 ' the prefilter. After having removed these   '
	 ' unwanted high frequencies, the important    '
	 ' parts of the signal can be reconstructed    '
	 ' properly.                                   '];                 

    hwin(ttlStr,hlpStr1,hlpStr2);    
       


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_alias'),

	fig_alias = figure('Name',...
	'Aliasing','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.2561 0.4656 0.4861 0.4667 ], ...
	'BackingStore','Off');
	set(fig_alias,'Color',[0.8 0.8 0.8], ...
	'DefaultUicontrolFontSize',11);

elseif strcmp(operation,'init_alias'),
	watchon;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_alias,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_alias = uicontrol(fig_alias,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ], ...
	'Callback','alias(''close_alias'');');

	help_alias = uicontrol(fig_alias,'Style','Push',...
	'String','Help!',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.7833 0.1429 0.0595 ],...
	'BackgroundColor',[1 1 0.3],...
	'Callback','alias(''help_alias'');');

	theory_alias = uicontrol(fig_alias,'Style','Push',...
	'String','Theory',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.7000 0.1429 0.0595 ],...
	'BackgroundColor',[1 1 0.5],...
	'Callback','alias(''theory_alias'');');

	hint_alias = uicontrol(fig_alias,'Style','Push',...
	'String','Hints',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.6167 0.1429 0.0595 ],...
	'BackgroundColor',[1 1 0.7],...
	'Callback','alias(''hints_alias'');');

	close_alias = uicontrol(fig_alias,'Style','Push',...
	'String','Quit',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.0690 0.1429 0.0595 ],...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','alias(''close_alias_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_alias,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3250 0.9524 ]);

	frame_nyq = uicontrol(fig_alias,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.7800 0.3143 0.1100 ]);

	sli_nyq = uicontrol(fig_alias,'Style','slider',...
	'Units', 'Normalized','Position', [0.2621 0.7870 0.2143 0.0450 ],  ...
	'Min',0.5,'Max',10,...
	'Value',2.5,'Callback','alias(''aliascalc'');');

	if ccs_col == 1,
		nyq_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8329 0.1010 0.0450 ],...
		'String',num2str(get(sli_nyq,'Val')),'ForegroundColor','m');
%		set(nyq_cur,'ButtonDownFcn','set(''pwn'',''Linewidth'',4);');
		set(nyq_cur,'ButtonDownFcn','aaa=1');
	else
		nyq_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8329 0.1010 0.0450 ],...
		'String',num2str(get(sli_nyq,'Val')),'ForegroundColor','k');
	end;
	
	nyq_min = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.7850 0.0380 0.0450 ],  ...
	'String',num2str(get(sli_nyq,'Min')));

	nyq_max = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.4764 0.7850 0.0432 0.0450 ],  ...
	'String',num2str(get(sli_nyq,'Max')));

	if ccs_col == 1,
		nyq_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8329 0.2089 0.0450 ],...
		'String','Nyquist freq.=','ForegroundColor','m');
	else
		nyq_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8329 0.2089 0.0450 ],...
		'String','Nyquist freq.(-.)=','ForegroundColor','k');
	end;

	frame_w = uicontrol(fig_alias,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.6600 0.3143 0.1100 ]);

	sli_w = uicontrol(fig_alias,'Style','slider');
	set(sli_w,'Units', 'Normalized',...
	'Position', [0.2621 0.6660 0.2143 0.0450 ],...
	'Min',0.1,'Max',5,...
	'Value',0.5,...
	'Callback','alias(''aliascalc'');');

	if ccs_col == 1,
		w_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7119 0.1010 0.0476 ],...
		'String',num2str(get(sli_w,'Val')),...
		'ForegroundColor','r');
	else
		w_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7119 0.1010 0.0476 ],...
		'String',num2str(get(sli_w,'Val')),'ForegroundColor','k');
	end;

	w_min = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.6660 0.0380 0.0450 ],  ...
	'String',num2str(get(sli_w,'Min')));

	w_max = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.4764 0.6660 0.0432 0.0450 ],  ...
	'String',num2str(get(sli_w,'Max')));

	if ccs_col == 1,
		w_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7119 0.2070 0.0476 ],...
		'ForegroundColor','r',...
		'String','Sine frequency=');
	else
		w_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7119 0.2070 0.0476 ],...
		'ForegroundColor','k',...
		'String','Sine freq. (-)=');
	end;

	frame_wb = uicontrol(fig_alias,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.5400 0.3143 0.1100 ]);

	sli_wb = uicontrol(fig_alias,'Style','slider',...
	'Min',0.1,'Max',5,...
	'Value',1.3,'Callback','alias(''aliascalc'');',...
	'Visible','off');
	drawnow
	set(sli_wb,'Units', 'Normalized',... 
	'Position',[0.2621 0.5452 0.2143 0.0476 ]); 


	if ccs_col == 1,
		wb_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.5929 0.1018 0.0476 ],...
		'String',num2str(get(sli_wb,'Val')),'ForegroundColor','b');
	else
		wb_cur = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.5929 0.1018 0.0476 ],...
		'String',num2str(get(sli_wb,'Val')),'ForegroundColor','k');
	end;

	wb_min = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.5452 0.0380 0.0476 ],  ...
	'String',num2str(get(sli_wb,'Min')));

	wb_max = uicontrol(fig_alias,'Style','text',...
	'Units', 'Normalized','Position', [0.4764 0.5452 0.0432 0.0476 ],  ...
	'String',num2str(get(sli_wb,'Max')));

	if ccs_col == 1,
		wb_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.5929 0.2089 0.0476 ],...
		'String','Bandwidth=','ForegroundColor','b');
	else
		wb_label = uicontrol(fig_alias,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.5929 0.2089 0.0476 ],...
		'String','Bandwidth=(:)','ForegroundColor','k');
	end;

	choise1_alias = uicontrol(fig_alias,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.3548 0.2679 0.0595 ],  ...
	'string',...
	'No filter|6:th order Bessel');
	set(choise1_alias,'Callback','alias(''aliascalc'');');

	set(frame_wb,'Visible','off');
%	set(sli_wb,'Visible','off');
	set(wb_cur,'Visible','off');
	set(wb_min,'Visible','off');
	set(wb_max,'Visible','off');
	set(wb_label,'Visible','off');	

	watchoff;

%%------------------ DIAGRAMS ------------------------------------

	%-- create diagram for frequencies
	freq_axes_alias = axes('Position',[0.6 0.71 0.35 0.22]);
	hold on;
	grid on;
	set(freq_axes_alias, 'XLim',[0 10],'YLim'...
	, [-0.1 2],'XColor','k','YColor','k',...
	'XTick',[0 2 4 6 8 10],'YTick',[],...
	'FontName','Times','Fontsize',11);
	title('Frequencies, rad/s','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for sine wave
	sine_axes_alias = axes('Position',[0.6 0.39 0.35 0.22]);
	hold on;
	grid on;
	set(sine_axes_alias, 'XLim',[0 15],'YLim'...
	, [-1.5 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Signal before sampling','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram sampled signal
	samp_axes_alias = axes('Position',[0.6 0.05 0.35 0.22]);
	hold on;
	grid on;
	set(samp_axes_alias, 'XLim',[0 15],'YLim'...
	, [-1.5 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Signal after sampling','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- get correct value of h
	nyq = get(sli_nyq,'Value');
	h = 3.14/nyq;

	%-- get correct value of w
	w = get(sli_w,'Value');

	%-- plot frequencies
	axes(freq_axes_alias);
	A = 0:0.1:1;
	w_vec = w*ones(1,length(A));
	if ccs_col == 1,
		pw = plot(w_vec,A,'r');
	else
		pw = plot(w_vec,A,'k');
	end;		
	set(pw,'Linewidth',2,'EraseMode','XOR');
	wn_vec = 3.14/h*ones(1,length(A));
	if ccs_col == 1,
		pwn = plot(wn_vec,A,'m');
	else
		pwn = plot(wn_vec,A,'k-.');
	end;
	set(pwn,'Linewidth',2,'EraseMode','XOR');

	%-- plot sine wave
	axes(sine_axes_alias);
	sin_t = 0:0.1/w:15;
	sin_u = sin(w*sin_t);
	if ccs_col == 1,
		sine_handle = plot(sin_t,sin_u,'r-');
	else
		sine_handle = plot(sin_t,sin_u,'k-');
	end;
	set(sine_handle,'EraseMode','XOR','LineWidth',2);

	%-- sample the sine wave
	axes(samp_axes_alias);
	sin_ts = 0:h:15;
	sin_us = sin(w*sin_ts);
	if ccs_col == 1,
		samp_handle = plot(sin_ts,sin_us,'r.');
		samp2_handle = plot(sin_ts,sin_us,'k-');
	else
		samp_handle = plot(sin_ts,sin_us,'k.');
		samp2_handle = plot(sin_ts,sin_us,'k-');
	end;		
	set(samp_handle,'EraseMode','XOR','MarkerSize',16);
	set(samp2_handle,'EraseMode','XOR','Linewidth',1);

	axes(freq_axes_alias);
	%-- create handles for bandwidth and alias frequencies
	if ccs_col == 1,
		pwb = plot(NaN,NaN,'b');
		set(pwb,'Linewidth',2,'EraseMode','XOR');
		pw_wn = plot(NaN,NaN,'r--');
		set(pw_wn,'Linewidth',2,'EraseMode','XOR');
	else
		pwb = plot(NaN,NaN,'k.');
		set(pwb,'Markersize',10,'EraseMode','XOR');
		pw_wn = plot(NaN,NaN,'k--');
		set(pw_wn,'Linewidth',2,'EraseMode','XOR');
	end;

	%-- create handle for filtered sine wave
	axes(sine_axes_alias);
	if ccs_col == 1,
		sine_filt_handle = plot(NaN,NaN,'b');
		set(sine_filt_handle,'Linewidth',2,'EraseMode','XOR');
	else
		sine_filt_handle = plot(NaN,NaN,'k-.');
		set(sine_filt_handle,'Linewidth',2,'EraseMode','XOR');
	end;

%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_alias'),

	[existFlag,figNumber]=figflag('Aliasing');
    	if existFlag,
		close(fig_alias);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_alias_def'),

	[existFlag,figNumber]=figflag('Aliasing');
    	if existFlag,
		close(fig_alias);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

function sampling(operation);
% SAMPLING 	Module illustrating sampling.
%
% 		Continuous time poles and zeros can be moved.
%		The discrete time poles and zeros are updated.
%		There are three different systems to choose among.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997, B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN


global fig_samp ccs_col fig_ccs fig_val_samp
global cont_axes_samp disc_axes_samp erase_samp
global polec_handle zeroc_handle
global poled_handle zerod_handle poled_handle1 poled_handle2
global polec_handle1 polec_handle2 
global A B C D ac ac0 bc bc0 ad ad0 bd bd0 ad1 ad2
global x y
global sli_h_samp h_min_samp h_max h_cur_samp h_label_samp
global ex1 ex2 motor 
global system_samp error_samp help_samp



if nargin == 0,
	operation = 'show';
end;

%-- checks if the window already exists
if strcmp(operation,'show'),
   [existFlag,figNumber]=figflag('Sampling of system');
    if ~existFlag,
	sampling('winit');
	sampling('init');
        [existFlag,figNumber]=figflag('Sampling of system');
    else
	clf;
	sampling('init');
    end;


%%------------ SYSTEM 0------------------------------------
%%---------------------------------------------------------

elseif strcmp(operation,'system_samp0'),
	watchon;
	set(error_samp,'Visible','off');
	bc = 1;
	ac = [1 1];
	bc0 = bc;
	ac0 = ac;
	subplot(224);
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');			
	subplot(222);
	cla;
	%-- plot imaginary axis
	y=-2:1:2;
	plot(zeros(length(y)),y,'k');

	%-- plot continuous time poles and zeros
	if ccs_col == 1,	
		polec_handle = plot(roots(ac),0,'rx');
		set(polec_handle,'Linewidth',2,'Markersize',10, ...
			'EraseMode', 'XOR');
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ro');
		set(zeroc_handle,'Linewidth',2,'Markersize',7, ...
			'EraseMode', 'XOR');
	else
		polec_handle = plot(roots(ac),0,'kx');
		set(polec_handle,'Linewidth',2,'Markersize',10, ...
			'EraseMode', 'XOR');
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ko');
		set(zeroc_handle,'Linewidth',2,'Markersize',7, ...
			'EraseMode', 'XOR');
	end;

	[A,B,C,D] = tf2ss(bc,ac);

	%-- get the right value of h
	set(sli_h_samp,'Val',0.5);
	h = get(sli_h_samp,'Val');
	set(h_cur_samp,'String',num2str(get(sli_h_samp,'Val')));

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);
	bd0 = bd;
	ad0 = ad;
	subplot(224);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

	%-- make poles and zeros movable
	set(polec_handle,'ButtonDownFcn','sampling(''move_pole'')');
	set(zeroc_handle,'ButtonDownFcn','sampling(''move_zero'')');
	set(sli_h_samp,'CallBack','sampling(''move_sli_h_samp'')');
	watchoff;

%%------------ SYSTEM 1------------------------------------
%%---------------------------------------------------------

elseif strcmp(operation,'system_samp1'),
	watchon;
	set(error_samp,'Visible','off');
	bc = 1;
	ac = [1 0 1];
	bc0 = bc;
	ac0 = ac;
	subplot(224);
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');			
	subplot(222);
	cla;
	%-- plot imaginary axis
	y=-2:1:2;
	plot(zeros(length(y)),y,'k');

	%-- plot continuous time poles and zeros
	if ccs_col == 1,	
		polec_handle = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(polec_handle,'Linewidth',2,'Markersize',10, ...
			'EraseMode', 'XOR');
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ro');
		set(zeroc_handle,'Linewidth',2,'Markersize',7, ...
			'EraseMode', 'XOR');
	else
		polec_handle = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(polec_handle,'Linewidth',2,'Markersize',10, ...
			'EraseMode', 'XOR');
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ko');
		set(zeroc_handle,'Linewidth',2,'Markersize',7, ...
			'EraseMode', 'XOR');
	end;

	[A,B,C,D] = tf2ss(bc,ac);

	%-- get the right value of h
	set(sli_h_samp,'Val',0.5);
	h = get(sli_h_samp,'Val');
	set(h_cur_samp,'String',num2str(get(sli_h_samp,'Val')));

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);
	bd0 = bd;
	ad0 = ad;
	subplot(224);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

	%-- make poles and zeros movable
	set(polec_handle,'ButtonDownFcn','sampling(''move_pole'')');
	set(zeroc_handle,'ButtonDownFcn','sampling(''move_zero'')');
	set(sli_h_samp,'CallBack','sampling(''move_sli_h_samp'')');
	watchoff;


%%-------------SYSTEM 2 ------------------------------------
%%----------------------------------------------------------

elseif strcmp(operation,'system_samp2'),
	watchon;
	set(error_samp,'Visible','off');
	bc = [1 1];
	ac = [1 1 1];
	bc0 = bc;
	ac0 = ac;
	subplot(224);

	%-- plot unit circle
	t=0:.1:6.3;				
	plot(sin(t),cos(t),'k-');
	subplot(222);
	cla;
	%-- plot imaginary axis
	y=-2:1:2;
	plot(zeros(length(y)),y,'k');

	%-- plot continuous time poles and zeros
	if ccs_col == 1,
		polec_handle = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(polec_handle,'Linewidth',2,'EraseMode','xor', ...
			'Markersize',10);
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ro');
		set(zeroc_handle,'Linewidth',2,'EraseMode','xor', ...
			'Markersize',7);
		[A,B,C,D] = tf2ss(bc,ac);
	else
		polec_handle = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(polec_handle,'Linewidth',2,'EraseMode','xor', ...
			'Markersize',10);
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ko');
		set(zeroc_handle,'Linewidth',2,'EraseMode','xor', ...
			'Markersize',7);
		[A,B,C,D] = tf2ss(bc,ac);
	end;		

	%-- get the right value of h
	set(sli_h_samp,'Val',0.5);
	h = get(sli_h_samp,'Val');
	set(h_cur_samp,'String',num2str(get(sli_h_samp,'Val')));

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);
	bd0 = bd;
	ad0 = ad;
	subplot(224);
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

	%-- make poles and zeros movable
	set(polec_handle,'ButtonDownFcn','sampling(''move_pole'')');
	set(zeroc_handle,'ButtonDownFcn','sampling(''move_zero'')');
	set(sli_h_samp,'CallBack','sampling(''move_sli_h_samp'')');
	watchoff;


%%--------------- MOVING POLES -----------------------------

elseif strcmp(operation,'moving_poles'),
	currpoint = get(cont_axes_samp, 'CurrentPoint');
	x = currpoint(1,1);
	y = currpoint(1,2);
	%-- update location while moving
	if get(system_samp,'value')==2,
		set(polec_handle, 'XData', x, 'YData', 0);
	else
		set(polec_handle, 'XData', [x x], 'YData', [y -y]);
	end;

	if get(system_samp,'value') ==2, ac=[1 -x];
	else ac = [1 -2*x x^2+y^2]; end;
	[A,B,C,D] = tf2ss(bc,ac);

	%-- get correct value of h
	h = get(sli_h_samp,'Val');

	%-- sample system	
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);
	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

elseif strcmp(operation,'moved_poles'),  	

	set(fig_samp, 'WindowButtonMotionFcn', '', ...
                        'WindowButtonUpFcn', '');

elseif strcmp(operation,'move_pole'),
	set(fig_samp, 'WindowButtonMotionFcn', ...
	'sampling(''moving_poles'');', ...
                  'WindowButtonUpFcn', ...
        'sampling(''moved_poles'');');


%%---------------------------- MOTOR ---------------------------
%%--------------------------------------------------------------

elseif strcmp(operation,'motor'),
	watchon;
	set(error_samp,'Visible','off');

	%-- physical parameters
	om0 = 1;
	j1 = 10/9;
	j2 = 10;
	k = 1;
	d = 0.1;
	ki = 1;
	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;

	subplot(224);
	%-- plot unit circle
	t=0:.1:6.3;	
	plot(sin(t),cos(t),'k-');		
	subplot(222);
	cla;
	%-- plot imaginary axis
	y=-2:1:2;
	plot(zeros(length(y)),y,'k');
	[bc,ac] = ss2tf(A,B,C,D,1);
	bc = [bc(3) bc(4)];
	bc0 = bc;
	ac0 = ac;

	%-- plot continuous time poles and zeros
	if ccs_col == 1,	
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ro');
	else
		zeroc_handle = plot(real(roots(bc)),imag(roots(bc)),'ko');
	end;
	set(zeroc_handle,'Linewidth',2,'Markersize',7,'EraseMode','xor');
	poles = roots(ac);
	ac1 = poly(poles(1));
	ac2 = poly(poles(2));
	ac3 = poly(poles(3));
	ac23 = conv(ac2,ac3);
	if ccs_col == 1,
		polec_handle1 = plot(real(roots(ac1)),imag(roots(ac1)),'rx');
		set(polec_handle1,'Linewidth',2, ...
		'EraseMode', 'XOR','Markersize',10);
		polec_handle2 = plot(real(roots(ac23)),imag(roots(ac23)),'rx');
		set(polec_handle2,'Linewidth',2,'Markersize',10, ...
		'EraseMode', 'XOR');
	else
		polec_handle1 = plot(real(roots(ac1)),imag(roots(ac1)),'kx');
		set(polec_handle1,'Linewidth',2,'Markersize',10, ...
		'EraseMode', 'XOR');
		polec_handle2 = plot(real(roots(ac23)),imag(roots(ac23)),'kx');
		set(polec_handle2,'Linewidth',2,'Markersize',10, ...
		'EraseMode', 'XOR');
	end;

	%-- get correct value of h
	set(sli_h_samp,'Val',0.5);
	h = get(sli_h_samp,'Val');
	set(h_cur_samp,'String',num2str(get(sli_h_samp,'Val')));

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);
	bd0 = bd;
	ad0 = ad;
	subplot(224);

	%-- discrete time poles and zeros
	poles = roots(ad);
	ad1 = poly(poles(1));
	ad2 = poly(poles(2));
	ad3 = poly(poles(3));
	ad23 = conv(ad2,ad3);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData',imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

	%-- make poles and zeros movable
	set(polec_handle1,'ButtonDownFcn','sampling(''move1'')');
	set(polec_handle2,'ButtonDownFcn','sampling(''move2'')');
	set(zeroc_handle,'ButtonDownFcn','sampling(''move_zero'')');
	set(sli_h_samp,'CallBack','sampling(''move_sli_h_samp'')');
	watchoff;


%%-------------- MOVING POLES 1-------------------------------

elseif strcmp(operation,'move1'),
	set(fig_samp, 'WindowButtonMotionFcn', ...
	'sampling(''moving_poles1'');',...
                  'WindowButtonUpFcn', ...
        'sampling(''moved_poles1'');');

elseif strcmp(operation,'moving_poles1'),
	currpoint = get(cont_axes_samp, 'CurrentPoint');
	x = currpoint(1,1);
	%-- update location while moving
	set(polec_handle1, 'XData',x, 'YData',0);

	x2 = get(polec_handle2,'XData');
	y2 = get(polec_handle2,'YData');
	ac1 = [1 -x];
	ac2 = [1 -2*x2(1) x2(1)^2+y2(1)^2];
	ac = conv(ac1,ac2);
	[A,B,C,D] = tf2ss(bc,ac);
	h = get(sli_h_samp,'Val');

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

elseif strcmp(operation,'moved_poles1'),   	

	set(fig_samp, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');


%%-------------- MOVING POLES 2-------------------------------

elseif strcmp(operation,'move2'),
	set(fig_samp, 'WindowButtonMotionFcn', ...
	'sampling(''moving_poles2'');', ...
                  'WindowButtonUpFcn', ...
        'sampling(''moved_poles2'');');

elseif strcmp(operation,'moving_poles2'),
	currpoint = get(cont_axes_samp, 'CurrentPoint');
	x = currpoint(1,1);
	y = currpoint(1,2);
	%-- update location while moving
	set(polec_handle2, 'XData', [x x], 'YData', [y -y]);

	x1 = get(polec_handle1,'XData');
	ac1 = [1 -x1];
	ac2 = [1 -2*x x^2+y^2];
	ac = conv(ac1,ac2);
	[A,B,C,D] = tf2ss(bc,ac);
	h = get(sli_h_samp,'Val');

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

elseif strcmp(operation,'moved_poles2'),		

	set(fig_samp, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');


%%------------ MOVING ZEROS --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'move_zero'),
	set(fig_samp, 'WindowButtonMotionFcn', ...
	'sampling(''moving_zeros'');', ...
                  'WindowButtonUpFcn', ...
        'sampling(''moved_zeros'');');

elseif strcmp(operation,'moving_zeros'),
	currpoint = get(cont_axes_samp, 'CurrentPoint');
	x = currpoint(1,1);
	y = currpoint(1,2);
	%-- update location while moving
	set(zeroc_handle, 'XData',x, 'YData',0);

	%-- update plots when moving
  	set(zeroc_handle, 'XData',x, 'YData',0);
	bc = [1 -x];
	[A,B,C,D] = tf2ss(bc,ac);

	%-- get correct value of h
	h = get(sli_h_samp,'Val');

	%-- sample system	
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));

elseif strcmp(operation,'moved_zeros'), 	

	set(fig_samp, 'WindowButtonMotionFcn', ...
		'', ...
                        'WindowButtonUpFcn', ...
		'');
    

%%---------PLOTS ORIGINAL AND LAST SYSTEM ---------------
%%-------------------------------------------------------

elseif strcmp(operation,'recalc');
   	watchon;
   	if get(system_samp,'Value') ==2|get(system_samp,'Value') ==3|...
   	get(system_samp,'Value') ==4|get(system_samp,'Value') ==5,

		subplot(224);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		%-- plot most resent poles and zeros
		if ccs_col == 1,
			p = plot(real(roots(ad)),imag(roots(ad)),'rx');
			set(p,'Linewidth',2,'Markersize',10);
			z = plot(real(roots(bd)),imag(roots(bd)),'ro');
			set(z,'Linewidth',2,'Markersize',7);
		else
			p = plot(real(roots(ad)),imag(roots(ad)),'kx');
			set(p,'Linewidth',2,'Markersize',10);
			z = plot(real(roots(bd)),imag(roots(bd)),'ko');
			set(z,'Linewidth',2,'Markersize',7);
		end;
	
   	end;
   	watchoff;


%%-------------------- SLIDER -------------------------------
%%-----------------------------------------------------------

elseif strcmp(operation,'move_sli_h_samp'),
 
	%-- set current value of h to correct value
	set(h_cur_samp,'String',num2str(get(sli_h_samp,'Val')));
	h = get(sli_h_samp,'Val');

	%-- sample system
	[Phi,Gamma] = c2d(A,B,h);
	[bd,ad] = ss2tf(Phi,Gamma,C,D,1);

	%-- updating position of discrete poles and zeros
	set(poled_handle, 'XData', real(roots(ad)), ...
		'YData', imag(roots(ad)));
	set(zerod_handle, 'XData', real(roots(bd)), ...
		'YData', imag(roots(bd)));


%%-------------- POPUP-----------------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'popup'),

	set(error_samp,'Visible','off');

	%-- go to chosen system
	if get(system_samp,'value')==1
 		subplot(222);cla;
		subplot(224);cla;t=0:.1:6.3;plot(sin(t),cos(t),'k-');
		set(sli_h_samp,'CallBack','sampling(''wrong'');');
		%-- creating handles for discrete poles and zeros
		if ccs_col == 1,
			poled_handle = plot(NaN, NaN, 'rx');
			set(poled_handle, 'LineWidth', 2, 'EraseMode', ...
				'XOR','Markersize',10);
			zerod_handle = plot(NaN, NaN, 'ro');
			set(zerod_handle, 'LineWidth', 2, 'EraseMode', ... 
				'XOR','Markersize',7);
		else
			poled_handle = plot(NaN, NaN, 'kx');
			set(poled_handle, 'LineWidth', 2, 'EraseMode', ...
				'XOR','Markersize',10);
			zerod_handle = plot(NaN, NaN, 'ko');
			set(zerod_handle, 'LineWidth', 2, 'EraseMode', ... 
				'XOR','Markersize',7);
		end;
		set(erase_samp,'Value',1);
	elseif get(system_samp,'value')==2,
 		sampling('system_samp0');
	elseif get(system_samp,'value')==3,
 		sampling('system_samp1');
	elseif get(system_samp,'value')==4, 
 		sampling('system_samp2');
	elseif get(system_samp,'value')==5, 
 		sampling('motor');
	end;


%%-------------- POPUP ERASE----------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'popup_erase'),

	if get(erase_samp,'value')==1
		subplot(224);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');
		if ccs_col == 1,
			poled_handle =...
			 plot(real(roots(ad)), imag(roots(ad)), 'rx');
			set(poled_handle, 'LineWidth', 2,...
			 'EraseMode', 'XOR','Markersize',10);
			zerod_handle =...
			 plot(real(roots(bd)), imag(roots(bd)), 'ro');
			set(zerod_handle, 'LineWidth', 2, 'EraseMode', ...
			'XOR','Markersize',7);
		else
			poled_handle =...
			 plot(real(roots(ad)), imag(roots(ad)), 'kx');
			set(poled_handle, 'LineWidth', 2,...
			 'EraseMode', 'XOR','Markersize',10);
			zerod_handle =...
			 plot(real(roots(bd)), imag(roots(bd)), 'ko');
			set(zerod_handle, 'LineWidth', 2, 'EraseMode', ... 
				'XOR','Markersize',7);
		end;

	elseif get(erase_samp,'value')==2,
 		set(poled_handle, 'EraseMode', 'None');
		set(zerod_handle, 'EraseMode', 'None');
	end;


%%---------------- WRONG -----------------------------------------
%%---------------------------------------------------------------
elseif strcmp(operation,'wrong'),

	set(error_samp,'Visible','on');


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_samp'),
   ttlStr='Sampling help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' This demo illustrates where the poles and   '  
         ' zeros of a system end up when the system is '
	 ' sampled. It also illustrates how the samp-  '
	 ' ling interval influences the result. In con-'
	 ' tinuous time the stability area, in the com-'
	 ' plex s-plane, is the left half-plane. This  '
	 ' area is mapped on to the unit circle, in the'
	 ' complex z-plane, when the system is sampled.'
     	 ' A zero-order-hold circuit is used for the   '
	 ' sampling.                                   '
	 '                                             '                 
	 ' Choose a system. Then the poles and zeros,  '
	 ' in the continuous time plot, can be moved   '
	 ' by grabbing them with the pointer.          '
	 '                                             '
	 ' Choosing "EraseMode XOR" means that only    '
	 ' the most recent discrete poles and zeros    '
	 ' are shown. Choosing "None" means that old   '];

   hlpStr2= ...
	[' discrete poles and zeros are also visible.  '
	 ' That is, in this case nothing is erased .   '];
     
    hwin(ttlStr,hlpStr1,hlpStr2);  


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_samp'),
   ttlStr='Sampling theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Chapter 2 in CCS p. 30 for reading more '
	 ' about sampling and discrete time systems.   '
         '                                             '
	 ' The mapping of poles and zeros from         '
	 ' continuous- to discrete-time is dealt with  '
	 ' in Section 2.8 p. 61-66 and the choice of   '
	 ' sampling period in Section 2.9 p. 66-68.    ' 
	 '                                             '
	 ' The robot mechanism process is further de-  '
	 ' scribed in CCS Section 4.7.                 '];  
     
    hwin(ttlStr,hlpStr); 


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_samp'),
   ttlStr='Sampling hints...';
    hlpStr= ...                                           
        ['                                             '  
      	 ' Choose system G(s)=1/(s^2+a1s+a2). Notice   '
	 ' that the continuous time system has no zeros'
	 ' while the discrete system has a zero in -1. '
	 '                                             '
	 ' The continuous time poles are situated on   '
	 ' the imaginary axis, which is the stability  '
	 ' limit. In discrete time, the poles are also '
	 ' situated on the stability limit, which, in  '
	 ' this case, is the unit circle. Change h, and'
	 ' see how the poles move on the stability     '
         ' bounder.                                    '  
	 '                                             '
	 ' Move the continuous time poles towards -Inf.'
	 ' Then the discrete time poles move towards   '
	 ' the origin.                                 '];  
     
    hwin(ttlStr,hlpStr); 


%%------------------- VALUES --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'values_samp'), 

	%-- checks if the window already exists
   	[existFlag,figNumber]=figflag('Values');
    	if ~existFlag,
		fig_val_samp = figure('Name','Values','NumberTitle'...
		,'Off','BackingStore','Off',...
		'Units','Normalized',...
		'Position',[0.05 0.05 0.3 0.3]);
	 	[existFlag,figNumber]=figflag('Values');

    	else
		clf;
        end;

	figure(fig_val_samp);
	axes('Visible','off');
	close_val = uicontrol(fig_val_samp,'Style','Push','String','Close',...
	'Units','normalized','Position',[0.8 0.03 0.17 0.07],...
	'Callback','close;','Fontsize',11);

	if get(system_samp,'Value')~=1,

		text(0.01,0.95,...
		'Continuous time system:','Color','k','Fontsize',11);
		text(0.01,0.55,...
		'Discrete time system:','Color','k','Fontsize',11);
		ac2_str = num2str(ac(2));
		if get(system_samp','Value')~=2,
			ac3_str = num2str(ac(3));
		end;
		ad2_str = num2str(ad(2));
		if get(system_samp','Value')~=2,
			ad3_str = num2str(ad(3));
		end;
		bd2_str = num2str(bd(2));
		if get(system_samp','Value')~=2,
			bd3_str = num2str(bd(3));
		end;
		if get(system_samp','Value')==2,
			text(0.01,0.85,'B(s)= 1','Fontsize',11);
			text(0.01,0.75,'A(s)=[1','Fontsize',11);
			text(0.23,0.75,ac2_str,'Fontsize',11);
			text(0.48,0.75,']','Fontsize',11);
			text(0.01,0.45,'B(q)= [','Fontsize',11);
			text(0.20,0.45,bd2_str,'Fontsize',11);
			text(0.50,0.45,']','Fontsize',11);	
			text(0.01,0.35,'A(q)=[1','Fontsize',11);
			text(0.23,0.35,ad2_str,'Fontsize',11);
			text(0.48,0.35,']','Fontsize',11);
		elseif get(system_samp','Value')==3,
			text(0.01,0.85,'B(s)= 1','Fontsize',11);
			text(0.01,0.75,'A(s)=[1','Fontsize',11);
			text(0.23,0.75,ac2_str,'Fontsize',11);
			text(0.48,0.75,ac3_str,'Fontsize',11);
			text(0.73,0.75,']','Fontsize',11);
			text(0.01,0.45,'B(q)= [','Fontsize',11);
			text(0.20,0.45,bd2_str,'Fontsize',11);
			text(0.50,0.45,bd3_str,'Fontsize',11);
			text(0.80,0.45,']','Fontsize',11);	
			text(0.01,0.35,'A(q)=[1','Fontsize',11);
			text(0.23,0.35,ad2_str,'Fontsize',11);
			text(0.48,0.35,ad3_str,'Fontsize',11);
			text(0.73,0.35,']','Fontsize',11);
		elseif get(system_samp','Value')==4,
			bc2_str = num2str(bc(2));
			text(0.01,0.85,'B(s)=[1','Fontsize',11);
			text(0.23,0.85,bc2_str,'Fontsize',11);
			text(0.45,0.85,']','Fontsize',11);
			text(0.01,0.75,'A(s)=[1','Fontsize',11);
			text(0.23,0.75,ac2_str,'Fontsize',11);
			text(0.48,0.75,ac3_str,'Fontsize',11);
			text(0.73,0.75,']','Fontsize',11);
			text(0.01,0.45,'B(q)= [','Fontsize',11);
			text(0.20,0.45,bd2_str,'Fontsize',11);
			text(0.50,0.45,bd3_str,'Fontsize',11);
			text(0.80,0.45,']','Fontsize',11);	
			text(0.01,0.35,'A(q)=[1','Fontsize',11);
			text(0.23,0.35,ad2_str,'Fontsize',11);
			text(0.48,0.35,ad3_str,'Fontsize',11);
			text(0.73,0.35,']','Fontsize',11);
		elseif get(system_samp,'Value')==5,
			ac4_str = num2str(ac(4));
			bc1_str = num2str(bc(1));
			bc2_str = num2str(bc(2));
			ad4_str = num2str(ad(4));
			bd4_str = num2str(bd(4));
			text(0.01,0.85,'B(s)=[','Fontsize',11);
			text(0.20,0.85,bc1_str,'Fontsize',11);
			text(0.50,0.85,bc2_str,'Fontsize',11);
			text(0.80,0.85,']','Fontsize',11);
			text(0.01,0.75,'A(s)=[1','Fontsize',11);
			text(0.23,0.75,ac2_str,'Fontsize',11);
			text(0.48,0.75,ac3_str,'Fontsize',11);
			text(0.73,0.75,ac4_str,'Fontsize',11);
			text(1,0.75,']','Fontsize',11);
			text(0.01,0.45,'B(q)=[','Fontsize',11);
			text(0.16,0.45,bd2_str,'Fontsize',11);
			text(0.46,0.45,bd3_str,'Fontsize',11);
			text(0.76,0.45,bd4_str,'Fontsize',11);
			text(1.1,0.45,']','Fontsize',11);	
			text(0.01,0.35,'A(q)=[1','Fontsize',11);
			text(0.23,0.35,ad2_str,'Fontsize',11);
			text(0.48,0.35,ad3_str,'Fontsize',11);
			text(0.73,0.35,ad4_str,'Fontsize',11);
			text(1.1,0.35,']','Fontsize',11);
		end;

	else
		text(0.2,0.5,'No system defined.',...
		'Color','r','Fontsize',14);		
	end;


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit'),

	%-- creates main window
	fig_samp = figure('Name','Sampling of system','NumberTitle'...
	,'Off','BackingStore','Off','DefaultUicontrolFontSize',11);
%	if strcmp(computer,'PCWIN'),
%		set(fig_samp,'Color',[0.8 0.8 0.8]);
%	else
%		set(fig_samp,'Color',[0.8 0.8 0.8]);
%	end;

elseif strcmp(operation,'init'),

	watchon;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_samp,'Style','Frame',...
	'Units','normalized','Position',[0.0161 0.0214 0.1786 0.9524]);

	main_samp = uicontrol(fig_samp,'Style','Push',...
	'String','Main Menu',...
	'Units','normalized',...
	'Position',[0.0339 0.8667 0.1429 0.0595],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','sampling(''close_samp'');');

	help_samp = uicontrol(fig_samp,'Style','Push','String','Help!',...
	'Units','normalized','Position',[0.0339 0.7833 0.1429 0.0595],...
	'BackgroundColor',[1 1 0.3],...
	'Callback','sampling(''help_samp'');');

	theory_samp = uicontrol(fig_samp,'Style','Push','String','Theory',...
	'Units','normalized','Position',[0.0339 0.7000 0.1429 0.0595],...
	'BackgroundColor',[1 1 0.5],...
	'Callback','sampling(''theory_samp'');');

	hint_samp = uicontrol(fig_samp,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','sampling(''hints_samp'');');

	values_samp = uicontrol(fig_samp,'Style','Push','String','Values',...
	'Units','normalized','Position',[0.0339 0.2356 0.1429 0.0595],...
	'BackgroundColor',[0.9 1 0.9],...
	'Callback','sampling(''values_samp'');');

	close_samp = uicontrol(fig_samp,'Style','Push','String','Quit',...
	'Units','normalized','Position',[0.0339 0.0690 0.1429 0.0595],...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','sampling(''close_samp_def'');');


%%--------------- FRAME  -------------------------------------------

	frame_middle = uicontrol(fig_samp,'Style','Frame',...
	'Units','normalized','Position',[0.2036 0.0214 0.3214 0.9524]);

	system_samp = uicontrol(fig_samp,'Style','popup',...
	'Units','normalized',...
	'Position',[0.2304 0.8667 0.2679 0.0595],'String',...
	'Select system|1/(s+a1)|1/(s^2+a1s+a2)|(s+b)/(s^2+a1s+a2)|Robot mechanism',...
	'Callback','sampling(''popup'');');

	frame_h = uicontrol(fig_samp,'Style','Frame',...
	'Units','normalized','Position',[0.210 0.565 0.31 0.12]);

	sli_h_samp = uicontrol(fig_samp,'Style','slider',...
	'Units','normalized','Position',[0.27 0.571 0.214 0.048],...
	'Min',0.01,'Max',4,...
	'Value',1,'CallBack','sampling(''wrong'');');

	h_cur_samp = uicontrol(fig_samp,'Style','text',...
	'Units','normalized','Pos',[0.42 0.62 0.09 0.048],...
	'String',num2str(get(sli_h_samp,'Val')));

	h_min_samp = uicontrol(fig_samp,'Style','text',...
	'Units','normalized','Position',[0.214 0.575 0.052 0.048],...
	'String',num2str(get(sli_h_samp,'Min')));

	h_max_samp = uicontrol(fig_samp,'Style','text',...
	'Units','normalized','Position',[0.484 0.575 0.031 0.048],...
	'String',num2str(get(sli_h_samp,'Max')));

	h_label_samp = uicontrol(fig_samp,'Style','text',...
	'Units','normalized','Position',[0.22 0.62 0.196 0.048],...
	'String','Sampl.period.h=');

	erase_samp = uicontrol(fig_samp,'Style','popup',...
	'Units','normalized','Position',[0.232 0.4 0.27 0.06],'String',...
	'Erasemode XOR|Erasemode None',...
	'Callback','sampling(''popup_erase'');');


%%---------------- DIAGRAMS ----------------------------------------

	%-- create pole/zero diagrams
	cont_axes_samp = subplot(222);
	grid on;
	hold on;
	%-- plot imaginary axis
	y=-2:1:2;
	plot(zeros(length(y)),y,'k');
	title('Continuous time system','Color','k',...
	'FontName','Times','Fontsize',11);
	disc_axes_samp = subplot(224);
	grid on;
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');		
	axis('equal');
	title('Discrete time system','Color','k',...
	'FontName','Times','Fontsize',11);
	set(cont_axes_samp,'XLim',[-10 1],'YLim',[-2 2],'Clipping'...
	,'Off','XLimMode','Manual','YLimMode','Manual','DrawMode',...
	'Fast','Xcolor','k','Ycolor','k',...
	'FontName','Times','Fontsize',11);
	set(disc_axes_samp,'XLim',[-1.05 1.5],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','Xcolor','k','Ycolor','k',...
	'FontName','Times','Fontsize',11);

	%-- creating handles for discrete poles and zeros
	if ccs_col == 1,
		poled_handle = plot(NaN, NaN, 'rx');
		set(poled_handle, 'LineWidth', 2, 'EraseMode', ...
			'XOR','Markersize',10);
		zerod_handle = plot(NaN, NaN, 'ro');
		set(zerod_handle, 'LineWidth', 2, 'EraseMode', ...
			'XOR','Markersize',7);
	else
		poled_handle = plot(NaN, NaN, 'kx');
		set(poled_handle, 'LineWidth', 2, 'EraseMode', ...
			'XOR','Markersize',10);
		zerod_handle = plot(NaN, NaN, 'ko');
		set(zerod_handle, 'LineWidth', 2, 'EraseMode', ...
			'XOR','Markersize',7);
	end;

%%----------------ERROR MESSAGE ------------------------------

 	error_samp = uicontrol(fig_samp,'Style','text',...
	'Units','normalized','Position',[0.23 0.20 0.27 0.1],'String',...
	'NO, select system first!',...
	'BackgroundColor','r');
	set(error_samp,'Visible','off');

	watchoff;


%%------------------ CLOSE ----------------------------
%%-----------------------------------------------------

elseif strcmp(operation, 'close_samp'),

	[existFlag,figNumber]=figflag('Sampling of system');
    	if existFlag,
		close(fig_samp);		
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_samp_def'),

	[existFlag,figNumber]=figflag('Sampling of system');
    	if existFlag,
		close(fig_samp);	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;	

function [sys,x0]= regul(t,x,u,flag)
 

    if flag==0
      sys=[0 9 1 14 0 1];
      x0=zeros(1,9);
    
    elseif (flag==3) | (flag==2)

	R=u(1:4)';
        S=u(5:8)';
       	T=u(9:12)';

        ucn=u(13);
        yn=u(14);
	    
        ut=T*[ucn;x(1:3)]-R(2:4)*x(4:6)-S*[yn;x(7:9)];
   	if flag==3
        	sys=ut;
   	else 
       		sys=[ucn;x(1:2); ut; x(4:5); yn; x(7:8)];
    end

  else
        sys=[];
    end;

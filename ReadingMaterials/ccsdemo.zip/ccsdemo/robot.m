function robot(operation);
% ROBOT		Module illustrating a robot mechanism process.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_motor fig2_motor ccs_col fig_ccs
global k_cur j1_cur j2_cur d_cur
global sli_k sli_j1 sli_j2 sli_d
global ac bc A B C D

if nargin == 0,
	operation = 'show';
end;

%-- checks if window already exists
if strcmp(operation,'show'),
    [existFlag,figNumber]=figflag('Robot example');
    if ~existFlag,
        robot('winit_motor');
	robot('init_motor');
        [existFlag,figNumber]=figflag('Robot example');
    else
	clf;
	robot('init_motor');
    end;


%%------------------- CHANGE PARAMETERS -------------------------
%%---------------------------------------------------------------

elseif strcmp(operation,'move_slid');

	watchon;

	%-- get current parameters
	k = get(sli_k,'Val');			
	set(k_cur,'String',num2str(k));
	j1 = get(sli_j1,'Val');
	set(j1_cur,'String',num2str(j1));
	j2 = get(sli_j2,'Val');
	set(j2_cur,'String',num2str(j2));
	d = get(sli_d,'Val');
	set(d_cur,'String',num2str(d));

	ki = 1;
	om0 = sqrt(k*(j1+j2)/(j1*j2));
	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;
	[bc,ac] = ss2tf(A,B,C,D,1);

	%-- plot poles and zeros
	subplot(222);
	if ccs_col == 1,
		p = plot(real(roots(bc)),imag(roots(bc)),'ro');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(z,'Linewidth',2,'Markersize',9);
	else
		p = plot(real(roots(bc)),imag(roots(bc)),'ko');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(z,'Linewidth',2,'Markersize',9);
	end;

	%-- plot impulse response
	subplot(224);
	t = 0:0.5:100;
	if ccs_col == 1,
		plot(t,impulse(A,B,C,D,1,t),'r');
	else
		plot(t,impulse(A,B,C,D,1,t),'k--');
	end;		

	%-- calculate bode plots
	w = logspace(-1,1,1000);
	[mag,phase] = bode(A,B,C,D,1,w);	
	figure(fig2_motor);
	
	%-- plot magnitude
	subplot(211);
	if ccs_col == 1,
		loglog(w,mag,'r');
	else
		loglog(w,mag,'k--');
	end;

	%-- plot phase
	subplot(212);
	if ccs_col == 1,
		semilogx(w,phase,'r');
	else
		semilogx(w,phase,'k--');
	end;
	figure(fig_motor); 
	watchoff;



%%-------GIVES LAST PLOTS AND NOMINAL PLOTS -----------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'recalc'),

	watchon;
	subplot(222);
	cla;

	%-- plots most resent poles and zeros
	if ccs_col == 1,
		p = plot(real(roots(bc)),imag(roots(bc)),'ro');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(z,'Linewidth',2,'Markersize',9);
	else
		p = plot(real(roots(bc)),imag(roots(bc)),'ko');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(z,'Linewidth',2,'Markersize',9);
	end;

	%-- plot most resent impulse response
	subplot(224);
	cla;
	t = 0:0.5:100;
	if ccs_col == 1,
		plot(t,impulse(A,B,C,D,1,t),'r');
	else	
		plot(t,impulse(A,B,C,D,1,t),'k--');
	end;
	%-- calculates most resent bode plots
	w = logspace(-1,1,1000);
	[mag,phase] = bode(A,B,C,D,1,w);	
	figure(fig2_motor);

	%-- plot magnitude
	subplot(211);
	cla;
	if ccs_col == 1,
		loglog(w,mag,'r');
	else
		loglog(w,mag,'k--');
	end;

	%-- plot phase
	subplot(212);
	cla;
	if ccs_col == 1,
		semilogx(w,phase,'r');
	else
		semilogx(w,phase,'k--');
	end;
	figure(fig_motor);

	%-- get nominal parameters
	j11 = 10/9;				
	j21 = 10;
	k1 = 1;
	d1 = 0.1;
	ki1 = 1;
	om01 = sqrt(k1*(j11+j21)/(j11*j21));
	a1 = j11/(j11+j21);
	b11 = d1/(j11*om01);
	b21 = d1/(j21*om01);
	gam1 = ki1/(j11*om01);
	delta1 = 1/(j11*om01);
	A1 =om01* [0 1 -1;a1-1 -b11 b11;a1 b21 -b21];
	B1 = [0 gam1 0]';
	C1 = [0 0 om01];
	D1 = 0;
	[bc1,ac1] = ss2tf(A1,B1,C1,D1,1);

	%-- plot nominal poles and zeros
	subplot(222);
	if ccs_col == 1,
		z = plot(real(roots(bc1)),imag(roots(bc1)),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(roots(ac1)),imag(roots(ac1)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	end;	

	%-- plot nominal impulse response
	subplot(224);
	t = 0:0.5:100;
	if ccs_col == 1,
		plot(t,impulse(A1,B1,C1,D1,1,t),'r');	
	else
		plot(t,impulse(A1,B1,C1,D1,1,t),'k');
	end;

	%-- calculate nominal bode plots
	w = logspace(-1,1,1000);
	[mag,phase] = bode(A1,B1,C1,D1,1,w);	
	figure(fig2_motor);

	%-- plot magnitude 
	subplot(211);
	if ccs_col == 1,
		loglog(w,mag,'r'),
	else
		loglog(w,mag,'k'),
	end;

	%-- plot phase 
	subplot(212);
	if ccs_col == 1,
		semilogx(w,phase,'r'),
	else
		semilogx(w,phase,'k'),
	end;
	figure(fig_motor);
	watchoff;


%%------------------- RESET ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'reset_motor'),

	watchon;

	%-- get nominal parameters
	j1 = 10/9;				
	j2 = 10;
	k = 1;
	d = 0.1;
	ki = 1;
	om0 = sqrt(k*(j1+j2)/(j1*j2));
	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;

	%-- set sliders to nominal values
	set(k_cur,'String',num2str(k));		
	set(sli_k,'Val',k);
	set(j1_cur,'String',num2str(j1));
	set(sli_j1,'Val',j1);
	set(j2_cur,'String',num2str(j2));
	set(sli_j2,'Val',j2);
	set(d_cur,'String',num2str(d));
	set(sli_d,'Val',d);

	[bc,ac] = ss2tf(A,B,C,D,1);

	%-- plot poles and zeros of nominal system
	subplot(222);
	cla;
	if ccs_col == 1,
		p = plot(real(roots(bc)),imag(roots(bc)),'ro');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(z,'Linewidth',2,'Markersize',9);
	else
		p = plot(real(roots(bc)),imag(roots(bc)),'ko');	
		set(p,'Linewidth',2,'Markersize',7);
		z = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(z,'Linewidth',2,'Markersize',9);
	end;

	%-- plot impulse response
	subplot(224);
	cla;
	t = 0:0.5:100;
	if ccs_col == 1,
		plot(t,impulse(A,B,C,D,1,t),'r');
	else	
		plot(t,impulse(A,B,C,D,1,t),'k');		
	end;
	figure(fig2_motor);

	%-- calculate bode plots
	w = logspace(-1,1,1000);	
	[mag,phase] = bode(A,B,C,D,1,w);

	%-- plot magnitude	
	subplot(211);
	cla;
	if ccs_col == 1,
		loglog(w,mag,'r');
	else
 		loglog(w,mag,'k');
	end;

	%-- plot phase
	subplot(212);
	cla;
	if ccs_col == 1,
		semilogx(w,phase,'r');
	else
		semilogx(w,phase,'k');
	end;
	figure(fig_motor);
	watchoff;


%%------------------- HELP ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'help_motor'),
 
 ttlStr='Parameters 2 help...';
    hlpStr= ...                                           
        ['                                             '  
         ' This demo illustrates the effect of changing'  
         ' the parameters in the robot mechanism       '   
         ' process described in CCS pp. 156.           '
	 ' The open-loop characteristics are plotted.  '
	 '                                             '
	 ' The process consists off a motor that drives'
	 ' a load consisting of two masses coupled with'
	 ' a spring with spring constant k. The mo-    '
	 ' ments of inertia are J1 and J2. The damping '
	 ' in the spring is d.                         '];

   hwin(ttlStr,hlpStr); 


%%------------------- THEORY ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'theory_motor'),
 
 ttlStr='Parameters 2 theory...';
    hlpStr= ...                                           
        ['                                             '  
     	 ' See Section 4.7 CCS p. 156-160 for reading  ' 
	 ' more about the Robot mechanism process.     '];  

     hwin(ttlStr,hlpStr); 


%%------------------- HINTS ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'hints_motor'),
 
 ttlStr='Parameters 2 hints...';
    hlpStr= ...                                           
        ['                                             '  
     	 ' Change d from 0.1 to 3 and see how this     '
	 ' effects the system. For example, the peak in'
	 ' the magnitude response flattens when the    '
	 ' damping is increased.                       ']; 

     hwin(ttlStr,hlpStr);         


%%------------------- INIT ---------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_motor'),

	%-- create main window
	fig_motor = figure('Name','Robot example','NumberTitle'...
	,'Off','BackingStore','Off','Position',[50 400 560 420],...
	'Units', 'Normalized',...
	'Position', [0.0425 0.4433 0.4861 0.4667 ],...
	'DefaultUicontrolFontSize',11);
	set(fig_motor,'Color',[0.8,0.8,0.8]);



elseif strcmp(operation,'init_motor'),

%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_motor,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_motor = uicontrol(fig_motor,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'Callback','robot(''close_motor'');');

	help_motor = uicontrol(fig_motor,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','robot(''help_motor'');');

	theory_motor = uicontrol(fig_motor,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','robot(''theory_motor'');');

	hint_motor = uicontrol(fig_motor,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','robot(''hints_motor'');');

	clear_motor = uicontrol(fig_motor,'Style','Push',...
	'String','Clear plots',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','robot(''recalc'');');

	reset_motor = uicontrol(fig_motor,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized','Position', [0.0339 0.3667 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','robot(''reset_motor'');');


	close_motor = uicontrol(fig_motor,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','robot(''close_motor_def'');');


%%--------------- FRAME MIDDLE  -------------------------------

	frame_middle = uicontrol(fig_motor,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	text_middle = uicontrol('Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.7119 0.2857 0.0476 ],  ...
	'String','Physical parameters.','ForegroundColor','k');


%%------------------- SLIDERS ---------------------------------

	frame_d = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2107 0.5452 0.3071 0.1000 ]);

	sli_d = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.2750 0.5490 0.1786 0.0456 ],  ...
	'Min',0.01,'Max',4,...
	'Value',0.10);

	d_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4446 0.5952 0.0700 0.0450 ],  ...
	'String',num2str(get(sli_d,'Val')));

	d_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.5490 0.0625 0.0456 ],  ...
	'String',num2str(get(sli_d,'Min')));

	d_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4536 0.5490 0.0600 0.0456 ],  ...
	'String',num2str(get(sli_d,'Max')));

	d_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.5952 0.2321 0.0450 ],  ...
	'String','Damping d=');
	set(sli_d,'CallBack','robot(''move_slid'')');

	frame_j1 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2107 0.4238 0.3071 0.1000 ]);

	sli_j1 = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.2750 0.4280 0.1786 0.0460 ],  ...
	'Min',0.5,'Max',15,...
	'Value',10/9);

	j1_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4446 0.4738 0.0700 0.0450 ],  ...
	'String',num2str(get(sli_j1,'Val')));

	j1_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.4280 0.0625 0.0460 ],  ...
	'String',num2str(get(sli_j1,'Min')));

	j1_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4536 0.4280 0.0600 0.0460 ],  ...
	'String',num2str(get(sli_j1,'Max')));

	j1_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.4738 0.2321 0.0460 ],  ...
	'String','Mom. of inertia j1=');
	set(sli_j1,'CallBack','robot(''move_slid'')');

	frame_j2 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2107 0.3024 0.3071 0.1000 ]);

	sli_j2 = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.2750 0.3080 0.1786 0.0440 ],  ...
	'Min',5,'Max',15,...
	'Value',10);

	j2_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4446 0.3524 0.0700 0.0450 ],  ...
	'String',num2str(get(sli_j2,'Val')));

	j2_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.3080 0.0625 0.0440 ],  ...
	'String',num2str(get(sli_j2,'Min')));

	j2_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4536 0.3080 0.0600 0.0440 ],  ...
	'String',num2str(get(sli_j2,'Max')));

	j2_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.3524 0.2321 0.0450 ],  ...
	'String','Mom. of inertia j2=');
	set(sli_j2,'CallBack','robot(''move_slid'')');

	frame_k = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2107 0.1810 0.3071 0.1000 ]);

	sli_k = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.2750 0.1850 0.1786 0.0470 ],  ...
	'Min',0.1,'Max',5,...
	'Value',1);

	k_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4446 0.2350 0.0700 0.0410 ],  ...
	'String',num2str(get(sli_k,'Val')));

	k_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.1850 0.0625 0.0470 ],  ...
	'String',num2str(get(sli_k,'Min')));

	k_max=uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4536 0.1850 0.0600 0.0470 ],  ...
	'String',num2str(get(sli_k,'Max')));

	k_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2125 0.2350 0.2321 0.0410 ],  ...
	'String',' Spring constant k=');
	set(sli_k,'CallBack','robot(''move_slid'')');


%%---------------- DIAGRAMS ------------------------------------

	%-- creates pole/zero diagram
	pz_axes = subplot(222);			
	title('Pole/Zero diagram','Color','k',...
	'FontName','Times','Fontsize',11);
	grid on;
	hold on;
	set(pz_axes, 'XLim', [-15 1], 'YLim', [-2 2], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);

	%-- set nominal parameters
	j1 = 10/9;				
	j2 = 10;
	k = 1;
	d = 0.1;
	ki = 1;
	om0 = sqrt(k*(j1+j2)/(j1*j2));
	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;
	[bc,ac] = ss2tf(A,B,C,D,1);
	hold on;

	%-- plot nominal poles and zeros
	if ccs_col == 1,
		z = plot(real(roots(bc)),imag(roots(bc)),'ro');	
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(ac)),imag(roots(ac)),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(roots(bc)),imag(roots(bc)),'ko');	
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(roots(ac)),imag(roots(ac)),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

        %-- create impulse response diagram
	imp_axes = subplot(224);
	title('Impulse response','Color','k',...
	'FontName','Times','Fontsize',11);	
	grid on;
	hold on;
	set(imp_axes, 'XLim', [0 100], 'YLim', [0 0.2], 'DrawMode', 'Fast',...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'YTick',[0 0.1 0.2],...
	'FontName','Times','Fontsize',11);
	%-- plot impulse response
	t = 0:0.5:100;
	if ccs_col == 1,
		plot(t,impulse(A,B,C,D,1,t),'r');
	else
		plot(t,impulse(A,B,C,D,1,t),'k');
	end;
	grid on;
	

%%------------- CREATE WINDOW 2 ------------------------------------

	%-- checks if plot window already exists
	[existFlag,figNumber]=figflag('Bode plots, Robot example');
	if ~existFlag,
      		fig2_motor = figure('Name','Bode plots, Robot example',...
		'NumberTitle','Off',...
		'BackingStore','Off','Units', 'Normalized',...
		'Position', [0.5286 0.4433 0.4340 0.4667 ]);
		set(fig2_motor,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=figflag('Bode plots, Robot example');
	else
		clf;fig=gcf;
	end; 

	%-- create Bode axes
	mag_axes = subplot(211);
	title('Magnitude response','Color','k',...
	'FontName','Times','Fontsize',11);
	grid on;
	hold on;
	set(mag_axes, 'XLim', [0.1 10], 'YLim', [0.0001 10], 'DrawMode',...
	'Fast','XScale','log','YScale','log',...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);

	phase_axes = subplot(212);
	title('Phase response','Color','k',...
	'FontName','Times','Fontsize',11)
	grid on;
	hold on;
	set(phase_axes, 'XLim', [0.1 10], 'YLim', [-300 0], 'DrawMode',...
	'Fast','XScale','log',...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);

	%-- calculate bode plots
	w = logspace(-1,1,1000);
	[mag,phase] = bode(A,B,C,D,1,w);

	%-- plot magnitude	
	subplot(211);
	if ccs_col == 1,
		loglog(w,mag,'r'), 
	else
		loglog(w,mag,'k'),
	end;
	
	%-- plot phase
	subplot(212);
	if ccs_col == 1,
		semilogx(w,phase,'r'),
	else
		semilogx(w,phase,'k'),
	end;		

	figure(fig_motor);


%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_motor'),

	[existFlag,figNumber]=figflag('Robot example');
    	if existFlag,
		close(fig_motor);	
 	end;

	[existFlag,figNumber]=figflag('Bode plots, Robot example');
    	if existFlag,
		close(fig2_motor);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_motor_def'),

	[existFlag,figNumber]=figflag('Robot example');
    	if existFlag,
		close(fig_motor);	
 	end;

	[existFlag,figNumber]=figflag('Bode plots, Robot example');
    	if existFlag,
		close(fig2_motor);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;




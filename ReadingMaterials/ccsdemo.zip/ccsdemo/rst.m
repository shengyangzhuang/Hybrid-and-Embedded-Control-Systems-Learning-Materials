function rst(operation);
% RST		Module illustrating Pole placement design based on
%		the input-output model.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_rst fig2_rst ccs_col fig_ccs fig_val_rst
global help_box clear_box
global frame_am am_label frame_ao ao_label
global system_rst
global input_zeta input_om om_label zeta_label 
global input_alfa alfa_label
global input_Bc input_Ac Bc_label Ac_label charao_label
global h_cur slid
global choise1_rst choise2_rst
global u0 u y0 y
global save_syst load_syst
global control_axes
global error1_rst
global h0 zeta0 om0 alfa0 Bc Ac R S T Bd Ad Adm Ao
global time time0 ts us h

if nargin == 0,
	operation = 'show';
end;

%-- checks if the main window already exists
if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Pole Placement design');
	if ~existFlag,
      		rst('winit_rst');
      		rst('init_rst');		
 		[existFlag,figNumber]=figflag('Pole Placement design');
	else
		clf;
		rst('init_rst');
	end;


%%---------------SYSTEM ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'system'),

	figure(fig_rst);

	watchon;

	set(input_Bc,'Visible','off');
	set(input_Ac,'Visible','off');
	set(Bc_label,'Visible','off');
	set(Ac_label,'Visible','off');
	set(error1_rst,'Visible','off');

	figure(fig2_rst);
	subplot(211);
	cla;
	subplot(212);
	cla;
	figure(fig_rst);

 	if get(system_rst,'Value') ==2|get(system_rst,'Value') ==3|...
 	get(system_rst,'Value') ==4,

		set(input_zeta,'Visible','on');
		set(input_om,'Visible','on');

		%-- gt edit-values of omega, zeta and alfa 
		zeta = str2num(get(input_zeta,'String'));zeta0 = zeta;
		om = str2num(get(input_om,'String'));om0 = om;
		alfa = str2num(get(input_alfa,'String'));alfa0 = alfa;

		%-- get slider-value of sampling intervall h
		h = get(slid,'Value');h0 = h;
		set(h_cur,'String',num2str(get(slid,'Val')));

		%-- chose system					
		if get(system_rst,'value')==2,    

			% double integrator
			Bc = 1;
			Ac = [1 0 0];
			[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
			Bd=[Bd(2) Bd(3)];
			sys_rst = 2;

		elseif get(system_rst,'value')==3,    
	
			%-- harmonic oscillator
			Bc = 1;
			Ac = [1 0 1];
			[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
			Bd=[Bd(2) Bd(3)];
			sys_rst = 3;

		elseif get(system_rst,'value')==4,	

			%-- user gives system
			set(input_Bc,'Visible','on');
			set(input_Ac,'Visible','on');
			set(Bc_label,'Visible','on');
			set(Ac_label,'Visible','on');
			sys_rst = 4;
		end;

    		if get(system_rst,'value')==2|get(system_rst,'value')==3,  

			if get(choise1_rst,'Value') == 1,
				%-- no cancellation of process zero
				bminus = Bd;	
				bplus = 1;
				z = 1;
			else
				%-- cancellation of process zero
				bminus = Bd(1);	
				if length(Bd) == 1,
					%-- degree Bd=0
					bplus = 1;
				else
					%-- degree Bd=1
					bplus = [1 Bd(2)/Bd(1)];
				end;
				z = 2;
			end;	

			if get(choise2_rst,'value')==1,
				%-- regulator with integrator	
				Ar = [1 -1];	
				l = 1;
				int = 1;
			elseif get(choise2_rst,'value')==2,
				%-- regulator without integrator	
				Ar = 1;
				l = 0;
				int = 2;
			end;

			%-- compute desired characteristic polynomial
			Acm = [1 2*om*zeta om*om];
  			rch = roots(Acm)*h;
			Adm  = real(poly(exp(rch)));
			P = roots(Adm);
			subplot(222);
			cla;

			%-- plot unit circle in pole/zero diagram
			t=0:.1:6.3;
			plot(sin(t),cos(t),'k-');

			%-- plot roots of closed-loop system
			if ccs_col == 1,
				p = plot(real(P),imag(P),'rx');
			else
				p = plot(real(P),imag(P),'kx');
			end;
			set(p,'Linewidth',2,'Markersize',9);

			%-- plot zeros of closed-loop system
			if ccs_col == 1,
				z = plot(real(roots(bminus)),...
				imag(roots(bminus)),'ro');
			else
				z = plot(real(roots(bminus)),...
				imag(roots(bminus)),'ko');
			end;
			set(z,'Linewidth',2,'Markersize',7);

			%-- decide degree of Ao and compute Ao
			degAo=2*(length(Ad)-1)-(length(Adm)-1)-...
			(length(bplus)-1)+l-1;
			if degAo == 0,
				Ao = 1;	
				set(charao_label,'String','Ao(s)=1');
			elseif degAo == 1,			
				set(input_alfa,'Visible','on');
				alfa = str2num(get(input_alfa,'String'));
				Ao = [1 -exp(-alfa*h)];
				set(charao_label,'String','Ao(s)=(s+alfa)');
			elseif degAo == 2,
				set(input_alfa,'Visible','on');
				alfa = str2num(get(input_alfa,'String'));
				Ao = [1 -2*exp(-alfa*h) (exp(-alfa*h))^2];
				set(charao_label,'String','Ao(s)=(s+alfa)^2');
			end;
		
			%-- plot roots of observer polynomial Ao
			Po = roots(Ao);
			subplot(222);
			if ccs_col == 1,
				p = plot(real(Po),imag(Po),'gx');
			else
				p = plot(real(Po),imag(Po),'k+');
			end;
			set(p,'Linewidth',2,'Markersize',9);
	
			%-- RST-design
			ae      =conv(Ad,Ar);	
			be      = conv(bminus,1);
			aoam    = conv(Adm,Ao);

			%-- solving dab-equation
			na = length(ae);	
			nb = length(be);
			nc = length(aoam);
			ny = na - 1;
			if ny<1,
  				x = c/ae;
  				y = 0;
  				return;
			end;
			nx = nc - ny;
			aoam = [zeros(1,nb-nx-1) aoam];
			nc = length(aoam);
			nx = nc - ny;
			if nx<1,
  				x = 0;
  				y = aoam/be;
  				return;
			end;
			be = [zeros(1,nx-nb+1) be];
			za = zeros(1,nx-1);
			zb = zeros(1,ny-1);
			ma = toeplitz([ae za],[ae(1) za]);
			mb = toeplitz([be zb],[be(1) zb]);
			m = [ma mb];
			if rank(m)<min(size(m)),
  				disp('Singular problem due to common factors in 				A and B');
			end;
			xy = aoam/m';
			r1 = xy(1:nx);
			s = xy(nx+1:nc);
			r = conv(conv(r1,Ar),bplus);
			t0 = sum(Adm)/sum(bminus);
  			t = t0*conv(Ao,1);

 			S = s/r(1);
			T = t/r(1);
			R = r/r(1);


			time=0:h:100;time0=time;
			
			%-- load disturbance
			v1 = zeros(round(50/h),1);
			v = [v1;-0.2*ones(length(time0)-length(v1),1)];
		
			%-- reference signal				
			uc = ones(length(v),1);	

			%-- output signal
			n = size(conv(Ad,R),2)-size(conv(Bd,S),2);
			[y1,x]=dlsim(conv(Bd,T),...
			conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
			[y2,x] = dlsim(conv(Bd,R),...
			conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
			y=y1+y2;y0=y;
	
			%-- control signal
			[u1,x] = dlsim(conv(Ad,T),...
			conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
			[u2,x] = dlsim(conv(Bd,S),...
			conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
			u = u1-u2;u0=u;	

			%-- plot output signal
			figure(fig2_rst);
			subplot(211);
			if ccs_col == 1,
				plot(time0,y0,'r');
			else
				plot(time0,y0,'k');
			end;

			%-- plot control signal
			subplot(212);
			[ts0,us0]=stairs(time0,u0);
			if ccs_col == 1,
				plot(ts0,us0,'r');
			else
				plot(ts0,us0,'k');
			end;
   		end;
 	end;
    	figure(fig_rst);
	watchoff;


%%---------------CALCULATIONS ------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'polycalc'),

	figure(fig_rst);
	watchon;
	if get(system_rst,'Value') ==2|get(system_rst,'Value') ==3|...
	get(system_rst,'Value') ==4,

		set(error1_rst,'Visible','off');
		zeta = str2num(get(input_zeta,'String'));
		om = str2num(get(input_om,'String'));
		alfa = str2num(get(input_alfa,'String'));
		set(h_cur,'String',num2str(get(slid,'Val')));
		h = get(slid,'Value');

		%-- if no value, set zeta and omega to nominal values
		if isempty(zeta),
			zeta = zeta0;
			set(input_zeta,'String',num2str(zeta0));
		end;
		if isempty(om),
			om = om0;
			set(input_om,'String',num2str(om0));
		end;
		if isempty(alfa),
			alfa = alfa0;
			set(input_alfa,'String',num2str(alfa0));
		end;

		if get(system_rst,'value')==2,    	
			%-- double integrator
			Bc = 1;
			Ac = [1 0 0];
			[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
			Bd=[Bd(2) Bd(3)];
	
		elseif get(system_rst,'value')==3,    	
			%-- harmonic oscillator
			Bc = 1;
			Ac = [1 0 1];
			[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
			Bd=[Bd(2) Bd(3)];
		
		elseif get(system_rst,'value')==4, 	
			%-- user given system
			Bc = str2num(get(input_Bc,'String'));
			Ac = str2num(get(input_Ac,'String'));
			[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
			if length(Bd)==0|length(Bd)==1,
		
			elseif length(Bd)==2,
				Bd=Bd(2);
			elseif length(Bd)==3,
				Bd=[Bd(2) Bd(3)];
			end;
		end;

		a = size(Ac);			
		b = size(Bc);
  		if a(2)~=3|b(2) > 2|a(2)==3&Ac(1)==0,
			%-- error if not 2:nd order system
			set(error1_rst,'Visible','on');
  		else

		if get(choise1_rst,'Value') == 1,
			%-- no cancellation of process zero
			bminus = Bd;
			bplus = 1;
			z = 1;
		else
			%-- cancellation of process zero
			bminus = Bd(1);		
			if length(Bd) == 1,
				%-- numerator of 0:th order
				bplus = 1;
			else
				%-- numerator of 1:st order
				bplus = [1 Bd(2)/Bd(1)];
			end;
			z = 2;
		end;	

		if get(choise2_rst,'value')==1,
			%-- regulator design with integrator
			Ar = [1 -1];	
			l = 1;
			int = 1;
		elseif get(choise2_rst,'value')==2,
			%-- regulator design without integrator	
			Ar = 1;
			l = 0;
			int = 2;
		end;
	
		%-- compute desired characteristic polynomial
		Acm = [1 2*om*zeta om*om];
		rch = roots(Acm)*h;
		Adm  = real(poly(exp(rch))); 			
		P = roots(Adm);
		subplot(222);
		cla;

		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		%-- plot roots of closed-loop system
		if ccs_col == 1,
			p = plot(real(P),imag(P),'rx');
		else
			p = plot(real(P),imag(P),'kx');
		end;
		set(p,'Linewidth',2,'Markersize',9);

		%-- plot zeros of closed-loop system
		if ccs_col == 1,
			z = plot(real(roots(bminus)),imag(roots(bminus)),'ro');
		else
			z = plot(real(roots(bminus)),imag(roots(bminus)),'ko');
		end;
		set(z,'Linewidth',2,'Markersize',7);

		%-- decide degree of Ao and compute Ao
		degAo = 2*(length(Ad)-1)-(length(Adm)-1)-(length(bplus)-1)+l-1;
		if degAo == 0,
			Ao = 1;	
			set(charao_label,'String','Ao(s)=1');		
		elseif degAo == 1,
			set(input_alfa,'Visible','on');
			alfa = str2num(get(input_alfa,'String'));
			Ao = [1 -exp(-alfa*h)];
			set(charao_label,'String','Ao(s)=(s+alfa)');
		elseif degAo == 2,
			set(input_alfa,'Visible','on');
			alfa = str2num(get(input_alfa,'String'));
			Ao = [1 -2*exp(-alfa*h) (exp(-alfa*h))^2];
			set(charao_label,'String','Ao(s)=(s+alfa)^2');
		end;
		Po = roots(Ao);
		subplot(222);

		%-- plot roots of observer polynomial Ao
		if ccs_col == 1,
			p = plot(real(Po),imag(Po),'gx');
		else
			p = plot(real(Po),imag(Po),'k+');
		end;
		set(p,'Linewidth',2);

		%-- RST-design
		ae      =conv(Ad,Ar);			
		be      = conv(bminus,1);
		aoam    = conv(Adm,Ao);
	
		%-- solving dab-equation
		na = length(ae);			
		nb = length(be);
		nc = length(aoam);
		ny = na - 1;
		if ny<1,
  			x = c/ae;
  			y = 0;
  			return;
		end;
		nx = nc - ny;
		aoam = [zeros(1,nb-nx-1) aoam];
		nc = length(aoam);
		nx = nc - ny;
		if nx<1,
  			x = 0;
  			y = aoam/be;
  			return;
		end;
		be = [zeros(1,nx-nb+1) be];
		za = zeros(1,nx-1);
		zb = zeros(1,ny-1);
		ma = toeplitz([ae za],[ae(1) za]);
		mb = toeplitz([be zb],[be(1) zb]);
		m = [ma mb];
		if rank(m)<min(size(m)),
  			disp...
			('Singular problem due to common factors in A and B');
		end;
		xy = aoam/m';
		r1 = xy(1:nx);
		s = xy(nx+1:nc);
		r = conv(conv(r1,Ar),bplus);
		t0 = sum(Adm)/sum(bminus);
 		t = t0*conv(Ao,1);
 
		S = s/r(1);
		T = t/r(1);
		R = r/r(1);	

		time=0:h:100;

		%-- load disturbance
		v1 = zeros(round(50/h),1);
		v = [v1;-0.2*ones(length(time)-length(v1),1)];

		%-- reference signal
		uc = ones(length(v),1);		

		%-- output signal
		n = size(conv(Ad,R),2)-size(conv(Bd,S),2);
		[y1,x]=dlsim(conv(Bd,T),conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[y2,x] =...
		 dlsim(conv(Bd,R),conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		y=y1+y2;
	
		%-- control signal
		[u1,x] = dlsim(conv(Ad,T),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[u2,x] = dlsim(conv(Bd,S),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		u = u1-u2;	

		%-- plot output signal
		figure(fig2_rst);
		subplot(211);
		if ccs_col == 1,
			plot(time,y,'r');
		else
			plot(time,y,'k');
		end;

		%-- plot control signal
		subplot(212);
		[ts,us]=stairs(time,u);
		if ccs_col == 1,
			plot(ts,us,'r');
		else
			plot(ts,us,'k');
		end;
 		end;
	end;
	figure(fig_rst);
	watchoff;


%%---------------- CLEAR ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'polyclear'),

   	if get(system_rst,'Value') ==2|get(system_rst,'Value') ==3|...
   	get(system_rst,'Value') ==4,

		watchon;

		%-- plot output signal
		figure(fig2_rst);
		subplot(211);
		cla;
		if ccs_col == 1,
			plot(time,y,'r');
		else
			plot(time,y,'k');
		end;

		%-- plot control signal
		subplot(212);
		cla;
		[ts,us]=stairs(time,u);
		if ccs_col == 1,
			plot(ts,us,'r');
		else
			plot(ts,us,'k');
		end;
		figure(fig_rst);
		watchoff;

   	end;


%%---------------- RESET ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'polyreset'),

	if get(system_rst,'Value') ==2|get(system_rst,'Value') ==3|...
get(system_rst,'Value') ==4,
	
		watchon;

		%-- set variables to nominal values
		h = h0;
		zeta = zeta0;
		om = om0;
		alfa = alfa0;

		[Bd,Ad] = c2dm(Bc,Ac,h,'zoh');
		Bd=[Bd(2) Bd(3)];

		%-- set sliders and edits to nominal values
		set(slid,'Val',h);
		set(h_cur,'String',num2str(get(slid,'Val')));
		set(input_zeta,'String',num2str(zeta));	
		set(input_om,'String',num2str(om));
		set(input_alfa,'String',num2str(alfa));
		set(choise1_rst,'Value',1);
		set(choise2_rst,'Value',1);

		bminus = Bd;
		bplus = 1;
		z = 1;
		Ar = [1 -1];	
		l = 1;
		int = 1;

		%-- compute desired characteristic polynomial	
		Acm = [1 2*om*zeta om*om];
		rch = roots(Acm)*h;
		Adm  = real(poly(exp(rch))); 	
		P = roots(Adm);

		subplot(222);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		%-- plot roots of closed-loop system
		if ccs_col == 1,
			p = plot(real(P),imag(P),'rx');
		else
			p = plot(real(P),imag(P),'kx');	
		end;	
		set(p,'Linewidth',2,'Markersize',9);

		%-- plot zeros of closed-loop system
		if ccs_col == 1,
			z = plot(real(roots(bminus)),imag(roots(bminus)),'ro');
		else
			z = plot(real(roots(bminus)),imag(roots(bminus)),'ko');
		end;
		set(z,'Linewidth',2,'Markersize',7);

		%-- decide degree of Ao and compute Ao
		degAo = 2*(length(Ad)-1)-(length(Adm)-1)-(length(bplus)-1)+l-1;
		if degAo == 0,
			Ao = 1;
			set(charao_label,'String','1Ao(s)=');
		elseif degAo == 1,
			set(input_alfa,'Visible','on');
			alfa = str2num(get(input_alfa,'String'));
			Ao = [1 -exp(-alfa*h)];
			set(charao_label,'String','Ao(s)=(s+alfa)');
		elseif degAo == 2,
			set(input_alfa,'Visible','on');
			alfa = str2num(get(input_alfa,'String'));
			Ao = [1 -2*exp(-alfa*h) (exp(-alfa*h))^2];
			set(charao_label,'String','Ao(s)=(s+alfa)^2');
		end;
		Po = roots(Ao);

		%-- plot roots of observer polynomial Ao
		subplot(222);
		if ccs_col == 1,
			p = plot(real(Po),imag(Po),'gx');
		else
			p = plot(real(Po),imag(Po),'k+');
		end;
		set(p,'Linewidth',2);

		%-- RST-design
		ae      =conv(Ad,Ar);				
		be      = conv(bminus,1);
		aoam    = conv(Adm,Ao);
	
		%-- solving dab-equation
		na = length(ae);			
		nb = length(be);
		nc = length(aoam);
		ny = na - 1;
		if ny<1,
  			x = c/ae;
  			y = 0;
  			return;
		end;
		nx = nc - ny;
		aoam = [zeros(1,nb-nx-1) aoam];
		nc = length(aoam);
		nx = nc - ny;
		if nx<1,
  			x = 0;
  			y = aoam/be;
  			return;
		end;
		be = [zeros(1,nx-nb+1) be];
		za = zeros(1,nx-1);
		zb = zeros(1,ny-1);
		ma = toeplitz([ae za],[ae(1) za]);
		mb = toeplitz([be zb],[be(1) zb]);
		m = [ma mb];
		xy = aoam/m';
		r1 = xy(1:nx);
		s = xy(nx+1:nc);
		r = conv(conv(r1,Ar),bplus);
		t0 = sum(Adm)/sum(bminus);
  		t = t0*conv(Ao,1);
 
		S = s/r(1);
		T = t/r(1);
		R = r/r(1);

		time=0:h:100;time0 = time;

		%-- load disturbance
		v1 = zeros(round(50/h),1);
		v = [v1;-0.2*ones(length(time0)-length(v1),1)];
		
		%-- reference signal				
		uc = ones(length(v),1);		

		% compute output
		n = size(conv(Ad,R),2)-size(conv(Bd,S),2);
		[y1,x]=dlsim(conv(Bd,T),conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[y2,x]...
		 = dlsim(conv(Bd,R),conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		y = y1+y2;y0 = y;
	
		%-- control signal
		[u1,x] = dlsim(conv(Ad,T),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[u2,x] = dlsim(conv(Bd,S),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		u = u1-u2;u0=u;	

		figure(fig2_rst);
		%-- plot output
		subplot(211);
		cla;
		if ccs_col == 1,
			plot(time,y,'r');
		else
			plot(time,y,'k');
		end;

		%-- plot control signal
		subplot(212);
		cla;
		[ts0,us0]=stairs(time,u);
		if ccs_col == 1,
			plot(ts0,us0,'r');
		else
			plot(ts0,us0,'k');
		end;	
		figure(fig_rst);
		watchoff;
	end;	


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_rst'),
   ttlStr='Pole Placement design help...';
    hlpStr1= ...  
    	['                                             ' 
      	 ' This demo illustrates a design method based '
	 ' on the input-output model of the system. The'
	 ' purpose is to design a linear regulator and '
	 ' to determine its parameters so that the     '
	 ' closed-loop system has desired properties.  '
	 '                                             ' 
         ' The specifications that have to be made are '
         ' the Am-polynomial and the observer poly-    '  
         ' nomial. Am is the characteristic polynomial '
	 ' of the closed-loop system and is given in   '
         ' terms of the damping z and the natural fre- '
	 ' quency w, in continuous time. The Bm-poly-  '
	 ' nomial is chosen so that the stationary gain'
	 ' is 1.                                       '
	 '                                             '
	 ' In this demo you can choose between cancel- '
	 ' ling zeros or not and between having an in- '
	 ' tegrator in the controller or not.          '];


    hlpStr2= ...
	['                                             '
	 ' The observer-poles are all real and situated'
	 ' in the same place. The observer-polynomial  '
	 ' can be of 0:th, 1:st or 2:nd order.         '
         '                                             '	
	 ' The choice "make own" let you construct     '
	 ' your own system. Specify the Bc- and Ac-    ' 
	 ' polynomials. This system has to be          '
	 ' of order 2.                                 '
	 '                                             '
	 ' Notice! Do always enter Ac last. It is only '
	 ' this edit-box that enhances further actions.'
	 ' Also when you change this system you have to'
	 ' use the Ac editbox, to make the changes be  '
	 ' accepted.                                   '];            
     
    hwin(ttlStr,hlpStr1,hlpStr2);  


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_rst'),
   ttlStr='Pole Placement design theory...';
    hlpStr= ...                                           
        ['                                             '  
 	 ' See Chapter 5 in CCS p. 165 for reading     '
	 ' about "Pole Placement design based on input-'
	 ' output models".                             '
	 '                                             '
	 ' Design algorithms for RST-regulators are    '
	 ' on p. 168 and 186.                          '];  
     
    hwin(ttlStr,hlpStr);           


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_rst'),
   ttlStr='Pole Placement design hints...';
    hlpStr= ...   
        ['                                             '  
    	 ' Choose the Double integrator. Change w from '
	 ' 0.5 to 1. Increasing w, makes the response  '
	 ' time shorter. Decrease h from 1 to 0.5. This'
	 ' also makes the response time shorter.       '
 	 '                                             '
	 ' Choose to cancel zeros. The effect is not   '
	 ' seen in the output, but is causing a severe '
	 ' ringing in the control signal.              '];
   
     
    hwin(ttlStr,hlpStr);  


%%------------------- VALUES --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'values_rst'), 

	%-- checks if the window already exists
   	[existFlag,figNumber]=figflag('Values');
    	if ~existFlag,
		fig_val_rst = figure('Name','Values','NumberTitle'...
		,'Off','BackingStore','Off',...
		'Units','Normalized',...
		'Position',[0.05 0.05 0.3 0.3]);
	 	[existFlag,figNumber]=figflag('Values');
    	else
		clf;
        end;
	figure(fig_val_rst);
	axes('Visible','off');
	close_val = uicontrol(fig_val_rst,'Style','Push','String','Close',...
	'Units','normalized','Position',[0.8 0.03 0.17 0.07],...
	'Callback','close;');

	if get(system_rst,'Value')~=1,
	
		if ccs_col == 1,
			text(0,1,'RST-polynomials:','Color','g');
		else
			text(0,1,'RST-polynomials:');
		end;
		if get(choise1_rst,'Value')==1&get(choise2_rst,'Value')==1,
			r2_str = num2str(R(2));
			r3_str = num2str(R(3));
			s1_str = num2str(S(1));
			s2_str = num2str(S(2));
			s3_str = num2str(S(3));
			t1_str = num2str(T(1));
			t2_str = num2str(T(2));
			t3_str = num2str(T(3));
			text(0.01,0.90,'R=[1');
			text(0.17,0.90,r2_str);
			text(0.47,0.90,r3_str);
			text(0.77,0.90,']'); 
			text(0.01,0.80,'S=[');
			text(0.10,0.80,s1_str);
			text(0.40,0.80,s2_str);
			text(0.70,0.80,s3_str);
			text(1,0.80,']'); 
			text(0.01,0.70,'T=[');
			text(0.10,0.70,t1_str);
			text(0.40,0.70,t2_str);
			text(0.70,0.70,t3_str);
			text(1,0.70,']'); 
		elseif get(choise1_rst,'Value')==2&get(choise2_rst,'Value')==1,
			r2_str = num2str(R(2));
			r3_str = num2str(R(3));
			s1_str = num2str(S(1));
			s2_str = num2str(S(2));
			s3_str = num2str(S(3));
			t1_str = num2str(T(1));
			t2_str = num2str(T(2));
			text(0.01,0.90,'R=[1');
			text(0.17,0.90,r2_str);
			text(0.50,0.90,r3_str);
			text(0.80,0.90,']'); 
			text(0.01,0.80,'S=[');
			text(0.10,0.80,s1_str);
			text(0.40,0.80,s2_str);
			text(0.70,0.80,s3_str);
			text(1,0.80,']'); 
			text(0.01,0.70,'T=[');
			text(0.10,0.70,t1_str);
			text(0.40,0.70,t2_str);
			text(0.70,0.70,']'); 
		elseif get(choise1_rst,'Value')==1&get(choise2_rst,'Value')==2,
			r2_str = num2str(R(2));
			s1_str = num2str(S(1));
			s2_str = num2str(S(2));
			t1_str = num2str(T(1));
			t2_str = num2str(T(2));
			text(0.01,0.90,'R=[1');
			text(0.17,0.90,r2_str);
			text(0.47,0.90,']'); 
			text(0.01,0.80,'S=[');
			text(0.10,0.80,s1_str);
			text(0.40,0.80,s2_str);
			text(0.70,0.80,']'); 
			text(0.01,0.70,'T=[');
			text(0.10,0.70,t1_str);
			text(0.40,0.70,t2_str);
			text(0.70,0.70,']'); 
		elseif get(choise1_rst,'Value')==2&get(choise2_rst,'Value')==2,
			r2_str = num2str(R(2));
			s1_str = num2str(S(1));
			s2_str = num2str(S(2));
			t1_str = num2str(T(1));
			text(0.01,0.90,'R=[1');
			text(0.17,0.90,r2_str);
			text(0.47,0.90,']'); 
			text(0.01,0.80,'S=[');
			text(0.10,0.80,s1_str);
			text(0.40,0.80,s2_str);
			text(0.70,0.80,']'); 
			text(0.01,0.70,'T=');
			text(0.10,0.70,t1_str);
		end;

		bd1_str = num2str(Bd(1));
		bd2_str = num2str(Bd(2));
		ad2_str = num2str(Ad(2));
		ad3_str = num2str(Ad(3));

		if ccs_col == 1,
			text(0,0.60,'Discrete time system:','Color','g');
		else
			text(0,0.60,'Discrete time system:');
		end;
		text(0.01,0.50,'B(q)=[');
		text(0.17,0.50,bd1_str);
		text(0.47,0.50,bd2_str);
		text(0.77,0.50,']');
		text(0.01,0.40,'A(q)=[1');
		text(0.25,0.40,ad2_str);
		text(0.55,0.40,ad3_str);
		text(0.85,0.40,']');

		am2_str = num2str(Adm(2));
		am3_str = num2str(Adm(3));
		if ccs_col == 1,
			text(0,0.30,...
			'Discrete time Am-polynomial:','Color','g');
		else
			text(0,0.30,...
			'Discrete time Am-polynomial:');
		end;
		text(0.01,0.20,'Am(q)=[1');
		text(0.25,0.20,am2_str);
		text(0.55,0.20,am3_str);
		text(0.85,0.20,']');

		if ccs_col == 1,
			text(0,0.10,...
			'Discrete time observer-polynomial:','Color','g');
		else
			text(0,0.10,...
			'Discrete time observer-polynomial:');
		end;
		if length(Ao)==1,
			text(0.01,0,'Ao(q)= 1');
		elseif length(Ao)==2,
			ao2_str = num2str(Ao(2));
			text(0.01,0,'Ao(q)= [1');
			text(0.25,0,ao2_str);
			text(0.50,0,']');
		elseif length(Ao)==3,
			ao2_str = num2str(Ao(2));
			ao3_str = num2str(Ao(3));
			text(0.01,0,'Ao(q)= [1');
			text(0.25,0,ao2_str);
			text(0.55,0,ao3_str);
			text(0.85,0,']');
		end;

		else
			if ccs_col == 1,
				text(0.2,0.5,'No system defined.',...
				'Color','r','Fontsize',11);
			else
				text(0.2,0.5,'No system defined.',...
				'Fontsize',11);
			end;
		end;        


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_rst'),

	fig_rst = figure('Name',...
	'Pole Placement design','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.0425 0.4178 0.4861 0.4667 ],... 
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_rst,'Color',[0.8,0.8,0.8]);



elseif strcmp(operation,'init_rst'),
	watchon;

	%-- checks if the plot window already exists
	[existFlag,figNumber]=...
	figflag('Step response & Control signal, Pole Placement design');
	if ~existFlag,
      		fig2_rst = figure('Name',...
		'Step response & Control signal, Pole Placement design',...
		'NumberTitle','Off','BackingStore','Off',...
		 'Units', 'Normalized', ...
		'Position', [0.5286 0.4178 0.4340 0.4667 ]);
		set(fig2_rst,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=...
		figflag...
		('Step response & Control signal, Pole Placement design');
	else
		clf;fig=gcf;
	end;

	figure(fig_rst);

	%-- creates pole/zero diagram
	disc1_axes = subplot(222);
	set(disc1_axes,'FontName','Times','Fontsize',11);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	if ccs_col == 1,
		title('Am- and observer- poles','Color','k',...
		'FontName','Times');
		set(disc1_axes,'XLim',[-1.2 1.2],'YLim',[-1.2 1.2],...
		'Clipping','Off','XLimMode','Manual','YLimMode'...
		,'Manual','DrawMode', 'Fast','XColor','k','YColor','k',...
		'FontName','Times','Fontsize',11);
	else
		title('Am(x)- and observer(+)- poles','Color','k',...
		'FontName','Times');
		set(disc1_axes,'XLim',[-1.2 1.2],'YLim',[-1.2 1.2],...
		'Clipping','Off','XLimMode','Manual','YLimMode'...
		,'Manual','DrawMode', 'Fast','XColor','k','YColor','k',...
		'FontName','Times','Fontsize',11);
	end;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_rst,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_rst = uicontrol(fig_rst,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','rst(''close_rst'');');

	help_rst = uicontrol(fig_rst,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','rst(''help_rst'');');

	theory_rst = uicontrol(fig_rst,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','rst(''theory_rst'');');

	hint_rst = uicontrol(fig_rst,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','rst(''hints_rst'');');

	clear_rst = uicontrol(fig_rst,'Style','Push',...
	'String','Clear plots',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','rst(''polyclear'');');

	reset_rst = uicontrol(fig_rst,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized','Position', [0.0339 0.3667 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','rst(''polyreset'');');

	values_srst = uicontrol(fig_rst,'Style','Push','String','Values',...
	'Units','normalized','Position',[0.0339 0.2356 0.1429 0.0595],...
	'BackgroundColor',[0.9 1 0.9],...
	'Callback','rst(''values_rst'');');

	close_rst = uicontrol(fig_rst,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','rst(''close_rst_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_rst,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	system_rst = uicontrol(fig_rst,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.8667 0.2679 0.0595 ],  ...
	'string',...
	'Select system|Double integrator|Harmonic oscillator|Make own');
	set(system_rst,'Callback','rst(''system'');');

	input_Bc = uicontrol(fig_rst,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.8071 0.1429 0.0476 ],  ...
	'String','[ ]');
	input_Ac = uicontrol(fig_rst,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.7595 0.1429 0.0476 ],  ...
	'String','[ ]');
	set(input_Ac,'Callback','rst(''polycalc'');');

	Bc_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.8071 0.0893 0.0452 ],  ...
	'String','Bc=');
 	Ac_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.7595 0.0893 0.0476 ],  ...
	'String','Ac=');

	set(input_Bc,'Visible','off');
	set(input_Ac,'Visible','off');
	set(Bc_label,'Visible','off');
	set(Ac_label,'Visible','off');

	choise1_rst = uicontrol(fig_rst,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.5929 0.2679 0.0595 ],  ...
	'string',...
	'Do not cancel zeros|Cancel zeros');
	set(choise1_rst,'Callback','rst(''polycalc'');');

	choise2_rst = uicontrol(fig_rst,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.5214 0.2679 0.0595 ],  ...
	'string',...
	'With integrator|Without integrator');
	set(choise2_rst,'Callback','rst(''polycalc'');');

	frame_h = uicontrol(fig_rst,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2180 0.3950 0.2950 0.1100 ]);

	slid = uicontrol(fig_rst,'Style','slider',...
	'Units', 'Normalized','Position', [0.2571 0.4024 0.2143 0.0476 ], ...
	'Min',0.01,'Max',2,...
	'Value',1.0,'Callback','rst(''polycalc'');');

	h_cur = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.4179 0.4500 0.0870 0.0476 ],  ...
	'String',num2str(get(slid,'Val')));

	h_min = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4024 0.0357 0.0476 ],  ...
	'String',num2str(get(slid,'Min')));
	h_max = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.4714 0.4024 0.0340 0.0476 ],  ...
	'String',num2str(get(slid,'Max')));

	h_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4500 0.1964 0.0476 ],  ...
	'String','Sampl. per. h=');


%%---------------- RIGHT ------------------------------------

	frame_am = uicontrol(fig_rst,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5696 0.2833 0.4107 0.2381 ]);

	frame_ao = uicontrol(fig_rst,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5696 0.0214 0.4107 0.2381 ]);

	if ccs_col == 1,
		am_label = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5750 0.4619 0.4000 0.0476 ],...
		'String','Continuous time Am-polynomial',...
		'ForegroundColor','y');

		ao_label1 = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6700 0.2000 0.2000 0.0476 ],...
		'String','Continuous time',...
		'ForegroundColor','g');

		ao_label2 = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6450 0.1524 0.2500 0.0476 ],...
		'String','observer-polynomial',...
		'ForegroundColor','g');
	else
		am_label = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5750 0.4619 0.4000 0.0476 ],...
		'String','Continuous time Am-polynomial',...
		'ForegroundColor','k');

		ao_label1 = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6700 0.2000 0.2000 0.0476 ],...
		'String','Cotinuous time observer-polynomial',...
		'ForegroundColor','k');

		ao_label2 = uicontrol(fig_rst,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6450 0.1524 0.2500 0.0476 ],...
		'String','observer-polynomial',...
		'ForegroundColor','k');
	end;

	charam_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.5875 0.4143 0.3571 0.0476 ],  ...
	'String','Am(s)=s^2+2zws+w^2');

	input_zeta = uicontrol(fig_rst,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.3667 0.0714 0.0476 ]);
	set(input_zeta,'Callback','rst(''polycalc'');',...
	'Backgroundcolor','w');
	input_om = uicontrol(fig_rst,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.3190 0.0714 0.0476 ]);
	set(input_om,'Callback','rst(''polycalc'');','Backgroundcolor','w');
	
	zeta_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.3667 0.1250 0.0452 ],  ...
	'String','zeta =');
	om_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.3190 0.1250 0.0476 ],  ...
	'String','omega =');

	charao_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.5875 0.1048 0.3571 0.0476 ],  ...
	'String','Ao(s)=(s+alfa)^deg(Ao)');

	input_alfa = uicontrol(fig_rst,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.0572 0.0714 0.0476 ]);
	set(input_alfa,'Callback','rst(''polycalc'');','Backgroundcolor','w');

	alfa_label = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.0572 0.1250 0.0452 ],  ...
	'String','alfa =');

	set(input_zeta,'Visible','off');
	set(input_om,'Visible','off');
	set(input_alfa,'Visible','off');
	set(input_zeta,'String','0.7');	
	set(input_om,'String','0.5');
	set(input_alfa,'String','1');


%%-------------- ERROR MESSAGES -------------------------------------

	error1_rst = uicontrol(fig_rst,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.3548 0.3929 0.0595 ], ...
	'String',...
	'Not a correct 2:nd order system,',...
	'BackgroundColor','r');
	set(error1_rst,'Visible','off');


%%----------- 2:nd WINDOW -------------------------------------

	figure(fig2_rst);

	%-- creates axes for step response
	step_axes = subplot(211);
	hold on;
	grid on;
	set(step_axes, 'XLim',[0 100],'YLim'...
	, [-0.1 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Step response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- creates diagram for control signal
	control_axes = subplot(212);
	hold on;
	grid on;
	set(control_axes, 'XLim',[0 100],'YLim'...
	, [-0.4 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Control signal','Color','k',...
	'FontName','Times','Fontsize',11);

	figure(fig_rst);
	watchoff;


%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_rst'),

	[existFlag,figNumber]=figflag('Pole Placement design');
    	if existFlag,
		close(fig_rst);	
 	end;

	[existFlag,figNumber]=figflag('Step response & Control signal, Pole Placement design');
    	if existFlag,
		close(fig2_rst);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_rst_def'),

	[existFlag,figNumber]=figflag('Pole Placement design');
    	if existFlag,
		close(fig_rst);	
 	end;

	[existFlag,figNumber]=figflag('Step response & Control signal, Pole Placement design');
    	if existFlag,
		close(fig2_rst);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

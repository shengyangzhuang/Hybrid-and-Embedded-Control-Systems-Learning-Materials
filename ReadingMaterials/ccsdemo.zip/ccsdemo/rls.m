function [sys, x0, str, ts]=rls(t, x, u, flag,h,lambda,p)

if flag == 0

	a1 = -1;
	a2 = 2;	
	b0 = 1;
	b1 = 1;

	
	x0 = [b0,b1,a1,a2,p,0,0,0,p,0,0,p,0,p,0,0,0,0]';%-- STATE VECTOR INIT
	sys = [0,18,8,2,0,0,1];				%-- SYSTEM INFO
	ts = [h 0];


elseif flag == 2					%-- UPDATE STATES

	theta = [x(1);x(2);x(3);x(4)];	
	phi = [x(15);x(16);-x(17);-x(18)];% --- [y(k-1) y(k-2) -u(k-1) -u(k-2)]

	% --- covariance matrix
	pold = [x(5),x(6),x(7),x(8);x(6),x(9),x(10),x(11);x(7),x(10),x(12),x(13);x(8),x(11),x(13),x(14)];

	
		
		pf = pold*phi;
		denom = lambda+phi'*pf;
		k = pf/denom;
	
		e = u(1)-phi'*theta;

		ntheta = theta+k*e;
	
		P = (pold-k*pf')/lambda;
	

		sys = [ntheta(1),ntheta(2),ntheta(3),ntheta(4),P(1,1),P(1,2),P(1,3),P(1,4),P(2,2),P(2,3),P(2,4),P(3,3),P(3,4),P(4,4),u(2),x(15),u(1),x(17)];
	


elseif flag == 3					%-- CALCULATE OUTPUTS
	
	
		

		sys = [x(1),x(2),x(3),x(4),x(5),x(9),x(12),x(14)];
end;
		

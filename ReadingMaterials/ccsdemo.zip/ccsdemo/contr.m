function contr(operation);
% CONTR		Module illustrating controllability.

%		Author: Helena Haglund
%		LastEditDate : Dec 8 1995
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_contr
global u_move uold u_axes y_axes
global pt u

if nargin == 0,
	operation = 'show';
end;

if strcmp(operation,'show'),
    [existFlag,figNumber]=figflag('Controllability');
    if ~existFlag,
        contr('winit');
	contr('init');
        [existFlag,figNumber]=figflag('Controllability');
    else
	clf;
	contr('init');
    end;




elseif strcmp(operation,'moving_u'),

	bc = 1;
	ac = [1 0 0];
	[bd,ad] = c2dm(bc,ac,0.5,'zoh');




%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit'),

	fig_contr = figure('Name','Controllability','NumberTitle'...
	,'Off','BackingStore','Off');
	set(fig_contr,'Color',[0.8,0.8,0.8]);

	
elseif strcmp(operation,'init'),


%%---------------- FRAME LEFT ------------------------------------

	frame_left = uicontrol(fig_contr,'Style','Frame',...
	'Position',[10 10 100 400]);

	main_contr = uicontrol(fig_contr,...
	'Style','Push','String','Main Menu',...
	'Position',[20 365 80 25],...
	'Callback','close, close, close,close_system,close_system,ccs');

	help_contr = uicontrol(fig_contr,'Style','Push','String','Help!',...
	'Position',[20 330 80 25],...
	'Callback','contr(''contr_help'');');

	theory_contr = uicontrol(fig_contr,'Style','Push','String','Theory',...
	'Position',[20 295 80 25],...
	'Callback','contr(''contr_theory'');');

	clear_contr = uicontrol(fig_contr,'Style','Push',...
	'String','Clear plots',...
	'Position',[20 225 80 25],...
	'Callback','contr(''contr_clear'');');

	close_contr = uicontrol(fig_contr,'Style','Push','String','Quit',...
	'Position',[20 30 80 25],...
	'Callback',...
	'close,close,close,close_system,close_system');


%%------------ DIAGRAM -------------------------------------------

	y_axes = axes('position',[0.40 0.58 0.50 0.33]);
	title('Output y','Color','k');
	grid on;
	set(y_axes, 'XLim', [0 20], 'YLim', [0 2],...
	 'DrawMode','Fast','Clipping','Off',...
	 'XLimMode','Manual','YLimMode','Manual',...
	'XColor','k','YColor','k');
	hold on;
	plot(0,0.8,'kx',0,1.2,'kx',5,1,'kx',5,1.4,'kx'...
	,10,0.5,'kx',10,0.9,'kx',15,0.7,'kx',15,1.1,'kx');


	u_axes = axes('position',[0.03 0.58 0.001 0.33]);
	set(u_axes,'YLim',[0 2],'XColor','k','YColor','k');
	u_move = plot(0,0.68,'yx');
	set(u_move,'ButtonDownFcn','contr(''move_u'')');
	uold = 0.68;

%%--------------------------------------- KOLLA UPP DETTA!!!
	axes('Position',[.30 .58 .001 .33],'XCOLOR','k','YColor','k')
	title('Control signal u','Color','k');

%%	xbox = uicontrol('Style','text','Tag','xbox');
%%	xboxlabel = uicontrol('Style','text','String','X Value',...
%%               'Position',get(xbox,'position')+[0 21 0 0]);

	ybox = uicontrol('Style','text',...
	'Position',[150 100 60 20],'Tag','ybox');
		yboxlabel = uicontrol('Style','text','String','u',...
                'Position',get(ybox,'position')+[0 21 0 0]);

	callback = ['pt = get(gca,''CurrentPoint'');'...
        'xbox = findobj(''Tag'',''xbox'');' ...
        'ybox = findobj(''Tag'',''ybox'');' ...
        'set(xbox,''String'',num2str(pt(1,1)));' ...
        'set(ybox,''String'',num2str(pt(1,2)));'];
	set(gcf,'WindowButtonMotionFcn',callback);

	contr('moving_u');


elseif strcmp(operation, 'close'),
	close;
	close;
end;	

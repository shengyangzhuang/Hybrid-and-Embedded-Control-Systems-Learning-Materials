global fig_sfb fig2_sfb
global system_sfb
global error1_sfb error2_sfb error3_sfb
global input_a input_b input_c a_label b_label c_label
global input_zeta input_om input_zeta1 input_om1
global om om1 zeta zeta1
global slid h_cur
global a11 a12 a21 a22 b1 b2 c1 c2 h l1 l2 l3 lc k1 k2 Pl Pk
global phi11 phi12 phi21 phi22 gam1 gam2
global k1last k2last
global A B C
global save_syst load_syst
global choise1 choise2
global h0 om10 zeta10 om0 zeta0 a110 a120 a210 a220 b10 b20 c10 c20 
global phi110 phi120 phi210 phi220 gam10 gam20 
global Pl0 l10 l20 l30 lc0 stateold Pk0 k10 k20 observ observ0 ex sys_sfb




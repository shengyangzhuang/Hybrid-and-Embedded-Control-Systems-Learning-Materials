function pid(operation);
% PID 		Module illustrating PID control.
%
% 		The user can tune a PID-controller for four different
%		processes. Autotuning with Ziegler Nichols method and
%		Kappa Tau method can be done. The controller may include
%		anti reset windup.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Witenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_pid fig2_pid ccs_col fig_ccs fig_val_pid
global system
global delay input_delay input_num input_den num_label den_label 
global limit input_limit text_limit aw aw0 awlast
global error1 error2 instruct instruct2
global not_ZN not_KT ZN KT self
global sli_h sli_k sli_ti sli_td sli_tt
global h_cur k_cur ti_cur td_cur tt_cur
global h k ti td tt N b
global ex x tune sys
global num den input_num input_den sat del
global ku tu kp
global save_syst load_syst

if nargin == 0,
	operation = 'show';
end;

%-- checks if window already exists
if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('PID-control');
	if ~existFlag,
      		pid('winit_pid');
      		pid('init_pid');	
 		[existFlag,figNumber]=figflag('PID-control');
	else
		clf;
		pid('init_pid');
	end;


%%------------ SYSTEM SPECIFICATION ---------------------------------
%%------------------------------------------------------------------

elseif strcmp(operation,'system'),

	figure(fig2_pid);
	subplot(211);
	cla;
	subplot(212);
	cla;
	
	watchon;
	ex = 0;
	num = [];
	den = [];
	sat =Inf;
	del = 0;
	set(not_ZN,'Visible','off');
	set(not_KT,'Visible','off');
	set(error1,'Visible','off');
	set(error2,'Visible','off');
	set(instruct,'String','Select a tuning method.');
	set(instruct2,'Visible','off');	
	set(self,'Value',1);
	set(ZN,'Value',0);
	set(KT,'Value',0);
	set(input_num,'Visible','off');
	set(input_den,'Visible','off');
	set(num_label,'Visible','off');
	set(den_label,'Visible','off');
	set(delay,'Visible','off');
	set(input_delay,'Visible','off');
	set(limit,'Visible','off');
	set(text_limit,'Visible','off');
	set(input_limit,'Visible','off');	
	set(limit,'Value',1);
	set(input_limit,'String',' ');
	set(aw,'Visible','off');

	if get(system,'value')==1,
		set(instruct,'String','Select a system.');
	
	%-- set system to chosen
	elseif get(system,'value')==2,

		sys = 2;
		num = [1];
		den = [1 4 6 4 1];
		h = 1;
		N = 10;

	elseif get(system,'value')==3,

		sys = 3;
		num = [-2 1];
		den = [1 3 3 1];
		h = 1;
		N = 10;

	elseif get(system,'value')==4, 
		%-- system with time delay
		sys = 4;
		num = [1];
		den = [1 3 3 1];
		h = 1;
		N = 10;

	elseif get(system,'value')==5, 

		sys = 5;
		num = [0.5];
		den = [1 3 3 1 0];
		h = 1;
		N = 10;

	elseif get(system,'value')==6,
		%-- give own system
		set(instruct,'String','Give num and den in G(s),');
		set(instruct2,'Visible','on');	
		sys = 6;
		set(input_num,'Visible','on');
		set(input_den,'Visible','on');
		set(num_label,'Visible','on');
		set(den_label,'Visible','on');
		set(delay,'Value',1);
		set(input_delay,'String',' ');	
		set(delay,'Visible','on');
		h = 1;
		N = 10;

	end;
	watchoff;


%%------------ TUNING METHOD SPECIFICATION -------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'tuning'),

	figure(fig2_pid);
	subplot(211);
	cla;
	subplot(212);
	cla;

	figure(fig_pid);
	watchon;
	set(limit,'Visible','on');
	set(aw,'Visible','on');

	%-- if limit on the control signal set default anti windup
	if get(limit,'Value')==1,
		set(aw,'Value',2);
	else	
		set(aw,'Value',1);	
	end;

	if get(system,'Value')==6,
		num = str2num(get(input_num,'String'));
		den = str2num(get(input_den,'String'));
		set(input_num,'Visible','off');
		set(input_den,'Visible','off');
		set(num_label,'Visible','off');
		set(den_label,'Visible','off');
		set(input_delay,'Visible','off');
		set(delay,'Visible','off');
	end;

	if (get(system,'Value')==1)|((isempty(num))&(isempty(den))),
		%-- if system not specified or chosen calculations
		%-- can't be made
		set(error1,'Visible','on');
		set(self,'Value',1);	
		set(ZN,'Value',0);	
		set(KT,'Value',0);

	elseif length(num)>=length(den),
		%-- if deg(num)>deg(den), system not OK
		set(error2,'Visible','on');
		set(self,'Value',1);	
		set(ZN,'Value',0);	
		set(KT,'Value',0);
	
	else
		if get(system,'Value')==4,
			%-- set del in simulation to 1 if system 4 is chosen
			del = 5;
		elseif get(system,'Value')==6,
			%-- set del to choden value if any given, otherwise 0
			del = str2num(get(input_delay,'String'));
			if isempty(del),
				del = 0;
			end;
		else
			del = 0;
		end;

  	if (get(system,'Value')==6&get(delay,'Value')==2),

		%-- approximation of time delay if there is one
		if abs(del)<eps,		
			numd=1;		
             	  	dend=1;
              	 	return;
		end;
 		numd=[del^2 -6*del 12];
        	dend=[del^2 6*del 12];

		%-- calculate polynomials including the delay
		numd = conv(num,numd);
		dend = conv(den,dend);
		lnum = length(num);
		lden = length(den);

		%-- calculate phase and gain margin
		[gm,pm,wcg,wcp] = margin(numd,dend); 

	else
		lnum = length(num);
		lden = length(den);
		%-- calculate phase and gain margin

		if get(system,'Value')~=4,
			[gm,pm,wcg,wcp] = margin(num,den);
		end;

 	end;

	set(error1,'Visible','off');
	set(error2,'Visible','off');

	if (get(ZN,'Value')==1)&(x==0)|...
	(get(KT,'Value')==1)&(x==0)|(get(self,'Value')==0)&(x==0),
		%-- no tuning method chosen
		set(self,'Value',1);
		set(ZN,'Value',0);		
		set(KT,'Value',0);
		tune = 1;
	
		%-- set regulator parameters to default values
		k = 2.5;
		ti = 5;
		td = 2;
		tt = 0.5*ti;
		b = 1;

	elseif (get(KT,'Value')==1)&(x==1)|...
	(get(self,'Value')==1)&(x==1)|(get(ZN,'Value')==0)&(x==1),

		%-- Ziegler Nichols tuning method chosen
		set(self,'Value',0);
		set(ZN,'Value',1);		
		set(KT,'Value',0);
		set(not_KT,'Visible','off');
		tune = 2;

		if get(system,'Value')==4,
			%-- already calculated in kja&th book
			k=0.75;
			ti=7.9;
			td=2.0;
			tt=0.5*ti;
			b=1;

		else
			%-- ultimate gain and period
			ku = gm;
			tu = 2*3.14/wcg;

			%-- calculate regulator param. 
			%-- with ultimate gain and period
			k = 0.6*ku;
			ti = tu/2;
			td = tu/8;
			tt = 0.5*ti;
			b = 1;
		end;

	elseif (get(ZN,'Value')==1)&(x==2)|...
	(get(self,'Value')==1)&(x==2)|(get(KT,'Value')==0)&(x==2),
		%-- Kappa Tau tuning method chosen
		set(self,'Value',0);
		set(ZN,'Value',0);
		set(KT,'Value',1);		
		tune = 3;

		if get(system,'value')==4,
			%-- already calculated in kja&th book
			k=0.17;
			ti=2.6;
			td=0.48;
			b=1.9;
			tt=0.5*ti;			

		elseif get(system,'Value')==5,
			%-- already calculated in kja&th book
			k=0.32;
			ti=14;
			td=2.6;
			b=0.33;
			tt=0.5*ti;
		else

			%-- ultimate gain, ultimate period, 
			%-- static gain and kappa
			ku = gm;
			tu = 2*3.14/wcg;
			kp = num(lnum)/den(lden);	
			kappa = 1/(kp*ku);

			%-- calculate regulator param. with ultimate gain,
			%-- ultimate period and kappa
			k = ku*0.33*exp(-0.31*kappa+(-1.0)*kappa^2);
			ti = tu*0.76*exp(-1.6*kappa+(-0.36)*kappa^2);
			td = tu*0.17*exp(-0.46*kappa+(-2.1)*kappa^2);
			tt =0.5*ti;	
			b = 0.58*exp(-1.3*kappa+3.5*kappa^2);
		end;	
	end;

	%-- selection of sampling interval
	h = 0.6*td/N*3;
	if h<0.01,
		h = 0.01;
	end;
	set(sli_h,'Value',h);



%%-------------- PLOTTING ---------------------------------------	
		
	if get(system,'Value')==6 &((get(ZN,'Value')==1)&(tu==Inf|ku==Inf)),
		%-- can't use Ziegler Nichols if tu or ku is Inf
		set(not_ZN,'Visible','on');
		set(instruct,'String','Select a tuning method');

	elseif get(system,'Value')==6 &((get(KT,'Value')==1)&(kp==Inf|k==Inf|ti==Inf|td==Inf)),
		%-- can't use Kappa Tau if some parameter is Inf	
		set(not_KT,'Visible','on');
		set(instruct,'String','Select a tuning method');	

	else
		set(instruct,'String','Have fun!');
		set(instruct2,'Visible','off');	
		set(not_ZN,'Visible','off');	
		set(not_KT,'Visible','off');
		set(sli_k,'Value',k);	
		set(sli_ti,'Value',ti);
		set(sli_td,'Value',td);
		set(sli_tt,'Value',tt);
		set(h_cur,'String',num2str(get(sli_h,'Value')));
		set(k_cur,'String',num2str(get(sli_k,'Value')));
		set(ti_cur,'String',num2str(get(sli_ti,'Value')));
		set(td_cur,'String',num2str(get(sli_td,'Value')));
		set(tt_cur,'String',num2str(get(sli_tt,'Value')));
		if get(aw,'value')==1,	
			%-- simulation with anti reset windup
			option=simset('MaxStep',get(sli_h,'Value'));		
			[t,x,y] = sim('pidaw_s',[0 80],option);
			aw0 = 1;
			awlast = 1;
		elseif get(aw,'value')==2,
			%-- simulation without anti reset windup
			option=simset('MaxStep',get(sli_h,'Value'));					[t,x,y] = sim('pid_s',[0 80],option);
			aw0 = 2;
			awlast = 2;
		end;
		figure(fig2_pid);

		%-- plot step response
		subplot(211);
		cla;
		if ccs_col == 1,
			plot(t,stepresp,'r');
		else
			plot(t,stepresp,'k');
		end;	

		%-- plot control signal	
		subplot(212);
		cla;
		[ts,pid_contrs]=stairs(t,pid_contr);
		if ccs_col == 1,
			plot(ts,pid_contrs,'r');
		else
			plot(ts,pid_contrs,'k');
		end;

	end;
	figure(fig_pid);
	end;
	watchoff;


%%-----------CALCULATIONS------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_calc'),


	figure(fig_pid);
	watchon;
	if (get(system,'Value')==1)|((isempty(num))&(isempty(den))),
		%-- if system not specified or chosen calculations
		%-- can't be made	
		set(error1,'Visible','on');
		set(self,'Value',1);	
		set(ZN,'Value',0);	
		set(KT,'Value',0);
	else					
	
	%-- set sliders to current values				
	set(h_cur,'String',num2str(get(sli_h,'Value')));
	set(k_cur,'String',num2str(get(sli_k,'Value')));
	set(ti_cur,'String',num2str(get(sli_ti,'Value')));
	set(td_cur,'String',num2str(get(sli_td,'Value')));
	set(tt_cur,'String',num2str(get(sli_tt,'Value')));

	h = get(sli_h,'Val');		
	k = get(sli_k,'Val');
	ti = get(sli_ti,'Val');
	td = get(sli_td,'Val');
	tt = get(sli_tt,'Val');

	%-- limitations on control signal
	sat = str2num(get(input_limit,'String'));
	if isempty(sat),
		sat = Inf;
	end;

	if get(aw,'value')==1,
		option=simset('MaxStep',get(sli_h,'Value'));
		[t,x,y] = sim('pidaw_s',[0 80],option);
		awlast = 1;
	elseif get(aw,'value')==2,
		option=simset('MaxStep',get(sli_h,'Value'));
		[t,x,y] = sim('pid_s',[0 80],option);
		awlast = 2;
	end;

	figure(fig2_pid);

	%-- plot step response
	subplot(211);
	if ccs_col == 1,
		plot(t,stepresp,'r');
	else
		plot(t,stepresp,'k');
	end;

	%-- plot control signal			
	subplot(212);
	[ts,pid_contrs]=stairs(t,pid_contr);
	if ccs_col == 1,	
		plot(ts,pid_contrs,'r');
	else
		plot(ts,pid_contrs,'k');
	end;

	figure(fig_pid);

	end;
	watchoff;


%%----------------- CLEAR ------------------------------------
%%------------------------------------------------------------

elseif strcmp(operation,'pid_clear'),

	figure(fig2_pid);
	subplot(211);
	cla;
	subplot(212);
	cla;

if get(system,'Value') ==2|get(system,'Value') ==3|...
get(system,'Value') ==4|get(system,'Value') ==5|get(system,'Value') ==6,


	figure(fig_pid);
	watchon;

	%-- error if system bot given
	if (get(system,'Value')==1)|...
	((isempty(num))&(isempty(den))),
		set(error1,'Visible','on');
		set(self,'Value',1);			
		set(ZN,'Value',0);			
		set(KT,'Value',0);
	else

		%-- set variables to current values	
		h = get(sli_h,'Val');
		k = get(sli_k,'Val');
		ti = get(sli_ti,'Val');
		td = get(sli_td,'Val');
		tt = get(sli_tt,'Val');
		set(aw,'Value',awlast);
	
		if get(aw,'value')==1,
			%-- simulation with anti reset windup		
			option=simset('MaxStep',get(sli_h,'Value'));
			[t,x,y] = sim('pidaw_s',[0 80],option);
		elseif get(aw,'value')==2,
			%-- simulation without anti reset windup
			option=simset('MaxStep',get(sli_h,'Value'));
			[t,x,y] = sim('pid_s',[0 80],option);
		end;

		figure(fig2_pid);

		%-- plot step response
		subplot(211);
		if ccs_col == 1,
			plot(t,stepresp,'r');
		else
			plot(t,stepresp,'k');
		end;

		%-- plot control signal		
		subplot(212);
		[ts,pid_contrs]=stairs(t,pid_contr);
		if ccs_col == 1,
			plot(ts,pid_contrs,'r');
		else
			plot(ts,pid_contrs,'k');
		end;

		figure(fig_pid);
	end;
watchoff;
end;


%%-----------LIMIT------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_limit'),

	figure(fig_pid);
	if get(limit,'Value') == 2,
		%-- limitations
		set(input_limit,'Visible','on');
		set(text_limit,'Visible','on');
	else
		%-- no limitations
		set(input_limit,'String','');
		set(input_limit,'Visible','off');
		pid('pid_calc');
		set(text_limit,'Visible','off');
	end;


%%-----------DELAY------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_delay'),

	if get(delay,'Value') == 2,
		%-- delay
		set(input_delay,'Visible','on');
	elseif get(delay,'Value') == 1,
		%-- no delay
		set(input_delay,'Visible','off');
	end;


%%-----------SAVE------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_save'),

	if get(save_syst,'value')==2,
		save syst1 num den h k ti td tt N tune sys awlast sat del b
	elseif get(save_syst,'value')==3,
	save syst2 num den h k ti td tt N tune sys awlast sat del b
	elseif get(save_syst,'value')==4,
		save syst3 num den h k ti td tt N tune sys awlast sat del b
	elseif get(save_syst,'value')==5,
		save syst4 num den h k ti td tt N tune sys awlast sat del b
	elseif get(save_syst,'value')==6,
		save syst5 num den h k ti td tt N tune sys awlast sat del b
	end;

	set(save_syst,'Value',1);


%%-----------LOAD------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_load'),

	figure(fig_pid);
	watchon;

	%-- load saved system in file if file exists
	if get(load_syst,'value')==2,
		if exist('syst1.mat')==2,
			load syst1
			ex = 1;
		else
			ex = 0;
		end;  
	elseif get(load_syst,'value')==3,
		if exist('syst2.mat')==2,
			load syst2
			ex =1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==4,
		if exist('syst3.mat')==2,
			load syst3
			ex = 1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==5,
		if exist('syst4.mat')==2,
			load syst4
			ex = 1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==6,
		if exist('syst5.mat')==2,
			load syst5
			ex = 1;
		else
			ex = 0;
		end; 
	end;

	if ex == 1,

	figure(fig_pid);

	%-- set sliders to stored values
	set(sli_h,'Value',h);
	set(sli_k,'Value',k);
	set(sli_ti,'Value',ti);
	set(sli_td,'Value',td);
	set(sli_tt,'Value',tt);

	set(h_cur,'String',num2str(h));
	set(k_cur,'String',num2str(k));
	set(ti_cur,'string',num2str(ti));
	set(td_cur,'String',num2str(td));
	set(tt_cur,'String',num2str(tt));

	set(system,'Value',sys);
	set(aw,'Value',awlast);
	set(aw,'Visible','on');
	set(limit,'Visible','on');

	if tune == 1,
		set(self,'Value',1);
		set(ZN,'Value',0);	
		set(KT,'Value',0);
	elseif tune == 2,
		set(self,'Value',0);
		set(ZN,'Value',1);	
		set(KT,'Value',0);
	elseif tune == 3,
		set(self,'Value',0);
		set(ZN,'Value',0);	
		set(KT,'Value',1);
	end;

	if sat == Inf,
		%-- no limitations
		set(input_limit,'Visible','off');
		set(limit,'Value',1);
	else
		%-- limitations
		set(input_limit,'Visible','on');
		set(limit,'Value',2);
		set(input_limit,'String',num2str(sat));	
	end;

	if get(aw,'value')==1,
		%-- simulation with anti reset windup
		option=simset('MaxStep',get(sli_h,'Value'));
		[t,x,y] = sim('pidaw_s',[0 80],option);
	elseif get(aw,'value')==2,
		%-- simulation without anti reset windup
		option=simset('MaxStep',get(sli_h,'Value'));
		[t,x,y] = sim('pid_s',[0 80],option);
	end;

	figure(fig2_pid);

	%-- plot step response
	subplot(211);
	if ccs_col == 1,
		plot(t,stepresp,'r');
	else
		plot(t,stepresp,'k');
	end;

	%-- plot control signal			
	subplot(212);
	[ts,pid_contrs]=stairs(t,pid_contr);
	if ccs_col == 1,	
		plot(ts,pid_contrs,'r');
	else
		plot(ts,pid_contrs,'k');
	end;

	figure(fig_pid);
	end;

	set(load_syst,'Value',1);
	watchoff;        


%%-----------HELP---------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_help'),

   ttlStr='PID help...';
    hlpStr1= ... 
	['                                             '
         ' This demo shows systems controlled by a     '   
         ' PID-controller.                             '
	 '                                             '
	 ' There is a choise between using Ziegler     '
	 ' Nichols tuning method, Kappa Tau tuning     '
	 ' method or doing the tuning yourself.        '
	 '                                             '
	 ' You can change the sampling period and tune '   
         ' the PID-parameters to see how the step res- '  
         ' ponse and the control signal is effected.   '
	 '                                             '
	 ' The reference signal is a unit step and     '
	 ' there is a load disturbance at t =50s. The  '
	 ' load disturbance acts on the input signal to'
	 ' the process.                                ' 
	 '                                             '
	 ' A limitation on the control signal can be   '
	 ' applied and the controller can act with or  '];

    hlpStr2= ...
	['                                             '
	 ' without antiwindup.                         '
	 '                                             '
	 ' You have the possibility to create a        '
	 ' process of your own by choosing "make own", '
	 ' and specify num, den and also choose whether'
	 ' there should be a time delay or not.        '
	 '                                             '
	 ' With the Save System button you can save the' 
	 ' current system in one of the 5 systx-files. '
	 ' With load you can reload it again.          '
	 ' After having reloaded a system all settings '
	 ' are adjusted according to this system.      '];  


    hwin(ttlStr,hlpStr1,hlpStr2); 


%%-----------THEORY------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_theory'),

    ttlStr='PID theory...';
    hlpStr= ...                                           
        ['                                             '  
     	 ' See Section 8.5 in CCS p. 306-320 for       '       
	 ' reading more about discrete-time PID-       '
	 ' controllers.                                '
	 '                                             '
	 ' You can read more about Kappa Tau tuning in '
	 ' Chapter 5, Karl Johan Astrom and Tore Hagg- '
	 ' lund, New Tuning Methods for PID Controllers' 
	 ' Second edition, Instrument Society of       '
	 ' America.                                    '];
     
    hwin(ttlStr,hlpStr);   


%%-----------HINTS------------------------------------
%%------------------------------------------------------

elseif strcmp(operation,'pid_hints'),

    ttlStr='PID hints...';
    hlpStr= ...                                           
        ['                                             '  
     	 ' Choose system 4, 0.5/s(s+1)^3 and Ziegler   '       
	 ' Nichols Tuning method. Set limitation to    '
	 ' 0.15 and see how the step response is       '
	 ' effected. Then, add antiwindup to the cont- '
	 ' roller and see what happens. The result is  '
	 ' that the overshoot is reduced.              '
	 '                                             '];  
     
    hwin(ttlStr,hlpStr);  


%%------------------- VALUES --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'values_pid'), 

	%-- checks if the window already exists
   	[existFlag,figNumber]=figflag('Values');
    	if ~existFlag,
		fig_val_pid = figure('Name','Values','NumberTitle'...
		,'Off','BackingStore','Off',...
		'Units','Normalized',...
		'Position',[0.05 0.05 0.3 0.3]);
	 	[existFlag,figNumber]=figflag('Values');

    	else
		clf;
        end;

	figure(fig_val_pid);
	close_val = uicontrol(fig_val_pid,'Style','Push','String','Close',...
	'Units','normalized','Position',[0.8 0.03 0.17 0.07],...
	'Callback','close;');

	axes('Visible','off');

	if get(system,'Value')~=1,

	   if get(system,'Value')==4|...
	   (get(system,'Value')==6&get(delay,'Value')==2),
		%-- approximation of time delay if there is one
 		numd=[del^2 -6*del 12];
        	dend=[del^2 6*del 12];

		%-- calculate polynomials including the delay
		numd = conv(num,numd);
		dend = conv(den,dend);
		[b_samp,a_samp] = c2dm(numd,dend,h,'zoh');
	   else
		[b_samp,a_samp] = c2dm(num,den,h,'zoh');
	   end;
		if b_samp(1,1)==0,	
			bt_samp = zeros(1,length(b_samp)-1);
			for count=1:length(b_samp)-1,
				bt_samp(1,count)= b_samp(1,count+1);
			end;
			b_samp=bt_samp;
		end;
		num_cl1 = conv(k*b*[1 -1]+h/ti,b_samp);
		num_cl2 = conv([1 -1],[1 -td/(N*h)+td]);
		num_cl = conv(num_cl1,num_cl2);

		den_cl1 = conv(a_samp,[1 -1]);
		den_cl2 = conv(den_cl1,[1 -td/(N*h+td)]);
		den_cl3 = k*conv(b_samp,[1 -1]);
		den_cl4 = conv(den_cl3,[1 -td/(N*h+td)]);
		den_cl5 = k*h/ti*conv(b_samp,[1 -td/(N*h+td)]);
		den_cl6 = conv([1 -1],b_samp);;
		den_cl65 = conv(den_cl6,[1 -1]);
		den_cl7 = k*td/(h+td/N)*den_cl65;
		s_cl2 = length(den_cl2);
		s_cl4 = length(den_cl4);
		s_cl5 = length(den_cl5);
		s_cl7 = length(den_cl7);
	
		den_cl8 = den_cl2+[zeros(1,s_cl2-s_cl4) den_cl4]+...
		[zeros(1,s_cl2-s_cl5) den_cl5]+[zeros(1,s_cl2-s_cl7) den_cl7];
		den_cl = conv([1 -1],den_cl8);
		zeros_pid = roots(num_cl);
		poles_pid = roots(den_cl);
		if ccs_col == 1,
			text_notice=text(0,-0.06,...
			'Notice! Pole(s) outside unit circle!',...
			'Color',[1 0.5 0.5]);
		else
			text_notice=text(0,-0.06,...
			'Notice! Pole(s) outside unit circle!');
		end;
		set(text_notice,'Visible','off');
		for t=1:length(poles_pid),
			if abs(poles_pid(t))>1.2,
				set(text_notice,'Visible','on');
			end;
		end;
		disc_axes = axes('Position',[0.15 0.17 0.7 0.7]);;
		grid on;
		hold on;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'w-');		
		axis('equal');
		title('Discrete time closed-loop poles and zeros',...
		'Fontsize',12);
		set(disc_axes,'XLim',[-1.5 1.5],'YLim',[-1.2 1.2],...
		'Clipping','Off','XLimMode','Manual','YLimMode'...
		,'Manual','DrawMode', 'Fast');
		if ccs_col == 1
			z=plot(real(roots(num_cl)),imag(roots(num_cl)),'ro');
			p=plot(real(roots(den_cl)),imag(roots(den_cl)),'rx');
		else
			z=plot(real(roots(num_cl)),imag(roots(num_cl)),'o');
			p=plot(real(roots(den_cl)),imag(roots(den_cl)),'x');
		end;
		set(z,'Linewidth',2,'MarkerSize',7); 
		set(p,'Linewidth',2,'MarkerSize',9);
	else
		if ccs_col == 1,
			text(0.2,0.5,'No system defined.',...
			'Color','r');
		else
			text(0.2,0.5,'No system defined.');
		end;
	end;        


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_pid'),

	fig_pid = figure('Name',...
	'PID-control','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.0425 0.4178 0.4861 0.4667 ],...
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_pid,'Color',[0.8,0.8,0.8]);


elseif strcmp(operation,'init_pid'),
	watchon;

	%-- checks if plot window already exists
	[existFlag,figNumber]=...
	figflag('Step response & Control signal, PID-control');
	if ~existFlag,
		%-- create plot window
      		fig2_pid= figure('Name',...
		'Step response & Control signal, PID-control',...
		'NumberTitle','Off','BackingStore','Off',...
		'Units', 'Normalized', ...
		'Position', [0.5286 0.4178 0.4340 0.4667 ]);
		set(fig2_pid,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=...
		figflag...
		('Step response & Control signal, PID-control');
	else
		clf;fig=gcf;
	end;

	figure(fig_pid);

	watchon;


%%---------------- FRAME LEFT ------------------------------------

	frame_left = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_pid = uicontrol(fig_pid,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','pid(''close_pid'');');

	help_pid = uicontrol(fig_pid,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','pid(''pid_help'');');

	theory_pid = uicontrol(fig_pid,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','pid(''pid_theory'');');

	hint_pid = uicontrol(fig_pid,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','pid(''pid_hints'');');

	clear_pid = uicontrol(fig_pid,'Style','Push',...
	'String','Clear plots',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','pid(''pid_clear'');');

	values_pid = uicontrol(fig_pid,'Style','Push','String','Values',...
	'Units','normalized','Position',[0.0339 0.2356 0.1429 0.0595],...
	'BackgroundColor',[0.9 1 0.9],...
	'Callback','pid(''values_pid'');');

	close_pid = uicontrol(fig_pid,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','pid(''close_pid_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	system = uicontrol(fig_pid,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.8667 0.2679 0.0595 ],  ...
	'string',...
	'Select system|1/(s+1)^4|(1-2s)/(1+s)^3|e^-5s/(s+1)^3|0.5/s(s+1)^3|Make own');
	set(system,'Callback','pid(''system'');');

	delay = uicontrol(fig_pid,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.6405 0.2679 0.0595 ],  ...
	'string',...
	'no timedelay|timedelay, s');
	set(delay,'Value',1);
	set(delay,'Visible','off');
	set(delay,'Callback','pid(''pid_delay'');');

	input_delay = uicontrol(fig_pid,'Style','edit',...
	'Units', 'Normalized','Position', [0.4268 0.5810 0.0714 0.0595 ],  ...
	'String','');
	set(input_delay,'Visible','off');
	set(input_delay,'String',' ');

	input_num = uicontrol(fig_pid,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.7643 0.1429 0.0476 ],  ...
	'String','[ ]');
	input_den = uicontrol(fig_pid,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.7167 0.1429 0.0476 ],  ...
	'String','[ ]');
	
	num_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.7643 0.0893 0.0452 ],  ...
	'String','num=');
	den_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.7167 0.0893 0.0476 ],  ...
	'String','den=');
	set(input_num,'Visible','off');
	set(input_den,'Visible','off');
	set(num_label,'Visible','off');
	set(den_label,'Visible','off');

	tuning = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.2304 0.4500 0.2679 0.0595 ],  ...
	'String','Tuning method');

	self = uicontrol(fig_pid,'Style','radio',...
	'Units', 'Normalized','Position', [0.2304 0.4024 0.2679 0.0476 ],  ...
	'String','I do it','Value',1,'CallBack',...
	'x=0;,pid(''tuning'');');

	ZN = uicontrol(fig_pid,'Style','radio',...
	'Units', 'Normalized','Position', [0.2304 0.3548 0.2679 0.0476 ],  ...
	'String','Ziegler Nichols','Value',0,'CallBack',...
	'x=1;,pid(''tuning'');');

	KT = uicontrol(fig_pid,'Style','radio',...
	'Units', 'Normalized','Position', [0.2304 0.3071 0.2679 0.0476 ], ...
	'String','KT Tuning','Value',0,'CallBack',...
	'x=2;,pid(''tuning'');');

	save_syst = uicontrol(fig_pid,'style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.1643 0.2679 0.0595 ],  ...
	'string',...
	'Save System|syst1|syst2|syst3|syst4|syst5');
	set(save_syst,'Callback','pid(''pid_save'');');

	load_syst = uicontrol(fig_pid,'style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.0690 0.2679 0.0595 ], ...
	'string',...
	'Load System|syst1|syst2|syst3|syst4|syst5');
	set(load_syst,'Callback','pid(''pid_load'');');


%%--------------- FRAME RIGHT -------------------------------------------

	instruct = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5786 0.9143 0.3571 0.0595 ],  ...
	'String',...
	'Select a system.',...
	'BackgroundColor',[1 1 0.4]);

	instruct2 = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5786 0.8667 0.3571 0.0476 ],  ...
	'String',...
	'then select a tuning method.',...
	'BackgroundColor',[1 1 0.4]);
	set(instruct2,'Visible','off');

	frame_right = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5429 0.0214 0.4464 0.8333 ]);

	frame_h = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5857 0.7119 0.3554 0.1100 ]);

	sli_h = uicontrol(fig_pid,'Style','slider',...
	'Units', 'Normalized','Position', [0.6589 0.7160 0.2143 0.0476 ],  ...
	'Min',0.01,'Max',2,...
	'Value',1,'CallBack','pid(''pid_calc'');');

	h_cur = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8375 0.7640 0.0982 0.0450 ],  ...
	'String',num2str(get(sli_h,'Val')));

	h_min = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.7160 0.0680 0.0476 ], ...
	'String',num2str(get(sli_h,'Min')));
	h_max = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8732 0.7160 0.0625 0.0476 ],  ...
	'String',num2str(get(sli_h,'Max')));

	h_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.7640 0.2500 0.0450 ],  ...
	'String','Sampling period h=');

	frame_k = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5857 0.5929 0.3554 0.1100 ]);

	sli_k = uicontrol(fig_pid,'Style','slider',...
	'Units', 'Normalized','Position', [0.6589 0.5972 0.2143 0.0476 ],  ...
	'Min',0,'Max',5,...
	'CallBack','pid(''pid_calc'');');

	k_cur = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8375 0.6449 0.0982 0.0440 ],  ...
	'String',num2str(get(sli_k,'Val')));

	k_min = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.5972 0.0680 0.0476 ],  ...
	'String',num2str(get(sli_k,'Min')));
	k_max = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8732 0.5972 0.0625 0.0476 ],  ...
	'String',num2str(get(sli_k,'Max')));

	k_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.6449 0.2500 0.0440 ], ...
	'String','Parameter K=');

	frame_ti = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5857 0.4738 0.3554 0.1100 ]);

	sli_ti = uicontrol(fig_pid,'Style','slider',...
	'Units', 'Normalized','Position', [0.6589 0.4782 0.2143 0.0476 ],  ...
	'Min',0.001,'Max',15,'Value',15,...
	'CallBack','pid(''pid_calc'');');

	ti_cur = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8375 0.5258 0.0982 0.0456 ],  ...
	'String',num2str(get(sli_ti,'Val')));

	ti_min = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.4782 0.0680 0.0476 ],  ...
	'String',num2str(get(sli_ti,'Min')));
	ti_max = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8732 0.4782 0.0625 0.0476 ],  ...
	'String',num2str(get(sli_ti,'Max')));

	ti_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.5258 0.2500 0.0456 ],  ...
	'String','Parameter Ti=');

	frame_td = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5857 0.3548 0.3554 0.1100 ]);

	sli_td = uicontrol(fig_pid,'Style','slider',...
	'Units', 'Normalized','Position', [0.6589 0.3600 0.2143 0.0476 ],  ...
	'Min',0,'Max',4,...
	'CallBack','pid(''pid_calc'');');

	td_cur = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8375 0.4068 0.0982 0.0456 ],  ...
	'String',num2str(get(sli_td,'Val')));

	td_min = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.3600 0.0680 0.0476 ],  ...
	'String',num2str(get(sli_td,'Min')));
	td_max = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8732 0.3600 0.0625 0.0476 ],  ...
	'String',num2str(get(sli_td,'Max')));

	td_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.4068 0.2500 0.0456 ],  ...
	'String','Parameter Td=');

	frame_tt = uicontrol(fig_pid,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5857 0.2357 0.3554 0.1100 ]);

	sli_tt = uicontrol(fig_pid,'Style','slider',...
	'Units', 'Normalized','Position', [0.6589 0.2401 0.2143 0.0476 ],  ...
	'Min',0.001,'Max',6,'Value',0.001,...
	'CallBack','pid(''pid_calc'');');

	tt_cur = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8375 0.2877 0.0982 0.0456 ],  ...
	'String',num2str(get(sli_tt,'Val')));

	tt_min = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.2401 0.0680 0.0476 ],  ...
	'String',num2str(get(sli_tt,'Min')));
	tt_max = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.8732 0.2401 0.0625 0.0476 ],  ...
	'String',num2str(get(sli_tt,'Max')));
	
	tt_label = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.5890 0.2877 0.2500 0.0456 ],  ...
	'String','Parameter Tt=');

	aw = uicontrol(fig_pid,'Style','popup',...
	'Units', 'Normalized','Position', [0.6232 0.1405 0.2768 0.0595 ],  ...
	'string',...
	'with antiwindup|without antiwindup');
	set(aw,'Visible','off');
	set(aw,'Callback','pid(''pid_calc'');');

	limit = uicontrol(fig_pid,'Style','popup',...
	'Units', 'Normalized','Position', [0.6232 0.0690 0.2768 0.0595 ],  ...
	'string',...
	'no limitation|limitation');
	set(limit,'Value',1);
	set(limit,'Visible','off');
	set(limit,'Callback','pid(''pid_limit'');');

	input_limit = uicontrol(fig_pid,'Style','edit',...
	'Units', 'Normalized','Position', [0.9000 0.0690 0.0714 0.0595 ],  ...
	'String','');
	set(input_limit,'Visible','off');
	set(input_limit,'String',' ');
	set(input_limit,'Callback','pid(''pid_calc'');','Backgroundcolor','w');

	if ccs_col == 1,
		text_limit = uicontrol(fig_pid,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6232 0.024 0.3571 0.0429 ],...
		'ForegroundColor','y',...
		'String','This number gives +/- limit.');
		set(text_limit,'Visible','off');
	else
		text_limit = uicontrol(fig_pid,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.6232 0.0262 0.3571 0.0429 ],...
		'ForegroundColor','k',...
		'String','This number gives +/- limit.');
		set(text_limit,'Visible','off');
	end;
	

%%----------- ERROR MESSAGES -----------------------------

	error1 = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.3554 0.4738 0.3571 0.1190 ],  ...
	'String',...
	'NO, select system first!',...
	'BackgroundColor','r');
	set(error1,'Visible','off');

	error2 = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.3554 0.4738 0.4464 0.1190 ],  ...
	'String',...
	'NO, chose deg(num) < deg(den)!',...
	'BackgroundColor','r');
	set(error2,'Visible','off');

	not_ZN = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized','Position', [0.0518 0.0690 0.3750 0.1190 ], ...
	'String',...
	'Ziegler Nichols can not be used!',...
	'BackgroundColor','r');
	set(not_ZN,'Visible','off');
	
	not_KT = uicontrol(fig_pid,'Style','text',...
	'Units', 'Normalized', 'Position', [0.0518 0.0690 0.3750 0.1190 ], ...
	'String',...
	'KT-tuning can not be used!',...
	'BackgroundColor','r');
	set(not_KT,'Visible','off');


%%----------------- AXES, 2:nd WINDOW ------------------------------------

	figure(fig2_pid);

	%-- create step response diagram
	step_axes = subplot(211);
	hold on;
	grid on;
	set(step_axes, 'XLim',[0 80],'YLim'...
	, [-1 2], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Step response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create control signal diagram
	control_axes = subplot(212);
	hold on;
	grid on;
	set(control_axes, 'XLim',[0 80],'YLim'...
	, [-1 2], 'DrawMode', 'Fast', ...
	'Clipping', 'Off', 'XLimMode', 'Manual', 'YLimMode', 'Manual',...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Control signal','Color','k',...
	'FontName','Times','Fontsize',11);

	figure(fig_pid);
	watchoff;


%%-------------------- CLOSE ALL WINDOWS---------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_pid'),

	[existFlag,figNumber]=figflag('PID-control');
    	if existFlag,
		close(fig_pid);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, PID-control');
    	if existFlag,
		close(fig2_pid);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_pid_def'),

	[existFlag,figNumber]=figflag('PID-control');
    	if existFlag,
		close(fig_pid);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, PID-control');
    	if existFlag,
		close(fig2_pid);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;
end;

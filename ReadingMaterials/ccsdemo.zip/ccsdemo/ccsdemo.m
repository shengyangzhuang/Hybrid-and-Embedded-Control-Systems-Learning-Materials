function ccsdemo(operation);
% CCSDEMO	Sampled Data Systems Demo consists of 13
%		modules. Each module illustrates a specific
%		area in sampled data systems.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997, B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_ccs ccs_col ccs_color

if nargin == 0,
	operation = 'show';
end;


if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
	if ~existFlag,
		ccsdemo('winit_ccs');
		ccsdemo('init_ccs');
		[existFlag,figNumber]=figflag('Sampled Data Systems Demo');
	else
		clf;
		ccsdemo('init_ccs');
	end;


elseif strcmp(operation,'ccs_i2'),
   ttlStr='Info...';
    hlpStr1= ...  
	['                                             '
	 ' How is this demo organized?                 '
         ' The organization of Sampled Data Systems    '
	 ' Demo is modular. It consists of thirteen    '
	 ' modules, each one demonstrating a specific  '
	 ' feature of sampled data systems.            '
	 ' The modules can only be started from this   '
	 ' menu. After having finished one module, just'
	 ' go back to the main menu and make another   '
	 ' choice.                                     '
	 '                                             '
	 ' How do I do?                                '
	 ' Choose a demo by clicking on the correspond-'
	 ' ing button. When having entered the demo You'
	 ' can interact with it by changing parameters '
	 ' and/or moving poles and zeros.              '];

    hlpStr2= ...
	['                                             '
	 ' The Sampled Data Systems Demo is created    '
	 ' in a Master Thesis Project by Helena Haglund'
	 ' under supervision of Bjorn Wittenmark at the'
	 ' Department of Automatic Control, Lund       '
	 ' Institute of Technology, Lund, Sweden.      '
	 '                                             '
	 '                                             '
	 '                                             '
	 '                                             '
	 '                                             '
	 '                                             '
	 ' NOTICE!                                     '
	 ' This demo is developed on a Sun work station'
	 ' with color screen. It is possible that the  '
	 ' graphics, when running it on some other type'
	 ' of computer, will not look as splendid as it'
	 ' does on a work station with color screen.   '
	 ' The functionality is though the same.       '];

    hwin(ttlStr,hlpStr1,hlpStr2); 

elseif strcmp(operation,'ccs_i1'),
   ttlStr='Info...';
    hlpStr= ...                                           
	['                                             '
	 ' The references (CCS) are for the book:      '
	 ' Karl Johan Astrom and Bjorn Wittenmark      '
	 ' (1997), Computer Controlled Systems, Third  '
	 ' Edition, Prentice Hall.                     '];  
  
    hwin(ttlStr,hlpStr); 

elseif strcmp(operation,'winit_ccs'),

      	fig_ccs = figure('Name', 'Welcome to Sampled Data Systems Demo!', ...
	'Units', 'Normalized', ...
	'Position', [0.2561 0.4400 0.4861 0.4667 ],... 
	'NumberTitle', 'Off', 'BackingStore', 'Off');
	set(gcf,'Color',[0.8,0.8,0.8]);
%elseif strcmp(operation,'make'),

%	[x,map] = gifread('astwit90.gif');
%	[y,nmap] = imapprox(x,map);
%	int1_axes = axes('position',[0 0 0.54 1],'Visible','off');
%	imshow(y,nmap);
%	set(gcf,'Color',[0.8,0.8,0.8]);
%	set(gca,'XTick',[],'YTick',[],'Visible','off');
%	[X,MAP]=capture;
%	save astwit90 X MAP


elseif strcmp(operation,'init_ccs'),

	watchon;
	ccs_col = 1;


%	ccs_text1 = text(0.59,0.95,'Computer','Color',[0 0.6 0],...
%	'Units','Normalized',...
%	'FontName','Times',...
%	'Fontsize',30,...
%	'FontWeight','Bold');
%	ccs_text3 = text(0.63,0.75,'Systems','Color',[0 0.6 0],...
%	'Units','Normalized',...
%	'FontName','Times',...
%	'Fontsize',30,...
%	'FontWeight','Bold');

%	pic_axes = axes('Position',[0.62 0.815 0.04 0.04]);
%	t=(1/4:1/4:1)'*2*pi;
%	x=sin(t);
%	y=cos(t);
%	fill(x,y,'r');
%	axis('square');
%	set(gca,'Visible','off','XTick',[],'YTick',[]);	

%	pic_axes = axes('Position',[0.865 0.815 0.04 0.04]);
%	t=(1/4:1/4:1)'*2*pi;
%	x=sin(t);
%	y=cos(t);
%	fill(x,y,'r');
%	axis('square');
%	set(gca,'Visible','off','XTick',[],'YTick',[]);	


	ccs_info1 = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1071 0.0594 ],  ...
	'BackgroundColor',[0.77 0.77 0.77],...
	'String','Info','Fontsize',11);
	set(ccs_info1,'CallBack','ccsdemo(''ccs_i1'');');

	ccs_info2 = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.0214 0.1786 0.0594 ],  ...
	'BackgroundColor',[0.77 0.77 0.77],...
	'String','Info','Fontsize',11);
	set(ccs_info2,'CallBack','ccsdemo(''ccs_i2'');');

	ccs_color = uicontrol(fig_ccs,'Style','popup',...
	'Units', 'Normalized','Position', [0.7304 0.0926 0.2143 0.0594 ],  ...
	'BackgroundColor',[0.77 0.77 0.77],...
	'String','Color|Black&White',...
	'Callback','ccsdemo(''color_popup'');','Fontsize',11);

	ccs_close = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.0214 0.1786 0.0594 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'String','Quit','Fontsize',11);
	set(ccs_close,'CallBack','ccsdemo(''close_ccs_def'');');

	alias_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.5914 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.3 0.8 0.3],...
	'String','Aliasing','Fontsize',11);
	set(alias_button,'CallBack','ccsdemo(''close_ccs'');, alias');

	samp_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.5202 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.4 0.82 0.4],...
	'String','Sampling','Fontsize',11);
	set(samp_button,'CallBack','ccsdemo(''close_ccs'');, sampling');

	par_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.4489 0.1786 0.0713 ], ...
	'BackgroundColor',[0.5 0.84 0.5],...
	'String','Numerics','Fontsize',11);
	set(par_button,'CallBack','ccsdemo(''close_ccs'');, numerics');

	freq_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.3777 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.6 0.86 0.6],...
	'String','Frequencies','Fontsize',11);
	set(freq_button,'CallBack','ccsdemo(''close_ccs'');, freqdom');

	observ_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.3064 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.7 0.88 0.7],...
	'String','Observability','Fontsize',11);
	set(observ_button,'CallBack','ccsdemo(''close_ccs'');, observab');

	pd_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.2352 0.1786 0.0713 ], ...
	'BackgroundColor',[0.8 0.9 0.8],...
	'String','PD-control','Fontsize',11);
	set(pd_button,...
	'CallBack','ccsdemo(''close_ccs'');, pdglob,pdcontr');

	noise_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.5875 0.1640 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.85 0.92 0.85],...
	'String','Noise','Fontsize',11);
	set(noise_button,'CallBack','ccsdemo(''close_ccs'');, noise');

	pid_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.5914 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.3 0.8 0.3],...
	'String','PID-control','Fontsize',11);
	set(pid_button,'CallBack','ccsdemo(''close_ccs'');,pidglob, pid');

	sfb_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.5202 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.4 0.82 0.4],...
	'String','State feedback','Fontsize',11);
	set(sfb_button,'CallBack',...
	'ccsdemo(''close_ccs'');,sfbglob,sfb');

	robot_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.4489 0.1786 0.0713 ], ...
	'BackgroundColor',[0.5 0.84 0.5],...
	'String','Robot example','Fontsize',11);
	set(robot_button,'CallBack','ccsdemo(''close_ccs'');, robot');

	rst_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.3777 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.6 0.86 0.6],...
	'String','Pole placement','Fontsize',11);
	set(rst_button,'CallBack','ccsdemo(''close_ccs'');, rst');

	robust_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.3064 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.7 0.88 0.7],...
	'String','Robustness','Fontsize',11);
	set(robust_button,'CallBack','ccsdemo(''close_ccs'');, robust');

	lq_button = uicontrol(fig_ccs,'Style','push',...
	'Units', 'Normalized','Position', [0.7661 0.2352 0.1786 0.0713 ],  ...
	'BackgroundColor',[0.8 0.9 0.8],...
	'String','LQ-control','Fontsize',11);
	set(lq_button,'CallBack','ccsdemo(''close_ccs'');, lqcontr');

	load astwit97
	int1_axes = axes('position',[0 0 1 1],'Visible','off');
	colormap(MAP);
	image(X); 
	set(gca,'XTick',[],'YTick',[]);

	ccs_text2 = text(0.58,0.85,'CCSDEMO','Color',[0 0.6 0],...
	'Units','Normalized',...
	'FontName','Times',...
	'Fontsize',30,...
	'FontWeight','Bold');

	watchoff;

elseif strcmp(operation,'color_popup');

	if get(ccs_color,'Value')==1,
		ccs_col=1;
	elseif get(ccs_color,'Value')==2,
		ccs_col=0;
	end;
 
elseif strcmp(operation, 'close_ccs'),

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','off');
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

elseif strcmp(operation, 'close_ccs_def'),

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

end;

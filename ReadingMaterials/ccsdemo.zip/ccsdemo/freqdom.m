function freqdom(operation);
% FREQDOM	Module illustrating the frequency domain approach
%		of a system.		

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_freq ccs_col fig_ccs
global sine_axes_freq samp_axes_freq mag_axes_freq pha_axes_freq
global sli_nyq nyq_cur sli_w w_cur sli_ph ph_cur
global num den w h nyq
global sine_handle samp_handle samp2_handle
global sine_phase

if nargin == 0,
	operation = 'show';
end;

if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Frequency response');
	if ~existFlag,
      		freqdom('winit_freq');
      		freqdom('init_freq');	
 		[existFlag,figNumber]=figflag('Frequency response');
	else
		clf;
		freqdom('init_freq');
	end;


%%------------------- CALCULATIONS --------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'freqcalc'),

	watchon;

	%-- get correct value of Nyquist frequency
	nyq = get(sli_nyq,'Value');
	set(nyq_cur,'String',num2str(nyq));
	h = 3.14/nyq;

	%-- get correct value of w
	w = get(sli_w,'Value');
	set(w_cur,'String',num2str(w));

	%-- get correct value of sine phase
	sine_phase = get(sli_ph,'Value');
	set(ph_cur,'String',num2str(sine_phase));

	%-- calculate bode plots
	om = logspace(-1,3,1000);
	[mag,phase] = bode(num,den,om);

	%-- plot magnitude	
	axes(mag_axes_freq);
	cla;
	if ccs_col == 1,
	 	loglog(om,mag,'k--');
	else
		loglog(om,mag,'k--');
	end;
	
	%-- plot phase
	axes(pha_axes_freq);
	cla;
	if ccs_col == 1,
		semilogx(om,phase,'k--');
	else
		semilogx(om,phase,'k--');
	end;

	%-- calculate bode plots for system+ZoH
	fr1=zeros(1000,2);
	for j=1:1000
   	fr1(j,1)=om(1,j); 
   	fr1(j,2)= (1-exp(-i*om(1,j)*h))/(i*om(1,j)*h)/(1+i*om(1,j));
	end;
 
	scale = eval(['fr' int2str(nargin)]);
	scaleinfo = all(size(scale) == [1 6]);

	axes(mag_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
 		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
		eval(['magd_handle = loglog(fr' kstr '(:,1),abs(fr' kstr ind '));']);
		if ccs_col == 1,
			set(magd_handle,'Color','k');
		else
			set(magd_handle,'Color','k');
		end;
	end
 
	if scaleinfo
  		axis(scale(1:4)); 
	end
 
	axes(pha_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
  		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
  		eval(['phad_handle = semilogx(fr' kstr '(:,1),180/pi*unwrap(angle(fr' kstr ind ')));']);
		if ccs_col == 1,
			set(phad_handle,'Color','k');
		else
			set(phad_handle,'Color','k');
		end;
	end

	if scaleinfo
  		axis(scale([1,2,5,6])); 
	end

	A = 0.00001:0.1:2;
	nyq_vec = nyq*ones(1,length(A));
	%-- plot Nyquist frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(nyq_vec,A,'r-.','Linewidth',2);
	else
		plot(nyq_vec,A,'k--','Linewidth',2);
	end;
	freq_vec = w*ones(1,length(A));
	%-- plot sine frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(freq_vec,A,'b-.','Linewidth',2);
	else
		plot(freq_vec,A,'k-.','Linewidth',2);
	end;

	%-- plot sine wave
	axes(sine_axes_freq);
	sin_t = 0:0.1/w:15;
	sin_u = sin(w*sin_t+sine_phase);
	set(sine_handle,'XData',sin_t,'YData',sin_u);

	%-- sample the sine wave
	axes(samp_axes_freq);
	sin_ts = 0:h:17;
	sin_us = sin(w*sin_ts+sine_phase);
%	[t,y_out] = stairs(t,y_out);
	set(samp_handle,'XData',sin_ts,'YData',sin_us);
	set(samp2_handle,'XData',sin_ts,'YData',sin_us);

	watchoff;


%%------------------- NYQUIST FREQUENCY ---------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'freq_nyquist'),

	watchon;

	%-- set frequency to nyquist frequency
	w = nyq;
	set(sli_w,'Value',w);
	set(w_cur,'String',num2str(w));

	%-- calculate bode plots
	om = logspace(-1,3,1000);
	[mag,phase] = bode(num,den,om);

	%-- plot magnitude	
	axes(mag_axes_freq);
	cla;
	if ccs_col == 1,
	 	loglog(om,mag,'k--');
	else
		loglog(om,mag,'k--');
	end;
	
	%-- plot phase
	axes(pha_axes_freq);
	cla;
	if ccs_col == 1,
		semilogx(om,phase,'k--');
	else
		semilogx(om,phase,'k--');
	end;

	%-- calculate bode plots for system+ZoH	fr1=zeros(1000,2);
	for j=1:1000
   	fr1(j,1)=om(1,j); 
   	fr1(j,2)= (1-exp(-i*om(1,j)*h))/(i*om(1,j)*h)/(1+i*om(1,j));
	end;
 
	scale = eval(['fr' int2str(nargin)]);
	scaleinfo = all(size(scale) == [1 6]);

	axes(mag_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
 		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
		eval(['magd_handle = loglog(fr' kstr '(:,1),abs(fr' kstr ind '));']);
		if ccs_col == 1,
			set(magd_handle,'Color','k');
		else
			set(magd_handle,'Color','k');
		end;
	end
 
	if scaleinfo
  		axis(scale(1:4)); 
	end
 
	axes(pha_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
  		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
  		eval(['phad_handle = semilogx(fr' kstr '(:,1),180/pi*unwrap(angle(fr' kstr ind ')));']);
		if ccs_col == 1,
			set(phad_handle,'Color','k');
		else
			set(phad_handle,'Color','k');
		end;
	end

	if scaleinfo
  		axis(scale([1,2,5,6])); 
	end

	A = 0.00001:0.1:2;
	nyq_vec = 3.14/h*ones(1,length(A));
	%-- plot sine frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(nyq_vec,A,'r-.','Linewidth',2);
	else
		plot(nyq_vec,A,'k--','Linewidth',2);
	end;
	freq_vec = w*ones(1,length(A));
	%-- plot sine frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(freq_vec,A,'b-.','Linewidth',2);
	else
		plot(freq_vec,A,'k-.','Linewidth',2);
	end;

	%-- plot sine wave
	axes(sine_axes_freq);
	sin_t = 0:0.1/w:15;
	sin_u = sin(w*sin_t+sine_phase);
	set(sine_handle,'XData',sin_t,'YData',sin_u);

	%-- sample the sine wave
	axes(samp_axes_freq);
	sin_ts = 0:h:17;
	sin_us = sin(w*sin_ts+sine_phase);
	set(samp_handle,'XData',sin_ts,'YData',sin_us);
	set(samp2_handle,'XData',sin_ts,'YData',sin_us);

	watchoff;


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_freq'),
   ttlStr='Frequency help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' In this demo, a sine wave is sampled, sent  '
	 ' through a discrete time controller and then '
	 ' converted to an analog signal again.        '
	 ' The D-A converter is a zero-order-hold      '
	 ' circuit. The resulting continuous time sig- '
	 ' nal is sent through a first-order process,  '
	 ' G(s)=1/(s+1). The purpose is to describe the'
	 ' properties of the total transfer function   '
	 ' for this system, which looks like:          '
	 '                        _____                '
	 '                        |clock|              '
	 '    sinus            -----                   '
	 '    |                      |                 '
	 '    |      |-----------------|               '
	 '    |  __|__      ______       __|__     ____'
	 '  ---| A-D |--| H(z) |----| D-A |--|G(s)|--  '
	 '       -----    ------       -----     ----  '
	 ' See Fig. 7.23 CCS.                          '];

   hlpStr2= ...
	['                                             '
	 ' The frequency of the sine wave, the samp-   '
	 ' ling period and the phase of the sinusoidal '
	 ' can be altered.                             '
	 '                                             '
	 ' Bode plots are shown for the process and for'
	 ' the whole system. The upper one is for the  '
	 ' process and the lower one is for the whole  '
	 ' system.                                     '
	 '                                             '
	 ' The button "Nyquist freq." sets the sine    '
	 ' frequency to the Nyquist frequency, pi/h.   ']; 
 
    hwin(ttlStr,hlpStr1,hlpStr2); 


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_freq'),
   ttlStr='Frequency theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Section 7.7 in CCS p.268-278 for reading'  
         ' about frequency response. Look at Example   '
	 ' 7.9 p. 273-275.                             '];

    hwin(ttlStr,hlpStr);   


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_freq'),
   ttlStr='Frequency hints...';
    hlpStr1= ...                                           
        ['                                             '
	 ' Choose the Nyquist frequency to about 3 and '
	 ' the sine frequency to 1. Then, the signal   ' 
	 ' can be properly reconstructed.              '
	 '                                             '
	 ' Change the sine frequency to 10. The Nyquist'
	 ' frequency is lower then the signal frequency'
	 ' which implies that the signal can not be    '
	 ' properly reconstructed after sampling. The  '
	 ' signal after sampling has a much lower fre- '
	 ' quency then the original signal.            '
	 '                                             '
	 ' Set the Nyquist frequency to 3 and the sine '
	 ' frequency to 1, again. Change the sine phase'
	 ' and look at the signals. Then, push the "Ny-'
	 ' quist freq." button. The sine frequency now '
	 ' becomes the same as the Nyquist frequency.  '
	 ' Change the phase again and see what happens '
	 ' to the signals. You can see that, in this   '];

   hlpStr2= ...
	['                                             '
	 ' case, the amplitude of the sampled signal is'
	 ' dependent on the phase.                     '];



    hwin(ttlStr,hlpStr1,hlpStr2);    
       


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_freq'),

	fig_freq = figure('Name',...
	'Frequency response','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.2561 0.4656 0.4861 0.4667 ], ...
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_freq,'Color',[0.8,0.8,0.8]);

elseif strcmp(operation,'init_freq'),
	watchon;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_freq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_freq = uicontrol(fig_freq,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ], ...
	'Callback','freqdom(''close_freq'');');

	help_freq = uicontrol(fig_freq,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ], ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','freqdom(''help_freq'');');

	theory_freq = uicontrol(fig_freq,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','freqdom(''theory_freq'');');

	hint_freq = uicontrol(fig_freq,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','freqdom(''hints_freq'');');

	close_freq = uicontrol(fig_freq,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','freqdom(''close_freq_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_freq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.5038 0.3250 0.4700 ]);

	frame_nyq = uicontrol(fig_freq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.8200 0.3143 0.1100 ]);

	sli_nyq = uicontrol(fig_freq,'Style','slider',...
	'Units', 'Normalized','Position', [0.2671 0.8270 0.2143 0.0450 ],  ...
	'Min',1,'Max',25,...
	'Value',10,'Callback','freqdom(''freqcalc'');');

	if ccs_col == 1,
		nyq_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8729 0.1010 0.0450 ],...
		'String',num2str(get(sli_nyq,'Val')),'ForegroundColor','r');
	else
		nyq_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8729 0.1010 0.0450 ],...
		'String',num2str(get(sli_nyq,'Val')),'ForegroundColor','k');
	end;
	
	nyq_min = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.8250 0.0500 0.0450 ],  ...
	'String',num2str(get(sli_nyq,'Min')));

	nyq_max = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.4814 0.8250 0.0350 0.0450 ],  ...
	'String',num2str(get(sli_nyq,'Max')));

	if ccs_col == 1,
		nyq_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8729 0.2089 0.0450 ],...
		'String','Nyquist freq.=','ForegroundColor','r');
	else
		nyq_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8729 0.2089 0.0450 ],...
		'String','Nyquist freq.=','ForegroundColor','k');
	end;

	frame_w = uicontrol(fig_freq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.7000 0.3143 0.1100 ]);

	sli_w = uicontrol(fig_freq,'Style','slider',...
	'Units', 'Normalized','Position', [0.2571 0.7060 0.2143 0.0450 ],  ...
	'Min',1,'Max',25,...
	'Value',1,...
	'Callback','freqdom(''freqcalc'');');

	if ccs_col == 1,
		w_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7519 0.1010 0.0476 ],...
		'String',num2str(get(sli_w,'Val')),'ForegroundColor','b');
	else
		w_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7519 0.1010 0.0476 ],...
		'String',num2str(get(sli_w,'Val')),'ForegroundColor','k');
	end;

	w_min = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.7060 0.0350 0.0450 ],  ...
	'String',num2str(get(sli_w,'Min')));

	w_max = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.4714 0.7060 0.0482 0.0450 ],  ...
	'String',num2str(get(sli_w,'Max')));

	if ccs_col == 1,
		w_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7519 0.2070 0.0476 ],...
		'ForegroundColor','b',...
		'String','Sine frequency=');
	else
		w_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7519 0.2070 0.0476 ],...
		'ForegroundColor','k',...
		'String','Sine frequency=');
	end;

	frame_ph = uicontrol(fig_freq,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.5800 0.3143 0.1100 ]);

	sli_ph = uicontrol(fig_freq,'Style','slider',...
	'Units', 'Normalized','Position', [0.2521 0.5852 0.2143 0.0450 ],  ...
	'Min',0,'Max',6.28,...
	'Value',0,'Callback','freqdom(''freqcalc'');');

	if ccs_col == 1,
		ph_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.6329 0.1018 0.0476 ],...
		'String',num2str(get(sli_ph,'Val')),'ForegroundColor','k');
	else
		ph_cur = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.6329 0.1018 0.0476 ],...
		'String',num2str(get(sli_ph,'Val')),'ForegroundColor','k');
	end;

	ph_min = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.5852 0.0300 0.0476 ],  ...
	'String',num2str(get(sli_ph,'Min')));

	ph_max = uicontrol(fig_freq,'Style','text',...
	'Units', 'Normalized','Position', [0.4664 0.5852 0.0532 0.0476 ],  ...
	'String','2*pi');

	if ccs_col == 1,
		ph_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.6329 0.2089 0.0450 ],...
		'String','Sine phase=','ForegroundColor','k');
	else
		ph_label = uicontrol(fig_freq,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.6329 0.2089 0.0450 ],...
		'String','Sine phase=','ForegroundColor','k');
	end;

	nyquist_freq = uicontrol(fig_freq,'Style','Push',...
	'String','Nyquist freq.',...
	'Units', 'Normalized','Position', [0.280 0.518 0.1700 0.0500 ],  ...
	'Callback','freqdom(''freq_nyquist'');');

%%------------------ DIAGRAMS ------------------------------------

	%-- create diagram for magnitude response
	mag_axes_freq = axes('Position',[0.62 0.73 0.30 0.20]);
	hold on;
	grid on;
	set(mag_axes_freq, 'XLim',[0.1 200],'YLim',...
	[0.00001 5],'XColor','k','YColor','k',...
	'XScale','log','YScale','log',...
	'FontName','Times','Fontsize',11);
	title('Magnitude response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for magnitude response
	pha_axes_freq = axes('Position',[0.62 0.42 0.30 0.20]);
	hold on;
	grid on;
	set(pha_axes_freq, 'XLim',[0.1 200],'YLim',...
	[-300 0],'XColor','k','YColor','k',...
	'XScale','log',...
	'FontName','Times','Fontsize',11);
	title('Phase response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for sine wave
	sine_axes_freq = axes('Position',[0.23 0.05 0.30 0.26]);
	hold on;
	grid on;
	set(sine_axes_freq, 'XLim',[0 15],'YLim'...
	, [-1.5 1.5],'XColor','k','YColor','k',...
	'XTick',[0 5 10 15],...
	'FontName','Times','Fontsize',11);
	title('Continuous time signal','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram sampled signal
	samp_axes_freq = axes('Position',[0.62 0.05 0.30 0.26]);
	hold on;
	grid on;
	set(samp_axes_freq, 'XLim',[0 15],'YLim',[-1.5 1.5],...
	'XTick',[0 5 10 15],...
	'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Signal after sampling','Color','k',...
	'FontName','Times','Fontsize',11);


	%-- system
	num = 1;
	den = [1 1];

	%-- get correct value of Nyquist frequency
	nyq = get(sli_nyq,'Value');
	h = 3.14/nyq;

	%-- sampling
	[numd,dend] = c2dm(num,den,h,'freq');

	%-- get correct value of w
	w = get(sli_w,'Value');

	%-- sine phase
	sine_phase = get(sli_ph,'Value');

	%-- set simulation parameters
        rktol=1e-4;
        rkmax=0.1;
        rkmin=1e-5;

	%-- calculate bode plots
	om = logspace(-1,3,1000);
	[mag,phase] = bode(num,den,om);

	%-- plot magnitude	
	axes(mag_axes_freq);
	if ccs_col == 1,
	 	loglog(om,mag,'k--');
	else
		loglog(om,mag,'k--');
	end;
	
	%-- plot phase
	axes(pha_axes_freq);
	if ccs_col == 1,
		semilogx(om,phase,'k--');
	else
		semilogx(om,phase,'k--');
	end;

	%-- calculate bode plots for system+ZoH
	fr1=zeros(1000,2);
	for j=1:1000
   	fr1(j,1)=om(1,j); 
   	fr1(j,2)= (1-exp(-i*om(1,j)*h))/(i*om(1,j)*h)/(1+i*om(1,j));
	end;
 
	scale = eval(['fr' int2str(nargin)]);
	scaleinfo = all(size(scale) == [1 6]);

	axes(mag_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
 		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
 		eval(['magd_handle = loglog(fr' kstr '(:,1),abs(fr' kstr ind '));']);
		if ccs_col == 1,
			set(magd_handle,'Color','k');
	else
				set(magd_handle,'Color','k');
		end;
	end
 
	if scaleinfo
  		axis(scale(1:4)); 
	end
 
	axes(pha_axes_freq);
	for k=1:nargin-scaleinfo
  		kstr = int2str(k);
  		eval(['ind = sprintf(''(:,2:%g)'',size(fr' kstr ',2));']);
  		eval(['phad_handle = semilogx(fr' kstr '(:,1),180/pi*unwrap(angle(fr' kstr ind ')));']);
		if ccs_col == 1,
			set(phad_handle,'Color','k');
		else
			set(phad_handle,'Color','k');
		end;
	end

	if scaleinfo
  		axis(scale([1,2,5,6])); 
	end
 
	A = 0.00001:0.1:2;
	freq_vec = w*ones(1,length(A));
	%-- plot sine frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(freq_vec,A,'b-.','Linewidth',2);
	else
		plot(freq_vec,A,'k-.','Linewidth',2);
	end;
	nyq_vec = nyq*ones(1,length(A));
	%-- plot Nyquist frequency
	axes(mag_axes_freq);
	if ccs_col == 1,
		plot(nyq_vec,A,'r-.','Linewidth',2);
	else
		plot(nyq_vec,A,'k--','Linewidth',2);
	end;

	%-- plot sine wave
	axes(sine_axes_freq);
	sin_t = 0:0.1/w:15;
	sin_u = sin(w*sin_t);
	if ccs_col == 1,
		sine_handle = plot(sin_t,sin_u,'k');
	else
		sine_handle = plot(sin_t,sin_u,'k');
	end;
	set(sine_handle,'EraseMode','XOR','LineWidth',2);

	%-- sample the sine wave
	axes(samp_axes_freq);
	sin_ts = 0:h:17;
	sin_us = sin(w*sin_ts);
%	[t,y_out] = stairs(t,y_out);
	if ccs_col == 1,
		samp_handle = plot(sin_ts,sin_us,'b.');
		samp2_handle = plot(sin_ts,sin_us,'k-');
	else
		samp_handle = plot(sin_ts,sin_us,'k.');
		samp2_handle = plot(sin_ts,sin_us,'k-');
	end;
%	[t,y_out] = stairs(sin_ts,sin_us);
%		samp_handle = plot(t,y_out,'k');

	set(samp_handle,'EraseMode','XOR','MarkerSize',15);
	set(samp2_handle,'EraseMode','XOR','LineWidth',1);

	watchoff;

%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_freq'),

	[existFlag,figNumber]=figflag('Frequency response');
    	if existFlag,
		close(fig_freq);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;

elseif strcmp(operation, 'close_freq_def'),

	[existFlag,figNumber]=figflag('Frequency response');
    	if existFlag,
		close(fig_freq);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

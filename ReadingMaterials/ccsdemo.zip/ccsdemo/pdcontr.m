function pdcontr(operation);
% PDCONTR 	Module illustrating PD-control of the double
%		integrator.

%		Author: Helena Haglund
%		LastEditDate : October 15, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_control ccs_col fig_ccs
global step_axes_control contr_axes_control pz_axes_control
global sli_h h_cur sli_k k_cur sli_td td_cur
global num den h k td
global rktol rkmin rkmax
global time_contr time_step output outputd contr cl_poles end_root_locus
global poles_pd zeros_pd output_handle control_handle root_locus
global h0_contr k0_contr td0_contr cl_poles0 time0_step time0_contr
global output0_contr contr0 end_root_locus0

if nargin == 0,
	operation = 'show';
end;

if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('PD-control of Double Integrator');
	if ~existFlag,
      		pdcontr('winit_control');
      		pdcontr('init_control');	
 		[existFlag,figNumber]=...
		figflag('PD-control of Double Integrator');
	else
		clf;
		pdcontr('init_control');
	end;


%%------------------- CALCULATIONS --------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'contr_calc'),

	watchon;

	%-- get correct value of h
	h = get(sli_h,'Value');
	set(h_cur,'String',num2str(h));

	%-- get correct value of K
	k = get(sli_k,'Value');
	set(k_cur,'String',num2str(k));

	%-- get correct value of Td
	td = get(sli_td,'Value');
	set(td_cur,'String',num2str(td));

	%-- closed-loop poles
	chareq = [1 td*k*h-2+0.5*k*h^2 1-td*k*h+0.5*k*h^2];
	cl_poles = roots(chareq);
	end_root_locus = (2*td/h-1)/(2*td/h+1);
	axes(pz_axes_control);
	set(poles_pd, 'XData', real(cl_poles), ...
		'YData', imag(cl_poles));
	set(root_locus, 'XData', real(end_root_locus), ...
		'YData', imag(end_root_locus));

	%-- simulation
	options=simset('RelTol',rktol,'MaxStep',0.1);
	[t,x,y] = sim('pd_cont',[0 20],options);

	%-- plot step response
	axes(step_axes_control);
	set(output_handle,'XData',t,'YData',output');
	time_step = t;
	
	%-- plot control signal
	axes(contr_axes_control);
	[time_contr,contr] = stairs(t,contr);
	set(control_handle,'XData',time_contr,'YData',contr');

	watchoff;


%%------------------- CLEAR --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'contr_clear'),

	watchon;

	%-- plot closed-loop poles
	axes(pz_axes_control);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	if ccs_col == 1,
	      poles_pd=plot(real(cl_poles),imag(cl_poles),'rx');
	      root_locus=plot(real(end_root_locus),imag(end_root_locus),'ro');
	else
	      poles_pd=plot(real(cl_poles),imag(cl_poles),'kx');
	      root_locus=plot(real(end_root_locus),imag(end_root_locus),'ko');
	end;
	set(poles_pd,'LineWidth',2,'EraseMode','None','MarkerSize',9);
	set(root_locus,'LineWidth',2,'EraseMode','None','MarkerSize',7);

	%-- plot step response
	axes(step_axes_control);
	cla;
	if ccs_col == 1,
		output_handle = plot(time_step,output,'r');
	else
		output_handle = plot(time_step,output,'k');
	end;
	set(output_handle,'LineWidth',2,'EraseMode','None');
	
	%-- plot control signal
	axes(contr_axes_control);
	cla;
	if ccs_col == 1,
		control_handle = plot(time_contr,contr,'r');
	else
		control_handle = plot(time_contr,contr,'k');
	end;
	set(control_handle,'LineWidth',2,'EraseMode','None');

	watchoff;


%%------------------- RESET ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'contr_reset'),

	watchon;

	%-- set correct value of h
	set(h_cur,'String',num2str(h0_contr));
	set(sli_h,'Value',h0_contr);

	%-- set correct value of K
	k = get(sli_k,'Value');
	set(k_cur,'String',num2str(k0_contr));
	set(sli_k,'Value',k0_contr);

	%-- set correct value of Td
	td = get(sli_td,'Value');
	set(td_cur,'String',num2str(td0_contr));
	set(sli_td,'Value',td0_contr);

	%-- plot closed-loop poles
	axes(pz_axes_control);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	if ccs_col == 1,
	     poles_pd=plot(real(cl_poles0),imag(cl_poles0),'rx');
	     root_locus=plot(real(end_root_locus0),imag(end_root_locus0),'ro');
	else
	     poles_pd =plot(real(cl_poles0),imag(cl_poles0),'kx');
	     root_locus=plot(real(end_root_locus0),imag(end_root_locus0),'ko');
	end;
	set(poles_pd,'LineWidth',2,'EraseMode','None','MarkerSize',9);
	set(root_locus,'LineWidth',2,'EraseMode','None','MarkerSize',7);

	%-- plot step response
	axes(step_axes_control);
	cla;
	if ccs_col == 1,
		output_handle = plot(time0_step,output0_contr,'r');
	else
		output_handle = plot(time0_step,output0_contr,'k');
	end;
	set(output_handle,'LineWidth',2,'EraseMode','None');
	
	%-- plot control signal
	axes(contr_axes_control);
	cla;
	if ccs_col == 1,
		control_handle = plot(time0_contr,contr0,'r');
	else
		control_handle = plot(time0_contr,contr0,'k');
	end;
	set(control_handle,'LineWidth',2,'EraseMode','None');

	watchoff;


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_control'),
   ttlStr='PD-control help...';

    hlpStr= ...                                           
        ['                                             '  
         ' This demo illustrates control of the Double '
	 ' Integrator with a PD-controller.            '
	 '                                             '
	 ' The importance of choosing a proper regu-   '
	 ' lator design is shown here. In the pole-zero'
	 ' plot you can see how the locations of the   '
	 ' closed-loop poles change with varying values'
	 ' of K and Td in the controller.              '];
   hwin(ttlStr,hlpStr); 


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_control'),
   ttlStr='PD-control theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Section 3.5 in CCS p.107-110 for reading'  
         ' about control of the Double Integrator.     '];

    hwin(ttlStr,hlpStr);   


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_control'),
   ttlStr='PD-control hints...';
    hlpStr1= ...                                           
        ['                                             '
	 ' Set Td=0 and Change K. The system is un-    '
	 ' stable for all values of K.                 '
	 '                                             '
	 ' Set Td=1.5 and h =1 (use reset). You can see'
	 ' that, when K is increased, one pole moves   '
	 ' towards -inf, through -1 and the other pole '
	 ' moves towards 0.5.                          '
	 '                                             '
	 ' Change Td and see how this effects the loca-'
	 ' tion of the zero. This zero represents the  '
	 ' limit of the root locus, which varies be-   '
	 ' ween -1 for Td=0 and +1 for large values.   '
	 ' This zero is the zero of the loop transfer. '
	 '                                             '
	 ' See what happens when Td=0.5. Change K.     '
	 ' The poles are situated on the stability li- '
	 ' mit. It is shown here that, for Td < 0.5,   '
	 ' the system is unstable for all values of K. '];

   hlpStr2= ...
	['                                             '
	 ' It is therefor very important to first      '
	 ' choose a proper value of Td and then set K  '
	 ' to give a good response.                    '];

    hwin(ttlStr,hlpStr1,hlpStr2);    
       


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_control'),

	fig_control = figure('Name',...
	'PD-control of Double Integrator','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.2561 0.4656 0.4861 0.4667 ], ...
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	if strcmp(computer,'pcwin'),
		set(fig_control,'Color',[1 1 1]);
	else
		set(fig_control,'Color',[0.8 0.8 0.8]);
	end;

elseif strcmp(operation,'init_control'),
	watchon;


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_control,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_control = uicontrol(fig_control,'Style','Push',...
	'String','Main Menu','BackgroundColor',[0.6 0.6 1],...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ], ...
	'Callback','pdcontr(''close_control'');');

	help_control = uicontrol(fig_control,'Style','Push',...
	'String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','pdcontr(''help_control'');');

	theory_control = uicontrol(fig_control,'Style','Push',...
	'String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','pdcontr(''theory_control'');');

	hint_control = uicontrol(fig_control,'Style','Push',...
	'String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','pdcontr(''hints_control'');');

%	clear_control = uicontrol(fig_control,'Style','Push',...
%	'String','Clear',...
%	'Units', 'Normalized', ...
%	'Position', [[0.0339 0.4500 0.1429 0.0595 ]],...
%	'BackgroundColor',[0.5 1 0.5],...
%	'Callback','pdcontr(''contr_clear'');');

	reset_control = uicontrol(fig_control,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized', ...
	'Position', [[0.0339 0.3667 0.1429 0.0595 ]],...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','pdcontr(''contr_reset'');');

	close_control = uicontrol(fig_control,'Style','Push',...
	'String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','pdcontr(''close_control_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_control,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.5038 0.3250 0.4700 ]);

	frame_h = uicontrol(fig_control,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.8200 0.3143 0.1100 ]);

	sli_h = uicontrol(fig_control,'Style','slider',...
	'Units', 'Normalized','Position', [0.2671 0.8270 0.2143 0.0450 ],  ...
	'Min',0.1,'Max',2,...
	'Value',1,'Callback','pdcontr(''contr_calc'');');

	if ccs_col == 1,
		h_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8729 0.1010 0.0450 ],...
		'String',num2str(get(sli_h,'Val')),'ForegroundColor','k');
	else
		h_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.8729 0.1010 0.0450 ],...
		'String',num2str(get(sli_h,'Val')),'ForegroundColor','k');
	end;
	
	h_min = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.8250 0.0500 0.0450 ],  ...
	'String',num2str(get(sli_h,'Min')));

	h_max = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.4814 0.8250 0.0350 0.0450 ],  ...
	'String',num2str(get(sli_h,'Max')));

	if ccs_col == 1,
		h_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8729 0.2089 0.0450 ],...
		'String','Sampl.period h=','ForegroundColor','k');
	else
		h_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.8729 0.2089 0.0450 ],...
		'String','Sampl.period h=','ForegroundColor','k');
	end;

	frame_k = uicontrol(fig_control,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.7000 0.3143 0.1100 ]);

	sli_k = uicontrol(fig_control,'Style','slider',...
	'Units', 'Normalized','Position', [0.2571 0.7060 0.2143 0.0450 ],  ...
	'Min',0.1,'Max',2.5,...
	'Value',0.5,...
	'Callback','pdcontr(''contr_calc'');');

	if ccs_col == 1,
		k_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7519 0.1010 0.0476 ],...
		'String',num2str(get(sli_k,'Val')),'ForegroundColor','k');
	else
		k_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.7519 0.1010 0.0476 ],...
		'String',num2str(get(sli_k,'Val')),'ForegroundColor','k');
	end;

	k_min = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.7060 0.0350 0.0450 ],  ...
	'String',num2str(get(sli_k,'Min')));

	k_max = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.4714 0.7060 0.0482 0.0450 ],  ...
	'String',num2str(get(sli_k,'Max')));

	if ccs_col == 1,
		k_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7519 0.2070 0.0476 ],...
		'ForegroundColor','k',...
		'String','Parameter K=');
	else
		k_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.7519 0.2070 0.0476 ],...
		'ForegroundColor','k',...
		'String','Parameter K=');
	end;

	frame_td = uicontrol(fig_control,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2100 0.5800 0.3143 0.1100 ]);

	sli_td = uicontrol(fig_control,'Style','slider',...
	'Units', 'Normalized','Position', [0.2521 0.5852 0.2143 0.0476 ], ...
	'Min',0,'Max',5,...
	'Value',1.5,'Callback','pdcontr(''contr_calc'');');

	if ccs_col == 1,
		td_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.6329 0.1018 0.0476 ],...
		'String',num2str(get(sli_td,'Val')),'ForegroundColor','k');
	else
		td_cur = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.4179 0.6329 0.1018 0.0476 ], ...
		'String',num2str(get(sli_td,'Val')),'ForegroundColor','k');
	end;

	td_min = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.2150 0.5852 0.0300 0.0476 ],  ...
	'String',num2str(get(sli_td,'Min')));

	td_max = uicontrol(fig_control,'Style','text',...
	'Units', 'Normalized','Position', [0.4664 0.5852 0.0532 0.0476 ],  ...
	'String',num2str(get(sli_td,'Max')));

	if ccs_col == 1,
		td_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.6329 0.2089 0.0476 ],...
		'String','Parameter Td=','ForegroundColor','k');
	else
		td_label = uicontrol(fig_control,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.2150 0.6329 0.2089 0.0476 ],...
		'String','Parameter Td=','ForegroundColor','k');
	end;


%%------------------ DIAGRAMS ------------------------------------

	%-- create diagram for step response
	step_axes_control = axes('Position',[0.62 0.55 0.35 0.37]);
	hold on;
	grid on;
	set(step_axes_control, 'XLim',[0 20],'YLim',...
	[-0.5 1.5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Step response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create diagram for control signal
	contr_axes_control = axes('Position',[0.62 0.06 0.35 0.37]);
	hold on;
	grid on;
	set(contr_axes_control, 'XLim',[0 20],'YLim',...
	[-2 2 ],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Control signal','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create pole/zero diagram
	pz_axes_control = axes('Position',[0.24 0.06 0.30 0.30]);
	hold on;
	grid on;
	set(pz_axes_control, 'XLim',[-1.2 1.2],'YLim'...
	, [-1.2 1.2],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Closed-loop poles','Color','k',...
	'FontName','Times','Fontsize',11);
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	axis('equal');

	%-- system
	num = 1;
	den = [1 0 0];

	%-- get correct value of h
	h = get(sli_h,'Value');h0_contr = h;

	%-- get correct value of K
	k = get(sli_k,'Value');k0_contr = k;

	%-- get correct value of Td
	td = get(sli_td,'Value');td0_contr = td;

	%-- closed-loop poles
	chareq = [1 td*k*h-2+0.5*k*h^2 1-td*k*h+0.5*k*h^2];
	cl_poles = roots(chareq);cl_poles0 = cl_poles;
	end_root_locus = (2*td/h-1)/(2*td/h+1);end_root_locus0=end_root_locus;
	axes(pz_axes_control);
	if ccs_col == 1,
	       poles_pd=plot(real(cl_poles),imag(cl_poles),'rx');
	       root_locus=plot(real(end_root_locus),imag(end_root_locus),'ro');
	else
	       poles_pd=plot(real(cl_poles),imag(cl_poles),'kx');
	       root_locus=plot(real(end_root_locus),imag(end_root_locus),'ko');
	end;
	set(poles_pd,'LineWidth',2,'EraseMode','None','MarkerSize',9);
	set(root_locus,'LineWidth',2,'EraseMode','None','MarkerSize',7);

	%-- set simulation parameters
        rktol=1e-4;
        rkmax=0.1;
        rkmin=1e-5;

	%-- simulation
	option=simset('RelTol',rktol,'MaxStep',0.1);
	[t,x,y] = sim('pd_cont',[0 20],option);
	time_step = t;time0_step = time_step;
	output0_contr = output;

	%-- plot step response
	axes(step_axes_control);
	if ccs_col == 1,
		output_handle = plot(t,output,'r');
	else
		output_handle = plot(t,output,'k');
	end;
	set(output_handle,'LineWidth',2,'EraseMode','None');
	
	%-- plot control signal
	axes(contr_axes_control);
	[t,contr] = stairs(t,contr);
	time0_contr = t;
	contr0 = contr;
	if ccs_col == 1,
		control_handle = plot(t,contr,'r');
	else
		control_handle = plot(t,contr,'k');
	end;
	set(control_handle,'LineWidth',2,'EraseMode','None');

	watchoff;

%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_control'),

	[existFlag,figNumber]=figflag('PD-control of Double Integrator');
    	if existFlag,
		close(fig_control);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_control_def'),

	[existFlag,figNumber]=figflag('PD-control of Double Integrator');
    	if existFlag,
		close(fig_control);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

global k td h

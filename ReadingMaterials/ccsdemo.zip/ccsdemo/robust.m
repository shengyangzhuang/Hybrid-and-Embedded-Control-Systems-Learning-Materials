function robust(operation);
% ROBUST	Module illustrating robustness.

%		Author: Helena Haglund
%		LastEditDate : January 3, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_rob fig2_rob ccs_col fig_ccs
global disc_axes_rob1 disc_axes_rob2
global k_cur j1_cur j2_cur d_cur
global sli_k sli_j1 sli_j2 sli_d
global k j1 j2 d
global help_box clear_box error
global frame_am am_label frame_ao ao_label
global system_rob
global input_zeta input_om om_label zeta_label 
global input_alfa alfa_label
global h_cur slid
global choise1_rob choise2_rob
global error1_rob error2_rob
global bc ac
global h zeta om alfa alf 
global Bd0 Ad0 R S T Bd Ad Bdm Adm
global time mag mag0 y y0 w w0 uc u u0
global RSTdes change_var
global zeros0_cl poles0_cl zeros_cl poles_cl
global pn zn p z

if nargin == 0,
	operation = 'show';
end;

%-- checks if the window already exists
if strcmp(operation,'show'),
	[existFlag,figNumber]=figflag('Robustness');
	if ~existFlag,
      		robust('winit_rob');
      		robust('init_rob');	
 		[existFlag,figNumber]=figflag('Robustness');
	else
		clf;
		robust('init_rob');
	end;


%%---------------CALCULATIONS ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'robcalc'),

	watchon;
	if RSTdes == 0,
		%-- reset parameters and update plots if new design is made
		robust('robreset');
		RSTdes = 1;
	end;
	figure(fig2_rob);
	subplot(211);
	cla;
	subplot(212);
	cla;
	figure(fig_rob);

	%-- set slider h to desired value
	h = get(slid,'Val');h0 = h;
	set(h_cur,'String',num2str(h));

	%-- sample system
	[Bd,Ad] = c2dm(bc,ac,h,'zoh');Bd0 = Bd;
	Ad0 = Ad;

	%-- set omega, zeta and alfa to desired values
	om = str2num(get(input_om,'String'));
	if isempty(om),
		om = 1;
		set(input_om,'String',num2str(om));
	end;
	zeta = str2num(get(input_zeta,'String'));
	if isempty(zeta),
		zeta = 0.7;
		set(input_zeta,'String',num2str(zeta));
	end;
	alfa = 2*om;

	%-- compute desired closed-loop polynomial
	Acm1 = [1 2*om*zeta om*om];		
	Acm2 = [1 alf*om];
	Acm = conv(Acm1,Acm2);
	rch = roots(Acm)*h;
	Adm  = real(poly(exp(rch)));	
 	
	bplus = 1;
	bminus = Bd;	
	l = 1;

	%-- compute observer polynomial Ao
%	Ao = conv([1 -exp(-alfa*h)],[1 -exp(-alfa*h)]);
%	Ao = conv(Ao,[1 -exp(-alfa*h)]);
	Aco = conv([1 2*zeta*alfa alfa^2],[1 alfa]);
	rch = roots(Aco)*h;
	Ao  = real(poly(exp(rch)));

	%-- regulator with integrator
	Ar = [1 -1];

	%-- RST-design
	ae      =conv(Ad,Ar);			
	be      = conv(bminus,1);
	aoam    = conv(Adm,Ao);
	
	%-- solving dab-equation
	na = length(ae);			
	nb = length(be);
	nc = length(aoam);
	ny = na - 1;
	if ny<1,
  		x = c/ae;
  		y = 0;
  		return;
	end;
	nx = nc - ny;
	aoam = [zeros(1,nb-nx-1) aoam];
	nc = length(aoam);
	nx = nc - ny;
	if nx<1,
  		x = 0;
  		y = aoam/be;
  		return;
	end;
	be = [zeros(1,nx-nb+1) be];
	za = zeros(1,nx-1);
	zb = zeros(1,ny-1);
	ma = toeplitz([ae za],[ae(1) za]);
	mb = toeplitz([be zb],[be(1) zb]);
	m = [ma mb];
	if rank(m)<min(size(m)),
  		disp('Singular problem due to common factors in A and B');
	end;
	xy = aoam/m';
	r1 = xy(1:nx);
	s = xy(nx+1:nc);
	
	r       = conv(conv(r1,Ar),bplus);
	t0      = sum(Adm)/sum(bminus);
  	t       = t0*conv(Ao,1);
 	S       = s/r(1);
	T       = t/r(1);
	R       = r/r(1);

	%-- compute closed-loop system
	Bd0_cl = conv(Bd0,T);
	n = size(Ad0,2)-size(Bd0,2);
	Ad0_cl = conv(Ad,R)+[zeros(n,1) conv(Bd0,S)];
	zeros0_cl = roots(Bd0_cl);
	poles0_cl = roots(Ad0_cl);

	axes(disc_axes_rob1);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot closed-loop system poles and zeros
	if ccs_col == 1,
		zn = plot(real(zeros0_cl),imag(zeros0_cl),'ro');
		set(zn,'Linewidth',2,'Markersize',7);
		pn = plot(real(poles0_cl),imag(poles0_cl),'rx');
		set(pn,'Linewidth',2,'Markersize',9);
	else
		zn = plot(real(zeros0_cl),imag(zeros0_cl),'ko');
		set(zn,'Linewidth',2,'Markersize',7);
		pn = plot(real(poles0_cl),imag(poles0_cl),'kx');
		set(pn,'Linewidth',2,'Markersize',9);
	end;

	axes(disc_axes_rob2);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	if ccs_col == 1,
		z = plot(real(zeros0_cl),imag(zeros0_cl),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(poles0_cl),imag(poles0_cl),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(zeros0_cl),imag(zeros0_cl),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(poles0_cl),imag(poles0_cl),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	figure(fig2_rob);
	subplot(211);
	time=0:h:30;

	%-- load disturbance
	v1 = zeros(round(15/h),1);
	v = [v1;-2*ones(length(time)-length(v1),1)];

	%-- reference signal
	uc = ones(length(v),1);

	%-- calculate and plot output signal
	n = size(conv(Ad,R),2)-size(conv(Bd,T),2);
	[y1,x]=dlsim(conv(Bd,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[y2,x] = dlsim(conv(Bd,R),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	y=y1+y2;y0=y;
	if ccs_col == 1,
		plot(time,y,'r');
	else
		plot(time,y,'k');
	end;	

	%-- calculate and plot control signal
	[u1,x] = dlsim(conv(Ad,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[u2,x] = dlsim(conv(Bd,S),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	u = u1-u2;u0=u;
	subplot(212);
	timeu = time;
	[time_s,u_s] = stairs(timeu,u);
	if ccs_col == 1,
		plot(time_s,u_s,'r');
	else
		plot(time_s,u_s,'k');
	end;				

	figure(fig_rob);
	watchoff;


%%------- CHANGE PHYSICAL PARAMETERS ----------------------
%%---------------------------------------------------------

elseif strcmp(operation,'change_fys'),

		%-- reference signal given, do simulation
		change_var = 1;
		
		watchon;
		if RSTdes == 1,
			RSTdes = 0;
		end;


		%-- set physical parameters to desired values	
		k = get(sli_k,'Val');
		set(k_cur,'String',num2str(k));
		j1 = get(sli_j1,'Val');
		set(j1_cur,'String',num2str(j1));
		j2 = get(sli_j2,'Val');
		set(j2_cur,'String',num2str(j2));
		d = get(sli_d,'Val');
		set(d_cur,'String',num2str(d));

		%-- calculate new process
		om0 = sqrt(k*(j1+j2)/(j1*j2));
		ki = 1;
		a = j1/(j1+j2);
		b1 = d/(j1*om0);
		b2 = d/(j2*om0);
		gam = ki/(j1*om0);
		delta = 1/(j1*om0);
		A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
		B = [0 gam 0]';
		C = [0 0 om0];
		D = 0;
		[bc,ac] = ss2tf(A,B,C,D,1);

		%-- sample process
		[Bd,Ad] = c2dm(bc,ac,h,'zoh');

		%-- calculate closed-loop system
		Bd_cl = conv(Bd,T);
		n = size(Ad,2)-size(Bd,2);
		Ad_cl = conv(Ad,R)+[zeros(n,1) conv(Bd,S)];
		zeros_cl = roots(Bd_cl);
		poles_cl = roots(Ad_cl);

		axes(disc_axes_rob2);
		%-- plot resent closed-loop poles and zeros
		if ccs_col == 1,
			z = plot(real(zeros_cl),imag(zeros_cl),'ro');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles_cl),imag(poles_cl),'rx');
			set(p,'Linewidth',2,'Markersize',9);
		else
			z = plot(real(zeros_cl),imag(zeros_cl),'ko');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles_cl),imag(poles_cl),'kx');
			set(p,'Linewidth',2,'Markersize',9);
		end;

		figure(fig2_rob);
		subplot(211);
		time=0:h:30;

		%-- if step signal, plot nominal step response
		if ccs_col == 1,
			plot(time,y0,'r');
		else
			plot(time,y0,'k');
		end;

		%-- load disturbance
		v1 = zeros(round(15/h),1);
		v = [v1;-2*ones(length(time)-length(v1),1)];

		%-- reference signal
		uc = ones(length(v),1);

		%-- calculate and plot output signal
		n = size(conv(Ad,R),2)-size(conv(Bd,T),2);
		[y1,x]=dlsim(conv(Bd,T),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[y2,x] = dlsim(conv(Bd,R),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		y=y1+y2;
		if ccs_col == 1,
			plot(time,y,'r');
		else
			plot(time,y,'k');
		end;

		%-- calculate and plot control signal
		[u1,x] = dlsim(conv(Ad,T),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
		[u2,x] = dlsim(conv(Bd,S),...
		conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
		u = u1-u2;
		subplot(212);
		timeu = time;
		[time_s,u_s] = stairs(timeu,u);
		if ccs_col == 1,
			plot(time_s,u_s,'r');
		else
			plot(time_s,u_s,'k');
		end;						

	figure(fig_rob);
	watchoff;


%%---------------- CLEAR ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'robclear'),

	if RSTdes == 0,
		watchon;   

		axes(disc_axes_rob2);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		%-- plot nominal closed-loop poles and zeros
		if ccs_col == 1,	
			z = plot(real(zeros0_cl),imag(zeros0_cl),'ro');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles0_cl),imag(poles0_cl),'rx');
			set(p,'Linewidth',2,'Markersize',9);
		else
			z = plot(real(zeros0_cl),imag(zeros0_cl),'ko');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles0_cl),imag(poles0_cl),'kx');
			set(p,'Linewidth',2,'Markersize',9);
		end;

		%-- plot most resent closed-loop poles and zeros
		if ccs_col == 1,	
			z = plot(real(zeros_cl),imag(zeros_cl),'ro');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles_cl),imag(poles_cl),'rx');
			set(p,'Linewidth',2,'Markersize',9);
		else
			z = plot(real(zeros_cl),imag(zeros_cl),'ko');
			set(z,'Linewidth',2,'Markersize',7);
			p = plot(real(poles_cl),imag(poles_cl),'kx');
			set(p,'Linewidth',2,'Markersize',9);
		end;

		figure(fig2_rob);
		subplot(211);
		cla;
		subplot(212);
		cla;
		timeu = time;
		%-- plot nominal step response & Control signal
		[time_s,u0_s] = stairs(timeu,u0);
		if ccs_col == 1,
			subplot(211);
			plot(time,y0,'r');
			subplot(212);
			plot(time_s,u0_s,'r');
		else
			subplot(211);
			plot(time,y0,'k');
			subplot(212);
			plot(time_s,u0_s,'k');
		end;

		[time_s,u_s] = stairs(timeu,u);
		if ccs_col == 1,
			%-- calculate and plot output and control signal
			subplot(211);
			plot(time,y,'r');
			subplot(212);
			plot(time_s,u_s,'r');
		else
			%-- calculate and plot output and control signal
			subplot(211);
			plot(time,y,'k');
			subplot(212);
			plot(time_s,u_s,'k');
		end;
				
	end;
	figure(fig_rob);
	watchoff;


%%---------------- RESET ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'robreset'),

	watchon;
	
	%-- set physical parameters to nominal values
	change_var = 0;
	j1 = 10/9;
	j2 = 10;
	k = 1;
	d = 0.1;
	ki = 1;
	om0 = sqrt(k*(j1+j2)/(j1*j2));

	%-- set sliders to correct values
	set(sli_k,'Val',k);
	set(sli_j1,'Val',j1);
	set(sli_j2,'Val',j2);
	set(sli_d,'Val',d);
	set(k_cur,'String',num2str(k));
	set(j1_cur,'String',num2str(j1));
	set(j2_cur,'String',num2str(j2));
	set(d_cur,'String',num2str(d));

	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;
	[bc,ac] = ss2tf(A,B,C,D,1);

	%-- sample system
	[Bd,Ad]= c2dm(bc,ac,h,'zoh');

	axes(disc_axes_rob2);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- calculate closed-loop system
	Bd_cl = conv(Bd,T);
	n = size(Ad,2)-size(Bd,2);
	Ad_cl = conv(Ad,R)+[zeros(n,1) conv(Bd,S)];
	zeros_cl = roots(Bd_cl);
	poles_cl = roots(Ad_cl);

	%-- creat new handles after clear
	z = plot(NaN,NaN,'ro');
	set(z,'Linewidth',2,'EraseMode','None','Markersize',7);
	hold on;
	p = plot(NaN,NaN,'rx');
	set(p,'Linewidth',2,'EraseMode','None','Markersize',9);

	%-- plot nominal closed-loop poles and zeros
	if ccs_col == 1,	
		z = plot(real(zeros_cl),imag(zeros_cl),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(poles_cl),imag(poles_cl),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(zeros_cl),imag(zeros_cl),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		p = plot(real(poles_cl),imag(poles_cl),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	figure(fig2_rob);

	subplot(211);
	cla;
	subplot(212);
	cla;

	t=0:h:30;

	%-- load disturbance
	v1 = zeros(round(15/h),1);
	v = [v1;-2*ones(length(time)-length(v1),1)];

	%-- reference signal
	uc = ones(length(v),1);

	%-- calculate and plot output signal
	n = size(conv(Ad,R),2)-size(conv(Bd,T),2);
	[y1,x]=dlsim(conv(Bd,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[y2,x] = dlsim(conv(Bd,R),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	y=y1+y2;

	%-- calculate and plot control signal
	[u1,x] = dlsim(conv(Ad,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[u2,x] = dlsim(conv(Bd,S),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	u = u1-u2;u0=u;
	timeu = t;
	[time_s,u_s] = stairs(timeu,u);
	[time_s,u0_s] = stairs(timeu,u0);
	if ccs_col == 1,
		subplot(211);
		plot(t,y,'r');
		plot(t,y0,'r');	
		subplot(212);
		plot(time_s,u_s,'r');	
		plot(time_s,u0_s,'r');	
	else
		subplot(211);
		plot(t,y,'k');
		plot(t,y0,'k');	
		subplot(212);
		plot(time_s,u_s,'k');	
		plot(time_s,u0_s,'k');		
	end;

	figure(fig_rob);
	watchoff;


%%------------------- HELP ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'help_rob'),
   ttlStr='Robustness help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' This demo illustrates Robustness.           ' 
	 '                                             ' 
         ' The process used is the Robot Mechanism,    '   
         ' CCS p. 156. This mechanism is also treated  '
	 ' in the "Robot example" module.              '
	 '                                             '	
	 ' An RST-design can be made with optional     '  
         ' values of h and the Am-polynomial. Am is of '
	 ' third order and so is also the observer-    '
	 ' polynomial. The observer is twice as fast as'
	 ' the desired closed-loop response. The zeros '
	 ' are never cancelled and there is always an  '
	 ' integrator in the controller.               ' 
	 '                                             '               
	 ' After having designed a regulator for the   '
	 ' nominal process, it is possible to change   '
	 ' the physical process, with the variables d, '
	 ' j1, j2 and k, and see how this effects the  '];


    hlpStr2= ...
	['                                             '
	 ' stability of the closed-loop system. The de-'
	 ' sign is always done for the nominal process.'
	 ' The aim is to investigate what happens to   '
	 ' the closed-loop system when the real process'
	 ' is different from the process for which the '
	 ' controller is designed.                     ']; 

    hwin(ttlStr,hlpStr1,hlpStr2); 


%%------------------- THEORY ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'theory_rob'),
   ttlStr='Robustness theory...';
    hlpStr= ...                                           
        ['                                             '
	 ' See Section 5.5 in CCS p. 183-186 for       '
	 ' reading about "Sensitivity to modeling      '
	 ' errors".                                    '
	 '                                             '
	 ' See Section 5.9 in CCS p. 208-213 for       '
	 ' reading more about "Pole-Placement design-  '
	 ' Robot Mechanism".                           '
         '                                             '
	 ' See Section 4.7 in CCS p. 156-160 for more  '
	 ' information about the Robot example.        ']; 

    hwin(ttlStr,hlpStr); 


%%------------------- HINTS ---------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'hints_rob'),
   ttlStr='Robustness hints...';
    hlpStr= ...                                           
        ['                                             '
	 ' Use the default design of the regulator.    '
	 ' Change j2 from 10 to 5 in small steps, by   '
	 ' pressing the left arrow, and see how the    '
	 ' changes effects the location of the closed  '
	 ' loop poles, the step response and the con-  '
	 ' trol signal.                                '
	 '                                             '
	 ' The module "Robot example" shows how the    '
	 ' open-loop system changes when the process-  '
	 ' parameters are altered.                     '];

    hwin(ttlStr,hlpStr);           


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_rob'),

	fig_rob = figure('Name',...
	'Robustness','NumberTitle','off',...
	'Units', 'Normalized', ...
	'Position', [0.0425 0.4178 0.4861 0.4667 ],...
	'BackingStore','Off','DefaultUicontrolFontSize',11);
	set(fig_rob,'Color',[0.8,0.8,0.8]);


elseif strcmp(operation,'init_rob'),
	watchon;

	%-- checks if the plot window already exists	
	[existFlag,figNumber]=...
	figflag('Plots, Robustness');
	if ~existFlag,
      		fig2_rob= figure('Name',...
		'Step response & Control signal, Robustness',...
		'NumberTitle','Off','BackingStore','Off',...
		'Units', 'Normalized', ...
		'Position', [0.5286 0.4178 0.4340 0.4667 ]);
		set(fig2_rob,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=...
		figflag...
		('Step response & Control signal, Robustness');
	else
		clf;fig=gcf;
	end;

	figure(fig_rob);


%%-------------------FRAME LEFT--------------------------------------

	frame_left = uicontrol(fig_rob,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_rob = uicontrol(fig_rob,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','robust(''close_rob'');');

	help_rob = uicontrol(fig_rob,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','robust(''help_rob'');');

	theory_rob = uicontrol(fig_rob,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','robust(''theory_rob'');');

	hint_rob = uicontrol(fig_rob,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','robust(''hints_rob'');');

	clear_rob = uicontrol(fig_rob,'Style','Push',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ],  ...
	'String','Clear plots',...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','robust(''robclear'');');

	reset_rob = uicontrol(fig_rob,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized','Position', [0.0339 0.3667 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','robust(''robreset'');');

	close_rob = uicontrol(fig_rob,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','robust(''close_rob_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle1 = uicontrol(fig_rob,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.5300 0.3839 0.4438 ]);

	frame_middle2 = uicontrol(fig_rob,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3839 0.5000 ]);

	middle_text = uicontrol('Style','text',...
	'Units', 'Normalized','Position', [0.2393 0.9010 0.3214 0.0476 ],  ...
	'String','Design of RST-controller','ForegroundColor','k');

	frame_h = uicontrol(fig_rob,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2270 0.775 0.3240 0.1100 ]);

	slid = uicontrol(fig_rob,'Style','slider',...
	'Units', 'Normalized','Position', [0.2889 0.7805 0.2143 0.0476 ],  ...
	'Min',0.01,'Max',2,...
	'Value',0.5,'Callback','robust(''robcalc'');');

	h_cur = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.4393 0.8281 0.1018 0.0476 ],  ...
	'String',num2str(get(slid,'Val')));

	h_min = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2304 0.7805 0.0536 0.0476 ],  ...
	'String',num2str(get(slid,'Min')));
	h_max = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.5032 0.7805 0.0432 0.0476 ],  ...
	'String',num2str(get(slid,'Max')));

	h_label = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2304 0.8281 0.2089 0.0476 ],  ...
	'String','Sampl.period h=');

	frame_am = uicontrol(fig_rob,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2304 0.5433 0.3125 0.2181 ]);

	am_label = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2529 0.7019 0.2786 0.0476 ],  ...
	'String','Cont. Am-polynomial');

	charam_label = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2529 0.6619 0.2786 0.0476 ],  ...
	'String','Am(s)=s^2+2zws+w^2');

	input_zeta = uicontrol(fig_rob,'Style','edit',...
	'Units', 'Normalized','Position', [0.4125 0.6067 0.0714 0.0476 ],  ...
	'String','0.7','Backgroundcolor','w');
	set(input_zeta,'Callback','robust(''robcalc'');');
	zeta = str2num(get(input_zeta,'String'));	

	input_om = uicontrol(fig_rob,'Style','edit',...
	'Units', 'Normalized','Position', [0.4125 0.5590 0.0714 0.0476 ],  ...
	'String','1','Backgroundcolor','w');
	set(input_om,'Callback','robust(''robcalc'');');
	om = str2num(get(input_om,'String'));	
	
	zeta_label = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2875 0.6067 0.1250 0.0452 ],  ...
	'String','zeta =');
	om_label = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.2875 0.5590 0.1250 0.0476 ],  ...
	'String','omega =');


%%---------------- RIGHT ------------------------------------

%	right_text = uicontrol(fig_rob,'Style','text',...
%	'Units', 'Normalized','Position', [0.6321 0.7210 0.3393 0.0476 ],  ...
%	'String','Changes in physical process.','ForegroundColor','k');

	frame_d = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2399 0.4019 0.3071 0.1100 ]);

	sli_d = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.3041 0.4067 0.1786 0.0476 ],  ...
	'Min',0.01,'Max',1,...
	'Value',0.10);

	d_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4738 0.4543 0.0694 0.0476 ],  ...
	'String',num2str(get(sli_d,'Val')));

	d_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.4067 0.0570 0.0476 ],  ...
	'String',num2str(get(sli_d,'Min')));

	d_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4827 0.4067 0.0605 0.0476 ],  ...
	'String',num2str(get(sli_d,'Max')));

	d_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.4543 0.2021 0.0476 ],  ...
	'String','Damping d=');
	set(sli_d,'CallBack','robust(''change_fys'')');

	frame_j1 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2399 0.2805 0.3071 0.1100 ]);

	sli_j1 = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.3041 0.2853 0.1786 0.0476 ],  ...
	'Min',0.8,'Max',2,...
	'Value',10/9);

	j1_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4738 0.3329 0.0694 0.0476 ],  ...
	'String',num2str(get(sli_j1,'Val')));

	j1_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.2853 0.0570 0.0476 ],  ...
	'String',num2str(get(sli_j1,'Min')));
	j1_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4827 0.2853 0.0605 0.0476 ],  ...
	'String',num2str(get(sli_j1,'Max')));

	j1_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.3329 0.2301 0.0476 ], ...
	'String','Mom. of inertia j1=');
	set(sli_j1,'CallBack','robust(''change_fys'')');

	frame_j2 = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2399 0.1590 0.3071 0.1100 ]);

	sli_j2 = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.3041 0.1638 0.1786 0.0476 ],  ...
	'Min',5,'Max',15,...
	'Value',10);

	j2_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4738 0.2114 0.0694 0.0476 ],  ...
	'String',num2str(get(sli_j2,'Val')));

	j2_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.1638 0.0570 0.0476 ],  ...
	'String',num2str(get(sli_j2,'Min')));

	j2_max = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4827 0.1638 0.0605 0.0476 ],  ...
	'String',num2str(get(sli_j2,'Max')));

	j2_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.2114 0.2301 0.0476 ], ...
	'String','Mom. of inertia j2=');
	set(sli_j2,'CallBack','robust(''change_fys'')');

	frame_k = uicontrol(gcf,'Style','frame',...
	'Units', 'Normalized','Position', [0.2399 0.0352 0.3071 0.1100 ]);

	sli_k = uicontrol(gcf,'Style','slider',...
	'Units', 'Normalized','Position', [0.3041 0.0400 0.1786 0.0476 ],  ...
	'Min',0.5,'Max',1.5,...
	'Value',1);

	k_cur = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4738 0.0876 0.0694 0.0476 ],  ...
	'String',num2str(get(sli_k,'Val')));

	k_min = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.0400 0.0570 0.0476 ],  ...
	'String',num2str(get(sli_k,'Min')));
	k_max=uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.4827 0.0400 0.0605 0.0476 ],  ...
	'String',num2str(get(sli_k,'Max')));

	k_label = uicontrol(gcf,'Style','text',...
	'Units', 'Normalized','Position', [0.2436 0.0876 0.2301 0.0476 ],...
	'String',' Spring constant k=');
	set(sli_k,'CallBack','robust(''change_fys'')');


%%-------------- SYSTEM -------------------------------------

	RSTdes = 1;
	change_var = 0;

	%-- physical parameters
	j1 = 10/9;
	j2 = 10;
	k = 1;
	d = 0.1;
	ki = 1;
	om0 = sqrt(k*(j1+j2)/(j1*j2));
	a = j1/(j1+j2);
	b1 = d/(j1*om0);
	b2 = d/(j2*om0);
	gam = ki/(j1*om0);
	delta = 1/(j1*om0);
	A =om0.* [0 1 -1;a-1 -b1 b1;a b2 -b2];
	B = [0 gam 0]';
	C = [0 0 om0];
	D = 0;
	[bc,ac] = ss2tf(A,B,C,D,1);
	h = get(slid,'Val');h0 = h;

	%-- sample system
	[Bd,Ad]= c2dm(bc,ac,h,'zoh');Bd0 = Bd; 
	Ad0 = Ad;
	alf = 1;

	%-- calculate desired closed-loop characteristic polynomial
	Acm1 = [1 2*om*zeta om*om];
 	Acm2 = [1 alf*om];
	Acm = conv(Acm1,Acm2);
	rch = roots(Acm)*h;
	Adm  = real(poly(exp(rch)));

	%-- no cancellation of process zeros
	bplus = 1;
	bminus = Bd;	
	l = 1;

	%-- calculate observer polynomial Ao
	alfa = 2*om;
%	Ao = conv([1 -exp(-alfa*h)],[1 -exp(-alfa*h)]);
%	Ao = conv(Ao,[1 -exp(-alfa*h)]);
	Aco = conv([1 2*zeta*alfa alfa^2],[1 alfa]);
	rch = roots(Aco)*h;
	Ao  = real(poly(exp(rch)));

	%-- regulator with integrator
	Ar = [1 -1];

	%-- RST-design
	ae      =conv(Ad,Ar);			
	be      = conv(bminus,1);
	aoam    = conv(Adm,Ao);
	
	%-- solve dab-equation
	na = length(ae);			
	nb = length(be);
	nc = length(aoam);
	ny = na - 1;
	if ny<1,
  		x = c/ae;
  		y = 0;
  		return;
	end;
	nx = nc - ny;
	aoam = [zeros(1,nb-nx-1) aoam];
	nc = length(aoam);
	nx = nc - ny;
	if nx<1,
  		x = 0;
  		y = aoam/be;
  		return;
	end;
	be = [zeros(1,nx-nb+1) be];
	za = zeros(1,nx-1);
	zb = zeros(1,ny-1);
	ma = toeplitz([ae za],[ae(1) za]);
	mb = toeplitz([be zb],[be(1) zb]);
	m = [ma mb];
	if rank(m)<min(size(m)),
  		disp('Singular problem due to common factors in A and B');
	end;
	xy = aoam/m';
	r1 = xy(1:nx);
	s = xy(nx+1:nc);
		r       = conv(conv(r1,Ar),bplus);
	t0      = sum(Adm)/sum(bminus);
  	t       = t0*conv(Ao,1);
 	S       = s/r(1);
	T       = t/r(1);
	R       = r/r(1);

	%-- create pole/zero diagram for nominal system
	disc_axes_rob1 = axes('Position',[0.65 0.55 0.30 0.35]);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	title('Closed loop nominal system','Color','k',...
	'FontName','Times','Fontsize',11);
	set(disc_axes_rob1,'XLim',[-1.2 1.2],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','Xcolor','k','Ycolor','k',...
	'FontName','Times','Fontsize',11);

	%-- create pole/zero diagram for changed system
	disc_axes_rob2 = axes('Position',[0.65 0.05 0.30 0.35]);
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	title('Closed loop system','Color','k',...
	'FontName','Times','Fontsize',11);
	set(disc_axes_rob2,'XLim',[-1.2 1.2],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','Xcolor','k','Ycolor','k',...
	'FontName','Times','Fontsize',11);

	%-- calculate nominal closed-loop system
	Bd0_cl = conv(Bd0,T);
	n = size(Ad0,2)-size(Bd0,2);
	Ad0_cl = conv(Ad0,R)+[zeros(n,1) conv(Bd0,S)];
	zeros0_cl = roots(Bd0_cl);
	poles0_cl = roots(Ad0_cl);
	axes(disc_axes_rob1);

	%-- plot nominal closed-loop system, poles and zeros
	if ccs_col == 1,
		zn = plot(real(zeros0_cl),imag(zeros0_cl),'ro');
		set(zn,'Linewidth',2,'Markersize',7);
		hold on;
		pn = plot(real(poles0_cl),imag(poles0_cl),'rx');
		set(pn,'Linewidth',2,'Markersize',9);
	else
		zn = plot(real(zeros0_cl),imag(zeros0_cl),'ko');
		set(zn,'Linewidth',2,'Markersize',7);
		hold on;
		pn = plot(real(poles0_cl),imag(poles0_cl),'kx');
		set(pn,'Linewidth',2,'Markersize',9);
	end;

	axes(disc_axes_rob2);
	%-- create handles for closed-loop poles and zeros
	if ccs_col ==1,
		z = plot(real(zeros0_cl),imag(zeros0_cl),'ro');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(poles0_cl),imag(poles0_cl),'rx');
		set(p,'Linewidth',2,'Markersize',9);
	else
		z = plot(real(zeros0_cl),imag(zeros0_cl),'ko');
		set(z,'Linewidth',2,'Markersize',7);
		hold on;
		p = plot(real(poles0_cl),imag(poles0_cl),'kx');
		set(p,'Linewidth',2,'Markersize',9);
	end;

	figure(fig2_rob);

	%-- create axes for plotting ouput and reference signals
	step_axes = subplot(211);	
	hold on;
	grid on;
	set(step_axes, 'XLim',[0 30],'YLim'...
	, [-1.5 2],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Step response','Color','k',...
	'FontName','Times','Fontsize',11);

	%-- create axes for plotting control signal
	step_axes = subplot(212);	
	hold on;
	grid on;
	set(step_axes, 'XLim',[0 30],'YLim'...
	, [-1.5 5],'XColor','k','YColor','k',...
	'FontName','Times','Fontsize',11);
	title('Control signal','Color','k',...
	'FontName','Times','Fontsize',11);

	time=0:h:30;

	%-- load disturbance
	v1 = zeros(round(15/h),1);
	v = [v1;-2*ones(length(time)-length(v1),1)];

	%-- reference signal
	uc = ones(length(v),1);

	%-- calculate and plot output signal
	n = size(conv(Ad,R),2)-size(conv(Bd,S),2);
	[y1,x]=dlsim(conv(Bd,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[y2,x] = dlsim(conv(Bd,R),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	y=y1+y2;y0=y;
	subplot(211);
	if ccs_col == 1,
		plot(time,y,'r');
	else
		plot(time,y,'k');
	end;

	%-- calculate and plot control signal
	[u1,x] = dlsim(conv(Ad,T),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],uc);
	[u2,x] = dlsim(conv(Bd,S),...
	conv(Ad,R)+[zeros(1,n) conv(Bd,S)],v);
	u = u1-u2;u0=u;
	subplot(212);
	timeu = time;
	[time_s,u_s] = stairs(time,u);
	if ccs_col == 1,
		plot(time_s,u_s,'r');
	else
		plot(time_s,u_s,'k');
	end;			

	figure(fig_rob);


%%-------------- ERROR MESSAGES -------------------------------------

	error1_rob = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.3548 0.3929 0.0595 ],  ...
	'String',...
	'Not a correct 2:nd order system,',...
	'BackgroundColor','r');
	set(error1_rob,'Visible','off');

	error2_rob = uicontrol(fig_rob,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.2952 0.3929 0.0595 ], ...
	'String',...
	'chose system 3 again and redo it!',...
	'BackgroundColor','r');
	set(error2_rob,'Visible','off');

	figure(fig_rob);
	watchoff;


%%-------------------- CLOSE --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_rob'),

	[existFlag,figNumber]=figflag('Robustness');
    	if existFlag,
		close(fig_rob);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, Robustness');
    	if existFlag,
		close(fig2_rob);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_rob_def'),

	[existFlag,figNumber]=figflag('Robustness');
    	if existFlag,
		close(fig_rob);	
 	end;

	[existFlag,figNumber]=...
	figflag('Step response & Control signal, Robustness');
    	if existFlag,
		close(fig2_rob);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;

end;

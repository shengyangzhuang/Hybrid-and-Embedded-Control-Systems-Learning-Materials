global fig_pid fig2_pid
global system
global input_num input_den num_label den_label 
global delay input_delay limit input_limit text_limit aw aw0 awlast
global error1 instruct 
global not_ZN not_KT ZN KT self
global sli_h sli_k sli_ti sli_td sli_tt
global h_cur k_cur ti_cur td_cur tt_cur
global h k ti td tt N b
global ex x tune sys
global num den input_num input_den sat del
global ku tu kp

function sfb(operation);
% SFB		Module illustrating Pole placement design based on
%		the internal model of the system.
%		
%		There are choises between having observer or not
%		and between cancelling process zeros or not. The
%		user also chooses the sampling period, the 
%		continuous time closed loop characteristic poly-
% 		nomial and the observer polynomial. 

%		Author: Helena Haglund
%		LastEditDate : October15, 1997 B. Wittenmark
%               Copyright:
%		Department of Automatic Control
%		Lund Institute of Technology, SWEDEN

global fig_sfb fig2_sfb ccs_col fig_ccs fig_val_sfb
global system_sfb
global error1_sfb error2_sfb error3_sfb
global input_a input_b input_c a_label b_label c_label
global input_zeta input_om input_zeta1 input_om1
global slid h_cur
global om om1 zeta zeta1 zeta0 om0 zeta10 om10
global a11 a12 a21 a22 b1 b2 c1 c2 h l1 l2 l3 lc k1 k2 Pl Pk L
global phi11 phi12 phi21 phi22 gam1 gam2
global k1last k2last
global A B C phi gam phi_i gam_i
global save_syst load_syst
global choise1 choise2
global h0 om10 zeta10 om0 zeta0 a110 a120 a210 a220 b10 b20 c10 c20
global phi110 phi120 phi210 phi220 gam10 gam20 
global Pl0 l10 l20 l30 lc0 stateold Pk0 k10 k20 observ observ0 ex sys_sfb
global ad ad1
global charsfb_label
global rktol rkmin rkmax

if nargin == 0,
	operation = 'show';
end;

%-- checks if window already exists
if strcmp(operation,'show'),			
	[existFlag,figNumber]=figflag('State feedback design');
	if ~existFlag,
      		sfb('winit_sfb');
      		sfb('init_sfb');	
 		[existFlag,figNumber]=figflag('State feedback design');
	else
		clf;
		sfb('init_sfb');
	end;


%%------------ SYSTEM SPECIFICATION ---------------------------------
%%------------------------------------------------------------------

elseif strcmp(operation,'sfb_syst'),

	figure(fig2_sfb);
	subplot(211);
	cla;
	subplot(212);
	cla;

	ex = 0;
	figure(fig_sfb);
	if get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3|...
	get(system_sfb,'Value') ==4,

		watchon;
		set(error1_sfb,'Visible','off');
		set(error2_sfb,'Visible','off');
		set(error3_sfb,'Visible','off');

		set(input_a,'Visible','off');
		set(input_b,'Visible','off');
		set(input_c,'Visible','off');
		set(a_label,'Visible','off');
		set(b_label,'Visible','off');
		set(c_label,'Visible','off');

		set(input_zeta1,'Visible','on');
		set(input_om1,'Visible','on');

		%-- set sliders to current values
		set(input_zeta1,'String','0.7');	
		set(input_om1,'String','2');
		set(input_zeta,'String','0.7');	
		set(input_om,'String','4');
		zeta1 = str2num(get(input_zeta1,'String'));zeta10 = zeta1;
		om1 = str2num(get(input_om1,'String'));om10 = om1;
		zeta = str2num(get(input_zeta,'String'));zeta0 = zeta;
		om = str2num(get(input_om,'String'));om0 = om;

		h = 0.5;h0 = h;
		set(slid,'Val',h);
		set(h_cur,'String',num2str(h));	

		if get(choise1,'Value') == 2,
			%-- with observer		
			set(input_zeta,'Visible','on');	
			set(input_om,'Visible','on');
		else
			%-- without observer
			set(input_zeta,'Visible','off');
			set(input_om,'Visible','off');
		end;	

		if get(system_sfb,'value')==2,    
			%-- double integrator
			A = [0 1;0 0];
			B = [0 1]';
			C = [1 0];
			D = 0;
			sys_sfb = 2;
		elseif get(system_sfb,'value')==3,    
			%-- harmonic oscillator
			A = [0 1;-1 0];
			B = [0;1];
			C = [1 0];
			D = 0;
			sys_sfb = 3;
		elseif get(system_sfb,'value')==4,   
			%-- free choise of 2:nd order system
			set(input_a,'Visible','on');
			set(input_b,'Visible','on');
			set(input_c,'Visible','on');
			set(a_label,'Visible','on');
			set(b_label,'Visible','on');
			set(c_label,'Visible','on');
			sys_sfb = 4;
		end;

		%-- calculate if system is given, if "make own" wait for 
		%-- acknowledgement and calculate in sfb_calc
		if get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3,

		[ma,na] = size(A);
		[mb,nb] = size(B);
		[mc,nc] = size(C);

		%-- check if system is of 2:nd order
		if ma~=2|na~=2|mb~=2|nb~=1|mc~=1|nc~=2,

			%-- if not 2:nd order: error
			set(error1_sfb,'Visible','on');
			set(error2_sfb,'Visible','on');

			set(input_a,'Visible','off');
			set(input_b,'Visible','off');
			set(input_c,'Visible','off');
			set(a_label,'Visible','off');
			set(b_label,'Visible','off');
			set(c_label,'Visible','off');
			set(system_sfb,'Value',1);
		else
	
			[phi,gam] = c2d(A,B,h);
			ctrm = ctrb(phi,gam);
			
			%-- check if system controllable
			if rank(ctrm)== size(ctrm),	
				a11=A(1,1);a110 = a11;
				a12=A(1,2);a120 = a12;
				a21=A(2,1);a210 = a21;
				a22=A(2,2);a220 = a22;
				b1=B(1);b10 = b1;
				b2=B(2);b20 = b2;
				c1=C(1);c10 = c1;
				c2=C(2);c20 = c2;

			%-- calculate desired closed-loop system polynomial
  			ac1=[1 2*om1*zeta1 om1*om1];
  			rch = roots(ac1)*h;
			ad1  = real(poly(exp(rch)));
			Pl = roots(ad1);
	
			if get(choise2,'value')==1,
				%-- with integrator
			     set(charsfb_label,'String','(s^2+2zws+w^2)(s+p)');
				Li = place(phi,gam,Pl);

				%-- place l3 on real axes
				p = abs(Pl);   
				%-- just to avoid error unmotivated error
				%-- message from "place"   
				pint = p(1)+0.0001;
				ad1 = conv(ad1,[1 -pint]);
				Pl = [Pl;pint];
				phi_i = [phi [0 0]';-C 1];
				gam_i = [gam;0];
	
				%-- calculate state feedback L
				L = place(phi_i,gam_i,Pl);
				l3 = L(3);
				l30 = l3;

				%-- make static gain equal to one
				lc = 1/(C*inv((eye(2)-phi+gam*Li))*gam);
				lc0 = lc;	
		
			elseif get(choise2,'value')==2,	
				%-- without integrator
			      	set(charsfb_label,'String','s^2+2zws+w^2');

				%-- calculate state feedback L
				L = place(phi,gam,Pl);
				l3 = 0;
				l30 = l3;

				%-- make static gain equal to one
				lc = 1/(C*inv((eye(2)-phi+gam*L))*gam);
				lc0 = lc;
			end;
	 
			subplot(222);
			cla;
			%-- plot unit circle
			t=0:.1:6.3;
			plot(sin(t),cos(t),'k-');
			Pl0 = Pl;

			%-- plot closed loop poles
			if ccs_col == 1,
				p = plot(real(Pl),imag(Pl),'rx');
			else
				p = plot(real(Pl),imag(Pl),'kx');
			end;	
			set(p,'Linewidth',2,'Markersize',9);		 
	
			l1 = L(1);l10 = l1;
			l2 = L(2);l20 = l2;

			if get(choise1,'Value') == 2,
				%-- with observer
				%-- calculate desired closed loop char. pol.
				ac = [1 2*om*zeta om*om];
  				rch = roots(ac)*h;
				ad  = real(poly(exp(rch)));
 
				%-- calculate closed-loop poles
				Pk = roots(ad);Pk0 = Pk;

				%-- plot closed-loop poles
				subplot(222);
				if ccs_col == 1,
					p = plot(real(Pk),imag(Pk),'gx');
				else
					p = plot(real(Pk),imag(Pk),'k+');
				end;

				set(p,'Linewidth',2,'Markersize',9);

				%-- calculate observer
				phi11 = phi(1,1);phi110=phi11;
				phi12 = phi(1,2);phi120=phi12;
				phi21 = phi(2,1);phi210=phi21;
				phi22 = phi(2,2);phi220=phi22;
				gam1 = gam(1);gam10 = gam1;
				gam2 = gam(2);gam20 = gam2;

				%-- calculate observer K
				K = place(phi',C',Pk)';
				k1=K(1);
				k2=K(2);
				k10 = k1;
				k20 = k2;
			
			end;		
	
			if get(choise1,'value')==1,
				%-- simulation with observer	
				stateold = 1;
				option=simset('MaxStep',h);
				[t,x,y] = sim('sfb_s',[0 50],option);
				observ = 0;observ0 = observ;

			elseif get(choise1,'value')==2,
				%-- simulation without observer
				stateold = 2;
				option=simset('MaxStep',h);
				[t,x,y] = sim('sfb_o_s',[0 50],option);
				observ = 1;observ0 = observ;
			end;

	   		time=1:h:50;

			%-- plot step response
			figure(fig2_sfb);
			subplot(211);
			cla;
			if ccs_col == 1,
				if get(choise2,'value') == 1,
					plot(t,st,'r');	
				else
					plot(t,st,'r--');	
				end;
			else
				if get(choise2,'value') == 1,
					plot(t,st,'k');	
				else
					plot(t,st,'k--');	
				end;
			end;
	
			%-- plot control signal	
			subplot(212);
			cla;
			[ts,us]=stairs(t,u);
			if ccs_col == 1,	
				if get(choise2,'value') == 1,
					plot(ts,us,'r');	
				else
					plot(ts,us,'r--');	
				end;
			else
				if get(choise2,'value') == 1,
					plot(ts,us,'k');	
				else
					plot(ts,ts,'k--');	
				end;
			end;
		else
			set(error3_sfb,'Visible','on');
			set(input_a,'Visible','off');
			set(input_b,'Visible','off');
			set(input_c,'Visible','off');
			set(a_label,'Visible','off');
			set(b_label,'Visible','off');
			set(c_label,'Visible','off');
			set(system_sfb,'Value',1);
		end;
		end;	
	
	end;
	figure(fig_sfb);
	watchoff;
	end;


%%---------- CALCULATES AND SIMULATES AFTER A CHANGE------------------
%%--------------------------------------------------------------------

elseif strcmp(operation,'sfb_calc'),

if get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3|...
get(system_sfb,'Value') ==4,
	figure(fig_sfb);
	watchon;
	set(error1_sfb,'Visible','off');
	set(error2_sfb,'Visible','off');



	if get(choise1,'Value') == 1,	
		%-- without observer	
		set(input_zeta,'Visible','off');
		set(input_om,'Visible','off');
	else
		%-- with observer
		set(input_zeta,'Visible','on');	
		set(input_om,'Visible','on');
	end;

	%-- set h to current value
	h = get(slid,'Value');
	hlast = h;
	set(h_cur,'String',num2str(h));	
	if get(system_sfb,'Value')==4 & ex~=1,
		%-- read in given system
		A = str2num(get(input_a,'String'));
		B = str2num(get(input_b,'String'));
		B = B'; 
		C = str2num(get(input_c,'String'));
	elseif get(system_sfb,'Value')==4 & ex==1,
		
	end;

	[ma,na] = size(A);
	[mb,nb] = size(B);
	[mc,nc] = size(C);

	%-- check if system 2:nd order
	if ma~=2|na~=2|mb~=2|nb~=1|mc~=1|nc~=2,

		set(error1_sfb,'Visible','on');
		set(error2_sfb,'Visible','on');

		set(input_a,'Visible','off');
		set(input_b,'Visible','off');
		set(input_c,'Visible','off');
		set(a_label,'Visible','off');
		set(b_label,'Visible','off');
		set(c_label,'Visible','off');
		set(system_sfb,'Value',1);
	else
	
		%-- sample system
 		[phi,gam] = c2d(A,B,h);

		ctrm = ctrb(phi,gam);
			
		%-- check if system controllable
		if rank(ctrm)== size(ctrm),	
			a11=A(1,1);a110 = a11;
			a12=A(1,2);a120 = a12;
			a21=A(2,1);a210 = a21;
			a22=A(2,2);a220 = a22;
			b1=B(1);b10 = b1;
			b2=B(2);b20 = b2;
			c1=C(1);c10 = c1;
			c2=C(2);c20 = c2;
	
			%-- get current values of omega and zeta
			zeta1 = str2num(get(input_zeta1,'String'));
			om1 = str2num(get(input_om1,'String'));

			%-- if no value, set zeta and omega to nominal values
			if isempty(zeta1),
				zeta1 = zeta10;
				set(input_zeta1,'String',num2str(zeta10));
			end;
			if isempty(om1),
				om1 = om10;
				set(input_om1,'String',num2str(om10));
			end;

			%-- calculate desired characteristic polynomial	
			ac1 = [1 2*om1*zeta1 om1*om1];
  			rch = roots(ac1)*h;
			ad1  = real(poly(exp(rch)));
			Pl = roots(ad1);
	
			if get(choise2,'value')==1;
				%-- with integrator
				set(charsfb_label,'String','(s^2+2zws+w^2)(s+p)');
		 		Li = place(phi,gam,Pl);

				%-- place l3 on the real axis	
				p = abs(Pl);   
				%-- just to avoid error unmotivated error
				%-- message from "place"
				pint = p(1)+0.0001;
				ad1 = conv(ad1,[1 -pint]);
				Pl = [Pl;pint];
				phi_i = [phi [0 0]';-C 1];
				gam_i = [gam;0];
				L = place(phi_i,gam_i,Pl);
				l3 = L(3);
				l3last = l3;
				%-- make static gain equal to one
				lc = 1/(C*inv((eye(2)-phi+gam*Li))*gam);
				lclast = lc;
		
			elseif get(choise2,'value')==2,	
				%-- without integrator
				set(charsfb_label,'String','s^2+2zws+w^2');
				L = place(phi,gam,Pl);
				l3 = 0;
				l3last = l3;
				%-- make static gain equal to one
				lc = 1/(C*inv((eye(2)-phi+gam*L))*gam);
				lclast = lc;
			end;
		 
			subplot(222);
			cla;
			%-- plot unit circle
			t=0:.1:6.3;			
			plot(sin(t),cos(t),'k-');

			%-- plot closed-loop poles
			if ccs_col == 1,
				p = plot(real(Pl),imag(Pl),'rx');
			else
				p = plot(real(Pl),imag(Pl),'kx');
			end;
			set(p,'Linewidth',2,'Markersize',9);
	
			l1 = L(1);
			l1last = l1;
			l2 = L(2);
			l2last = l2;

			if get(choise1,'Value') == 2,
				%-- with observer
				%-- set zeta and omega to current values
				zeta = str2num(get(input_zeta,'String'));
				om = str2num(get(input_om,'String'));

				%-- if no value, set zeta and omega to 
				%-- nominal values
				if isempty(zeta),
				       zeta = zeta0;
				       set(input_zeta,'String',num2str(zeta0));
				end;
				if isempty(om),
					om = om0;
					set(input_om,'String',num2str(om0));
				end;

				%-- calculate desired closed-loop polynomial
				ac = [1 2*om*zeta om*om];
 				rch = roots(ac)*h;
				ad  = real(poly(exp(rch)));
	
				Pk = roots(ad);
				subplot(222);
				if ccs_col == 1,
					p = plot(real(Pk),imag(Pk),'gx');
				else
					p = plot(real(Pk),imag(Pk),'k+');
				end;
				set(p,'Linewidth',2,'Markersize',9);

				%-- calculate observer
				phi11 = phi(1,1);
				phi12 = phi(1,2);
				phi21 = phi(2,1);
				phi22 = phi(2,2);
				gam1 = gam(1);
				gam2 = gam(2);

				%-- calculate observer K
				K = place(phi',C',Pk);
				k1=K(1);
				k1last = k1;
				k2=K(2);
				k2last = k2;
			end;

			figure(fig2_sfb);

			if get(choise1,'value')==1,
			    %-- simulation without observer
			option=simset('MaxStep',h);
			    [t,x,y] = sim('sfb_s',[0 50],option);
			elseif get(choise1,'value')==2,
			%-- simulation with observer
			option=simset('MaxStep',h);
			[t,x,y] = sim('sfb_o_s',[0 50],option);
			end;

			%-- plot step response
			subplot(211);
			if ccs_col == 1,
				if get(choise2,'value') == 1,
					plot(t,st,'r');	
				else
	 				plot(t,st,'r--');	
				end;
			else
				if get(choise2,'value') == 1,
					plot(t,st,'k');	
				else
					plot(t,st,'k--');	
				end;
			end;

			%-- plot control signal
			subplot(212);
			[ts,us]=stairs(t,u);
			if ccs_col == 1,
				if get(choise2,'value') == 1,
					plot(ts,us,'r');	
				else
					plot(ts,us,'r--');	
				end;
			else
				if get(choise2,'value') == 1,
					plot(ts,us,'k');	
				else
					plot(ts,us,'k--');	
				end;
			end;
		else
			set(error3_sfb,'Visible','on');
			set(input_a,'Visible','off');
			set(input_b,'Visible','off');
			set(input_c,'Visible','off');
			set(a_label,'Visible','off');
			set(b_label,'Visible','off');
			set(c_label,'Visible','off');
			set(system_sfb,'Value',1);
		end;
	end;
	figure(fig_sfb);
	watchoff;
end;


%%---------- CLEARS PLOTS, KEEPS THE LAST ONE AND THE ORIGINAL ONE-----
%%---------------------------------------------------------------------

elseif strcmp(operation,'sfb_clear'),

if (get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3|...
get(system_sfb,'Value') ==4),

	figure(fig_sfb);
	watchon;

	figure(fig2_sfb);

	subplot(211);
	cla;
	subplot(212);
	cla;


	if get(choise1,'value')==1,
		%-- simulation without observer
		option=simset('MaxStep',h);
		[t,x,y] = sim('sfb_s',[0 50],option);
	elseif get(choise1,'value')==2,
		%-- simulation with observer
		k1 = k1last;
		k2 = k2last;
		option=simset('MaxStep',h);
		[t,x,y] = sim('sfb_o_s',[0 50],option);
	end;

	%-- plot step response
	subplot(211);
	if ccs_col == 1,
		if get(choise2,'value') == 1,
			plot(t,st,'r');	
		else
	 		plot(t,st,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(t,st,'k');	
		else
			plot(t,st,'k--');	
		end;
	end;
	
	%-- plot control signal
	subplot(212);
	[ts,us]=stairs(t,u);
	if ccs_col == 1,
		if get(choise2,'value') == 1,
			plot(ts,us,'r');	
		else
	 		plot(ts,us,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(ts,us,'k');	
		else
			plot(ts,us,'k--');	
		end;
	end;		

	figure(fig_sfb);
 	watchoff;
end;


%%-------------- RESET-------------------------------------
%%---------------------------------------------------------

elseif strcmp(operation,'sfb_reset'),

figure(fig_sfb);
if get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3,

	watchon;

	%-- set parameters to nominal values
	h = h0;
	om1 = om10;
	zeta1 = zeta10;
	om = om0;
	zeta = zeta0;
	a11 = a110;
	a12 = a120;
	a21 = a210;
	a22 = a220;
	b1 = b10;
	b2 = b20;
	c1 = c10;
	c2 = c20;
	Pl = Pl0;
	l1 = l10;
	l2 = l20;
	l3 = l30;
	lc = lc0;

	%-- set sliders to nominal values
	set(input_zeta1,'String',num2str(zeta1));	
	set(input_om1,'String',num2str(om1));
	set(input_zeta,'String',num2str(zeta));	
	set(input_om,'String',num2str(om));
	set(h_cur,'String',num2str(h));	
	set(slid,'Val',h);

	set(choise2,'value',1);
	set(charsfb_label,'String','(s^2+2zws+w^2)(s+p)');


	if observ == 0,
		%-- simulation without observer
		subplot(222);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');
		set(choise1,'value',1);
		stateold = 1;
		option=simset('Maxstep',h);
		[t,x,y] = sim('sfb_s',[0 50],option);
		set(input_zeta,'Visible','off');
		set(input_om,'Visible','off');
	elseif observ == 1,
		%-- simulation with observer
		Pk =Pk0;
		k1 = k10;
		k2 = k20;
				
		%-- calculate observer
		phi11 = phi110;
		phi12 = phi120;
		phi21 = phi210;
		phi22 = phi220;
		gam1 = gam10;
		gam2 = gam20;
		subplot(222);
		cla;
		%-- plot unit circle
		t=0:.1:6.3;
		plot(sin(t),cos(t),'k-');

		if ccs_col == 1,
			p = plot(real(Pk),imag(Pk),'gx');
		else
			p = plot(real(Pk),imag(Pk),'k+');
		end;
		set(p,'Linewidth',2,'Markersize',9);
		observ = observ0;		
		set(choise1,'value',2);
		stateold = 2;
		option=simset('Maxstep',h);
		[t,x,y] = sim('sfb_o_s',[0 50],option);
		set(input_zeta,'Visible','on');
		set(input_om,'Visible','on');
	end;

	subplot(222);
	if ccs_col == 1,
		p = plot(real(Pl),imag(Pl),'rx');
	else
		p = plot(real(Pl),imag(Pl),'kx');
	end;
	set(p,'Linewidth',2,'Markersize',9);

	figure(fig2_sfb);

	%-- plot step response
	subplot(211);
	cla;
	if ccs_col == 1,
		if get(choise2,'value') == 1,
			plot(t,st,'r');	
		else
	 		plot(t,st,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(t,st,'k');	
		else
			plot(t,st,'k--');	
		end;
	end;	
	%-- plot control signal
	subplot(212);
	cla;
	[ts,us]=stairs(t,u);
	if ccs_col == 1,
		if get(choise2,'value') == 1,
			plot(ts,us,'r');	
		else
	 		plot(ts,us,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(ts,us,'k');	
		else
			plot(ts,us,'k--');	
		end;
	end;
	figure(fig_sfb);
	watchoff;
end;


%%---------------- SAVE ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'sfb_save'),

	if get(system_sfb,'Value') ==2|get(system_sfb,'Value') ==3|...
	get(system_sfb,'Value') ==4,

if get(save_syst,'value')==2,
	save syst1sfb A B C D om1 zeta1 om zeta h l3 observ Pl Pk sys_sfb l1 l2 lc a11 a12 a21 a22 b1 b2 c1 c2 phi phi11 phi12 phi21 phi22 gam gam1 gam2 k1 k2 ad1
elseif get(save_syst,'value')==3,
	save syst2sfb A B C D om1 zeta1 om zeta h l3 observ Pl Pk sys_sfb l1 l2 lc a11 a12 a21 a22 b1 b2 c1 c2 phi phi11 phi12 phi21 phi22 gam gam1 gam2 k1 k2 ad1
elseif get(save_syst,'value')==4,
	save syst3sfb A B C D om1 zeta1 om zeta h l3 observ Pl Pk sys_sfb l1 l2 lc a11 a12 a21 a22 b1 b2 c1 c2 phi phi11 phi12 phi21 phi22 gam gam1 gam2 k1 k2 ad1
elseif get(save_syst,'value')==5,
	save syst4sfb A B C D om1 zeta1 om zeta h l3 observ Pl Pk sys_sfb l1 l2 lc a11 a12 a21 a22 b1 b2 c1 c2 phi phi11 phi12 phi21 phi22 gam gam1 gam2 k1 k2 ad1
elseif get(save_syst,'value')==6,
	save syst5sfb A B C D om1 zeta1 om zeta h l3 observ Pl Pk sys_sfb l1 l2 lc a11 a12 a21 a22 b1 b2 c1 c2 phi phi11 phi12 phi21 phi22 gam gam1 gam2 k1 k2 ad1
end;

end;
set(save_syst,'Value',1);


%%-----------------LOAD-----------------------------------------
%%--------------------------------------------------------------

elseif strcmp(operation,'sfb_load'),

	figure(fig_sfb);
	watchon;

	%-- load value in desired file if file exists
	if get(load_syst,'value')==2,
		if exist('syst1sfb.mat')==2,
			load syst1sfb
			ex = 1;
		else
			ex = 0;
		end;  
	elseif get(load_syst,'value')==3,
		if exist('syst2sfb.mat')==2,
			load syst2sfb
			ex =1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==4,
		if exist('syst3sfb.mat')==2,
			load syst3sfb
			ex = 1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==5,
		if exist('syst4sfb.mat')==2,
			load syst4sfb
			ex = 1;
		else
			ex = 0;
		end; 
	elseif get(load_syst,'value')==6,
		if exist('syst5sfb.mat')==2,
			load syst5sfb
			ex = 1;
		else
			ex = 0;
		end; 
	end;

    if ex == 1,

	%-- set nominal parameters to loaded values
	h0 = h;
	om10 = om1;
	zeta10 = zeta1;
	om0 = om;
	zeta0 = zeta;
	a110 = a11;
	a120 = a12;
	a210 = a21;
	a220 = a22;
	b10 = b1;
	b20 = b2;
	c10 = c1;
	c20 = c2;
	Pl0 = Pl;
	l10 = l1;
	l20 = l2;
	l30 = l3;
	lc0 = lc;
	phi110 = phi11;
	phi120 = phi12;
	phi210 = phi21;
	phi220 = phi22;
	gam10 = gam1;
	gam20 = gam2;

	set(slid,'Value',h);
	set(h_cur,'String',num2str(h));
	set(system_sfb,'Value',sys_sfb);

	set(input_zeta1,'Visible','on');	
	set(input_om1,'Visible','on');

	if get(system_sfb,'Value')==4,
		set(input_a,'Visible','on');
		set(input_b,'Visible','on');
		set(input_c,'Visible','on');
		set(a_label,'Visible','on');
		set(b_label,'Visible','on');
		set(c_label,'Visible','on');
		set(input_a,'String',num2str(A));
		set(input_b,'String',num2str(B));
		set(input_c,'String',num2str(C));
	else
		set(input_a,'Visible','off');
		set(input_b,'Visible','off');
		set(input_c,'Visible','off');
		set(a_label,'Visible','off');
		set(b_label,'Visible','off');
		set(c_label,'Visible','off');
	end;

	if l3 == 0,
		%-- no integrator
		set(choise2,'Value',2);
		set(charsfb_label,'String','s^2+2zws+w^2');
	else
		%-- integrator
		set(choise2,'Value',1);
		set(charsfb_label,'String','(s^2+2zws+w^2)(s+p)');
	end;		

	set(input_zeta1,'String',num2str(zeta1));	
	set(input_om1,'String',num2str(om1));

	set(input_zeta,'String',num2str(zeta));	
	set(input_om,'String',num2str(om));

	subplot(222);
	cla;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');

	%-- plot closed-loop poles
	if ccs_col == 1,		
		p = plot(real(Pl),imag(Pl),'rx');
	else
		p = plot(real(Pl),imag(Pl),'kx');
	end;	
	set(p,'Linewidth',2,'Markersize',9);			

	if observ == 0,	
		%-- without observer			
		set(choise1,'Value',1);
		set(input_zeta,'Visible','off');
		set(input_om,'Visible','off');
	elseif observ == 1,
		%-- with observer			
		set(choise1,'Value',2);
		set(input_zeta,'Visible','on');
		set(input_om,'Visible','on');
		subplot(222);
		if ccs_col == 1,
			p = plot(real(Pk),imag(Pk),'gx');
		else
			p = plot(real(Pk),imag(Pk),'k+');
		end;		
		set(p,'Linewidth',2,'Markersize',9);	
	end;
	
	if get(choise1,'value')==1,
		%-- simulation without observer
		option=simset('Maxstep',h);
		[t,x,y] = sim('sfb_s',[0 50],option);
	elseif get(choise1,'value')==2,
		%-- simulation with observer
		option=simset('Maxstep',h);
		[t,x,y] = sim('sfb_o_s',[0 50],option);
	end;

	figure(fig2_sfb);

	%-- plot step response
	subplot(211);
	if ccs_col == 1,
		if get(choise2,'value') == 1,
			plot(t,st,'r');	
		else
	 		plot(t,st,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(t,st,'k');	
		else
			plot(t,st,'k--');	
		end;
	end;		

	%-- plot control signal				
	subplot(212);
	[ts,us]=stairs(t,u);
	if ccs_col == 1,			
		if get(choise2,'value') == 1,
			plot(ts,us,'r');	
		else
	 		plot(ts,us,'r--');	
		end;
	else
		if get(choise2,'value') == 1,
			plot(ts,us,'k');	
		else
			plot(ts,us,'k--');	
		end;
	end;

    end;
	figure(fig_sfb);
	watchoff;
	set(load_syst,'Value',1);
	ex = 1;


%%---------------- HELP ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'sfb_help'),

    ttlStr='State feedback and Observer help...';
    hlpStr1= ...                                           
        ['                                             '  
         ' This demo illustrates a design method based '
	 ' on the internal model of the system. The    '
	 ' purpose of the design is to arrange a feed- '
	 ' back so that all poles of the closed-loop   '
	 ' system assume prescribed values. The control'
	 ' law is a linear feedback: u(kh)=-Lx(kh). The' 
	 ' design parameters are the sampling period   '
	 ' and the continuous time characteristic po-  '
	 ' lynomial, in terms of the damping z and the '
	 ' natural frequency w. The method is called   '
	 ' State feedback. If the states can not be    '
	 ' measured directly, an observer must be used.'
	 ' The observer determines the states from the '
	 ' inputs and outputs of the system.           '
	 '                                             '
	 ' In this demo, integral action and observer  '
	 ' are optional.                               '];


    hlpStr2= ...
	['                                             '
	 ' When integrator is chosen, the third pole is'
	 ' placed on the real axis, at the same dis-   '
	 ' tance from the origin as the other poles.   '
	 '                                             '
	 ' The choice "make own" let you construct your'
	 ' own system. Specify the continuous-time     '
	 ' matrices A,B, and C in the state-space      '
	 ' representation. This system has to be of    '  
	 ' order 2.                                    '
	 '                                             '
	 ' Notice! Do always enter C last. It is only  '
	 ' this edit-box that enhances further actions.'
	 ' Also when you change this system you have to'
	 ' use the C editbox, to make the changes be   '
	 ' accepted.                                   '];


     
    hwin(ttlStr,hlpStr1,hlpStr2); 

%%---------------- THEORY ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'sfb_theory'),
          

   ttlStr='State feedback and Observer theory...';
    hlpStr= ...                                           
        ['                                             '  
         ' See Chapter 4 CCS p. 120 for reading about  '
	 ' State-space design methods.                 '];

     
    hwin(ttlStr,hlpStr); 


%%---------------- HINTS ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'sfb_hints'),
          

   ttlStr='State feedback and Observer hints...';
    hlpStr= ...                                           
        ['                                             '  
    	 ' Choose the Double integrator. Change w from '
	 ' 2 to 1. Lowering w, makes the response time '
	 ' longer. Increase h from 0.5 to 1. An in-    '
	 ' crease in h also makes the response time    '
	 ' longer. Take away the integrator. The result'
	 ' is that the system can no longer handle the '
	 ' load disturbance.                           '];

     
    hwin(ttlStr,hlpStr); 


%%------------------- VALUES --------------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation,'values_sfb'), 


	%-- checks if the window already exists
   	[existFlag,figNumber]=figflag('Values');
    	if ~existFlag,
		fig_val_sfb = figure('Name','Values','NumberTitle'...
		,'Off','BackingStore','Off',...
		'Units','Normalized',...
		'Position',[0.05 0.05 0.3 0.3]);
	 	[existFlag,figNumber]=figflag('Values');
    	else
		clf;
        end;
	figure(fig_val_sfb);
	axes('Visible','off');
	close_val = uicontrol(fig_val_sfb,'Style','Push','String','Close',...
	'Units','normalized','Position',[0.8 0.03 0.17 0.07],...
	'Callback','close;');

	if get(system_sfb,'Value')~=1,

		l1_str = num2str(l1);
		l2_str = num2str(l2);
		l3_str = num2str(l3);
		if ccs_col == 1,
			text(0,1,'State feedback law:','Color','r');
		else
			text(0,1,'State feedback law:');
		end;
		if get(choise2,'Value')==1,
			text(0.01,0.92,'u(kh)=-[');
			text(0.25,0.92,l1_str);
			text(0.45,0.92,l2_str);
			text(0.65,0.92,l3_str);
			text(0.85,0.92,']x(kh)');
		else
			text(0.01,0.92,'u(kh)=-[');
			text(0.25,0.92,l1_str);
			text(0.45,0.92,l2_str);
			text(0.65,0.92,']x(kh)');
		end;

		if get(choise1,'Value')==2,
			if ccs_col == 1,
				text(0,0.83,'Observer matrix:','Color','r');
			else
				text(0,0.83,'Observer matrix:');
			end;
			k1_str = num2str(k1);
			k2_str = num2str(k2);
			text(0.01,0.75,'K=[');
			text(0.1,0.75,k1_str);
			text(0.30,0.75,k2_str);
			text(0.50,0.75,']');
		end;

		phi11_str = num2str(phi(1,1));
		phi12_str = num2str(phi(1,2));
		phi21_str = num2str(phi(2,1));
		phi22_str = num2str(phi(2,2));
		gam1_str = num2str(gam(1));
		gam2_str = num2str(gam(2));
		c1_str = num2str(c1);
		c2_str = num2str(c2);
		if ccs_col == 1,
			text(0,0.66,'Discrete time system:','Color','r');
		else
			text(0,0.66,'Discrete time system:');
		end;
		text(0.01,0.53,'x(k+1)=');
		text(0.23,0.58,phi11_str);
		text(0.45,0.58,phi12_str);
		text(0.23,0.48,phi21_str);
		text(0.45,0.48,phi22_str);
		text(0.67,0.53,'x(k)+');
		text(0.83,0.58,gam1_str);
		text(0.83,0.48,gam2_str);
		text(1,0.53,'u(k)');
		text(0.01,0.38,'y(k)=[');
		text(0.22,0.38,c1_str);
		text(0.35,0.38,c2_str);
		text(0.48,0.38,']x(k)');

		if ccs_col == 1,
			text(0,0.29,...
			'Discrete time characteristic polynomial:',...
			'Color','r');
		else
			text(0,0.29,...
			'Discrete time characteristic polynomial:');
		end;
		ad2_str = num2str(ad1(2));
		ad3_str = num2str(ad1(3));
		if get(choise2,'Value')==2,
			text(0.01,0.21,'A(q)=[1');
			text(0.25,0.21,ad2_str);
			text(0.55,0.21,ad3_str);
			text(0.85,0.21,']');
		elseif get(choise2,'Value')==1, 
			ad4_str = num2str(ad1(4));
			text(0.01,0.21,'A(q)=[1');
			text(0.25,0.21,ad2_str);
			text(0.55,0.21,ad3_str);
			text(0.85,0.21,ad4_str);
			text(1.08,0.21,']');
		end;

		if get(choise1,'Value')==2,
			if ccs_col == 1,
				text(0,0.12,...
				'Discrete time observer-polynomial:',...
				'Color','r');
			else
				text(0,0.12,...
				'Discrete time observer-polynomial:');
			end;
			ao2_str = num2str(ad(2));
			ao3_str = num2str(ad(3));
			text(0.01,0.04,'Ao(q)= [1');
			text(0.30,0.04,ao2_str);
			text(0.60,0.04,ao3_str);
			text(0.87,0.04,']');
		end;

	else
		if ccs_col == 1,
			text(0.2,0.5,'No system defined.',...
			'Color','r');
		else
			text(0.2,0.5,'No system defined.');
		end;
	end; 


%%---------------- INIT ------------------------------------------
%%----------------------------------------------------------------

elseif strcmp(operation,'winit_sfb'),

	%-- craete window
     	fig_sfb = figure('Name','State feedback design',...
	'NumberTitle','Off','Units', 'Normalized',...
	'BackingStore','Off',...
	'Position',[0.0425 0.4178 0.4861 0.4667],...
	'DefaultUicontrolFontSize',11);
	set(fig_sfb,'Color',[0.8,0.8,0.8]);

elseif strcmp(operation,'init_sfb'),
	%-- check if plot window exists	
	[existFlag,figNumber]=...
	figflag('Step response & Control signal, State feedback design');
	if ~existFlag,
		%-- create plt window
      		fig2_sfb =...
		 figure('Name',...
		'Step response & Control signal, State feedback design',...
		'NumberTitle','Off','BackingStore','Off',...
		'Units', 'Normalized', ...
		'Position', [0.5286 0.4178 0.4340 0.4667 ]);
		set(fig2_sfb,'Color',[0.8,0.8,0.8]);	
 		[existFlag,figNumber]=...
		figflag...
		('Step response & Control signal, State feedback design');
	else
		clf;fig=gcf;
	end;

	figure(fig_sfb);

	watchon;
	%-- set simulation parameters
        rktol=1e-4;
        rkmax=0.1;
        rkmin=1e-5;

	%-- create pole/zero diagram
	disc1_axes = subplot(222);	
	hold on;
	%-- plot unit circle
	t=0:.1:6.3;
	plot(sin(t),cos(t),'k-');
	grid on;
	axis('equal');
	if ccs_col == 1,
		title('Closed-loop and Observer Poles','Color','k',...
		'FontName','Times','FontSize',11);
	else
		title('Closed loop(x) and Observer(+) Poles','Color','k',...
		'FontName','Times','FontSize',11);
	end;
	set(disc1_axes,'XLim',[-1.2 1.2],'YLim',[-1.2 1.2],...
	'Clipping','Off','XLimMode','Manual','YLimMode'...
	,'Manual','DrawMode', 'Fast','Xcolor','k','Ycolor','k',...
	'FontName','Times','FontSize',11);


%%---------------- FRAME LEFT ------------------------------------

	frame_left = uicontrol(fig_sfb,'Style','Frame',...
	'Units', 'Normalized','Position', [0.0161 0.0214 0.1786 0.9524 ]);

	main_sfb = uicontrol(fig_sfb,'Style','Push',...
	'String','Main Menu',...
	'Units', 'Normalized', ...
	'Position', [0.0339 0.8667 0.1429 0.0595 ],...
	'BackgroundColor',[0.6 0.6 1],...
	'Callback','sfb(''close_sfb'');');

	help_sfb = uicontrol(fig_sfb,'Style','Push','String','Help!',...
	'Units', 'Normalized','Position', [0.0339 0.7833 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.3],...
	'Callback','sfb(''sfb_help'');');

	theory_sfb = uicontrol(fig_sfb,'Style','Push','String','Theory',...
	'Units', 'Normalized','Position', [0.0339 0.7000 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.5],...
	'Callback','sfb(''sfb_theory'');');

	hint_sfb = uicontrol(fig_sfb,'Style','Push','String','Hints',...
	'Units', 'Normalized','Position', [0.0339 0.6167 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 1 0.7],...
	'Callback','sfb(''sfb_hints'');');

	clear_sfb = uicontrol(fig_sfb,'Style','Push',...
	'String','Clear plots',...
	'Units', 'Normalized','Position', [0.0339 0.4500 0.1429 0.0595 ], ...
	'BackgroundColor',[0.5 1 0.5],...
	'Callback','sfb(''sfb_clear'');');

	reset_sfb = uicontrol(fig_sfb,'Style','Push',...
	'String','Reset',...
	'Units', 'Normalized','Position', [0.0339 0.3667 0.1429 0.0595 ],  ...
	'BackgroundColor',[0.7 1 0.7],...
	'Callback','sfb(''sfb_reset'');');

	values_sfb = uicontrol(fig_sfb,'Style','Push','String','Values',...
	'Units','normalized','Position',[0.0339 0.2356 0.1429 0.0595],...
	'BackgroundColor',[0.9 1 0.9],...
	'Callback','sfb(''values_sfb'');');

	close_sfb = uicontrol(fig_sfb,'Style','Push','String','Quit',...
	'Units', 'Normalized','Position', [0.0339 0.0690 0.1429 0.0595 ],  ...
	'BackgroundColor',[1 0.4 0.4],...
	'Callback','sfb(''close_sfb_def'');');


%%--------------- FRAME MIDDLE -------------------------------------------

	frame_middle = uicontrol(fig_sfb,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2036 0.0214 0.3214 0.9524 ]);

	system_sfb = uicontrol(fig_sfb,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.8667 0.2679 0.0595 ],  ...
	'string',...
	'Select system|Double integrator|Harmonic oscillator|Make own');
	set(system_sfb,'Callback','sfb(''sfb_syst'');');

	input_a = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.8071 0.1429 0.0476 ], ...
	'String','[ ; ]');
	input_b = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.7595 0.1429 0.0476 ],  ...
	'String','[ ]');
	input_c = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.3375 0.7119 0.1429 0.0476 ],  ...
	'String','[ ]');
	set(input_c,'Callback','sfb(''sfb_calc'');');	

	a_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.8071 0.0893 0.0476 ],  ...
	'String','A=');
	b_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.7595 0.0893 0.0476 ],  ...
	'String','B^T=');
	c_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.2482 0.7119 0.0893 0.0476 ], ...
	'String','C=');
	set(input_a,'Visible','off');
	set(input_b,'Visible','off');
	set(input_c,'Visible','off');
	set(a_label,'Visible','off');
	set(b_label,'Visible','off');
	set(c_label,'Visible','off');

	choise1 = uicontrol(fig_sfb,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.5929 0.2679 0.0595 ],  ...
	'string',...
	'Without observer|With observer');
	set(choise1,'Callback','sfb(''sfb_calc'');');

	choise2 = uicontrol(fig_sfb,'Style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.5214 0.2679 0.0595 ],  ...
	'string',...
	'With integrator|Without integrator');
	set(choise2,'Callback','sfb(''sfb_calc'');');

	frame_h = uicontrol(fig_sfb,'Style','Frame',...
	'Units', 'Normalized','Position', [0.2180 0.3950 0.3000 0.1100 ]);
	
	slid = uicontrol(fig_sfb,'Style','slider',...
	'Units', 'Normalized','Position', [0.2571 0.4024 0.2143 0.0476 ],  ...
	'Min',0.01,'Max',2,...
	'Value',0.5,'Callback','sfb(''sfb_calc'');');

	h_cur = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.4179 0.4500 0.0860 0.0476 ],  ...
	'String',num2str(get(slid,'Val')));

	h_min = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4024 0.0357 0.0476 ],  ...
	'String',num2str(get(slid,'Min')));
	h_max = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.4714 0.4024 0.0330 0.0476 ],  ...
	'String',num2str(get(slid,'Max')));

	h_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.2214 0.4500 0.1964 0.0476 ],  ...
	'String','Sampl.period h=');

	save_syst = uicontrol(fig_sfb,'style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.1643 0.2679 0.0595 ],  ...
	'string',...
	'Save System|syst1|syst2|syst3|syst4|syst5');
	set(save_syst,'Callback','sfb(''sfb_save'');');

	load_syst = uicontrol(fig_sfb,'style','popup',...
	'Units', 'Normalized','Position', [0.2304 0.0690 0.2679 0.0595 ], ...
	'string',...
	'Load System|syst1|syst2|syst3|syst4|syst5');
	set(load_syst,'Callback','sfb(''sfb_load'');');


%%------------ RIGHT FRAME-------------------------------------

	frame_sfb = uicontrol(fig_sfb,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5696 0.2833 0.4107 0.2381 ]);

	frame_obs = uicontrol(fig_sfb,'Style','Frame',...
	'Units', 'Normalized','Position', [0.5696 0.0214 0.4107 0.2381 ]);

	if ccs_col == 1,
		sfb_label = uicontrol(fig_sfb,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5800 0.4619 0.3700 0.0476 ],...
		'String','Cont. characteristic polynomial',...
		'ForegroundColor','y');

		obs_label = uicontrol(fig_sfb,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5800 0.2000 0.3700 0.0476 ],...
		'String','Cont. observer polynomial',...
		'ForegroundColor','g');
	else
		sfb_label = uicontrol(fig_sfb,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5800 0.4619 0.3700 0.0476 ],...
		'String','Cont. characteristic polynomial',...
		'ForegroundColor','k');

		obs_label = uicontrol(fig_sfb,'Style','text',...
		'Units', 'Normalized', ...
		'Position', [0.5800 0.2000 0.3700 0.0476 ],...
		'String','Cont. observer polynomial',...
		'ForegroundColor','k');
	end;

	charsfb_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.5875 0.4262 0.3571 0.0476 ],  ...
	'String','(s^2+2zws+w^2)(s+p)');

	charobs_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.5875 0.1643 0.3571 0.0476 ],  ...
	'String','s^2+2zws+w^2');

	input_zeta1 = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.3786 0.0714 0.0476 ]);
	set(input_zeta1,'Callback','sfb(''sfb_calc'');',...
	'Backgroundcolor','w');

	input_om1 = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.3310 0.0714 0.0476 ]);
	set(input_om1,'Callback','sfb(''sfb_calc'');',...
	'Backgroundcolor','w');

	zeta1_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.3786 0.1250 0.0452 ],  ...
	'String','zeta =');
	om1_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.3310 0.1250 0.0476 ],  ...
	'String','omega =');

	input_zeta = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.1167 0.0714 0.0476 ]);
	set(input_zeta,'String','0.7','Backgroundcolor','w');
	zeta = str2num(get(input_zeta,'String'));
	set(input_zeta,'Callback','sfb(''sfb_calc'');');
	
	input_om = uicontrol(fig_sfb,'Style','edit',...
	'Units', 'Normalized','Position', [0.7393 0.0690 0.0714 0.0476 ]);
	set(input_om,'String','1.5','Backgroundcolor','w');
	om = str2num(get(input_om,'String'));
	set(input_om,'Callback','sfb(''sfb_calc'');');
	
	zeta_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.1167 0.1250 0.0452 ],  ...
	'String','zeta =');
	om_label = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.6054 0.0690 0.1250 0.0476 ],  ...
	'String','omega =');


	set(input_zeta1,'Visible','off');
	set(input_om1,'Visible','off');
	set(input_zeta,'Visible','off');
	set(input_om,'Visible','off');


%%------------- ERROR MESSAGES ----------------------------------

	error1_sfb = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.3548 0.3929 0.0595 ],  ...
	'String',...
	'Not a correct 2:nd order system,',...
	'BackgroundColor','r');
	set(error1_sfb,'Visible','off');

	error2_sfb = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.2952 0.3929 0.0595 ],  ...
	'String',...
	'chose system 3 again and redo it!',...
	'BackgroundColor','r');
	set(error2_sfb,'Visible','off');

	error3_sfb = uicontrol(fig_sfb,'Style','text',...
	'Units', 'Normalized','Position', [0.0339 0.2952 0.3929 0.0595 ], ...
	'String',...
	'Sampled system not controllable!',...
	'BackgroundColor','r');
	set(error3_sfb,'Visible','off');


%%----------- AXES, 2:nd WINDOW -------------------------------------

	figure(fig2_sfb);

	%-- create step response diagram
	step_axes = subplot(211);
	hold on;
	grid on;
	set(step_axes, 'XLim',[0 50],'YLim'...
	, [-1 2],'XColor','k','YColor','k',...
	'FontName','Times','FontSize',11);
	title('Step response','Color','k',...
	'FontName','Times','FontSize',11);

	%-- create control signal diagram
	control_axes = subplot(212);
	hold on;
	grid on;
	set(control_axes, 'XLim',[0 50],'YLim'...
	, [-1 4],'XColor','k','YColor','k',...
	'FontName','Times','FontSize',11);
	title('Control signal','Color','k',...
	'FontName','Times','FontSize',11);
	xlabel('Time','Color','k',...
	'FontName','Times','FontSize',11);

	ex = 0;

	figure(fig_sfb);
	watchoff;


%%----------------- CLOSE ALL WINDOWS------------------------------
%%-----------------------------------------------------------------

elseif strcmp(operation, 'close_sfb'),

	[existFlag,figNumber]=figflag('State feedback design');
    	if existFlag,
		close(fig_sfb);	
 	end;

	[existFlag,figNumber]=figflag('Step response & Control signal, State feedback design');
    	if existFlag,
		close(fig2_sfb);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		set(fig_ccs,'Visible','on');	
 	end;


elseif strcmp(operation, 'close_sfb_def'),

	[existFlag,figNumber]=figflag('State feedback design');
    	if existFlag,
		close(fig_sfb);	
 	end;

	[existFlag,figNumber]=figflag('Step response & Control signal, State feedback design');
    	if existFlag,
		close(fig2_sfb);	
 	end;

	[existFlag,figNumber]=figflag('Sampled Data Systems Help');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Values');
    	if existFlag,
		close;	
 	end;

	[existFlag,figNumber]=figflag('Welcome to Sampled Data Systems Demo!');
    	if existFlag,
		close(fig_ccs);	
 	end;


end;
